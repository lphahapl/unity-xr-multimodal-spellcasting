Shader "Hidden/CourtyardReviewID" {
Properties {_AuditCull("Culling",Float)=2 _IsGrass("Grass distance",Float)=0 _ReviewId("Index",Vector)=(0,0,0,1)}
SubShader { Tags {"RenderPipeline"="UniversalPipeline" "Queue"="Geometry" "RenderType"="Opaque"}
 Pass { Tags{"LightMode"="SRPDefaultUnlit"} Cull [_AuditCull] ZWrite On ZTest LEqual
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 float4 _ReviewId;float _IsGrass;
 struct inp {float3 pos:POSITION;float4 root:TEXCOORD1;}; struct outp {float4 pos:SV_POSITION;};
 outp vert(inp i) {outp o; float3 w=TransformObjectToWorld(i.pos);if(_IsGrass>.5){float3 r=TransformObjectToWorld(i.root.xyz);w=lerp(w,r,smoothstep(14,18,distance(r,GetCameraPositionWS())));}o.pos=TransformWorldToHClip(w);return o;}
 half4 frag(outp i):SV_Target {return _ReviewId;}
 ENDHLSL
}}}

