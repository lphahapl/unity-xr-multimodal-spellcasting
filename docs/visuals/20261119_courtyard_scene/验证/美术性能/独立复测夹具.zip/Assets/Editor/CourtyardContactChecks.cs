using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
using Object=UnityEngine.Object;
public static class CourtyardContactChecks {
 class Surface { public string label;public MeshCollider collider;public bool rock;}
 static readonly List<Surface> visibleGround=new List<Surface>();static readonly StringBuilder rows=new StringBuilder();
 static readonly StringBuilder walk=new StringBuilder();
 static string S(float f)=>float.IsNaN(f)?"":f.ToString("F3");
 static string Full(Transform t)=>t?(t.parent?Full(t.parent)+"/":"")+t.name:"";
 static GameObject Proxy(MeshRenderer r) {
    var proxy=new GameObject("GroundAuditProxy");
    proxy.layer=30;proxy.transform.SetParent(r.transform,false);
    return proxy;
 }
 static void SurfaceList(Transform[] transforms){
    foreach(var t in transforms.Where(x=>x.name=="CourtPlateau"||x.name=="GateSpur")){
       var g=t.GetComponent<LODGroup>();foreach(var r in g.GetLODs()[0].renderers.OfType<MeshRenderer>()){
           var c=Proxy(r).AddComponent<MeshCollider>();c.sharedMesh=r.GetComponent<MeshFilter>().sharedMesh;
           visibleGround.Add(new Surface{label=t.name,collider=c,rock=true});
       }
    }
    foreach(var r in Object.FindObjectsByType<MeshRenderer>(FindObjectsSortMode.None).Where(x=>Full(x.transform).Contains("庭院与崖径铺装")&&!x.name.Contains("水面")||x.name=="连续院墙石基")){
       var c=Proxy(r).AddComponent<MeshCollider>();c.sharedMesh=r.GetComponent<MeshFilter>().sharedMesh;
       visibleGround.Add(new Surface{label=r.name,collider=c,rock=false});
    }
    Physics.SyncTransforms();
 }
 static float SurfaceY(Vector3 at,bool rock,out string label){
    float best=float.NegativeInfinity;label="";var ray=new Ray(new Vector3(at.x,Mathf.Max(2f,at.y+1.25f),at.z),Vector3.down);
    foreach(var s in visibleGround){
       if(s.rock!=rock)continue;
       if(s.collider.Raycast(ray,out var hit,30)&&hit.point.y>best){best=hit.point.y;label=s.label;}
    }
    return float.IsNegativeInfinity(best)?float.NaN:best;
 }
 static bool PhysicalAt(Vector3 at,out RaycastHit hit) {
    var ray=new Ray(new Vector3(at.x,at.y+.42f,at.z),Vector3.down);
    var got=Physics.RaycastAll(ray,2.5f,~(1<<30),QueryTriggerInteraction.Ignore)
      .Where(x=>x.normal.y>.55f).OrderByDescending(x=>x.point.y).ToArray();
    hit=got.Length>0?got[0]:default;return got.Length>0;
 }
 static void Point(string id,Vector3 at) {
    string r,p;float stone=SurfaceY(at,true,out r),paving=SurfaceY(at,false,out p);
    var ok=PhysicalAt(at,out var hit);float support=!float.IsNaN(stone)&&!float.IsNaN(paving)?Mathf.Max(stone,paving):float.IsNaN(stone)?paving:stone;
    rows.AppendLine(string.Join(",",new[]{id,S(at.x),S(at.y),S(at.z),S(stone),r,S(paving),p,S(at.y-support),ok?S(hit.point.y):"",ok?Full(hit.transform):"NO_FLOOR"}));
 }
 static void Footprints(Transform[] ts){
    void Rect(string label,Transform t,float hx,float hz,float localFloor){
        foreach(float x in new[]{-hx,hx})foreach(float z in new[]{-hz,hz})Point(label,t.TransformPoint(new Vector3(x,localFloor,z)));
    }
    foreach(var t in ts.Where(t=>t.name=="WallStraight"||t.name=="WallCorner"||t.name=="WallEnd")){
        var g=t.GetComponentInChildren<LODGroup>();if(!g)continue;
        var ren=g.GetLODs()[0].renderers[0];var at=t.position;at.y=ren.bounds.min.y;
        Point("墙基·"+t.name,at);
    }
    foreach(var t in ts.Where(t=>t.Find("WalkwayConnection"))){
        var sc=t.lossyScale;
        var gx=t.name.Contains("西窗外")?3.0f:t.name.Contains("东窗外")?3.4f:3.65f;
        Rect("工坊台基·"+t.name,t,gx,2.0f,-.24f);
        foreach(float z in new[]{1.5f,2.1f,2.8f,3.4f})Point("工坊入口·"+t.name,t.TransformPoint(new Vector3(0,0,z)));
    }
    foreach(var t in ts.Where(t=>t.name=="CourtGatehouse")){
       foreach(float x in new[]{-2.13f,2.1f})foreach(float z in new[]{-1.28f,1.29f})Point("院门柱底",t.TransformPoint(new Vector3(x,0,z)));
    }
    foreach(var t in ts.Where(t=>t.name=="TianyiPavilionSet")){
       Rect("天仪阁外缘",t,4.07f,4.07f,-.20f);
       foreach(float z in new[]{-5.0f,-4.2f,-3.5f,3.5f,4.2f,5f})Point("天仪阁门槛与外接",t.TransformPoint(new Vector3(0,0,z)));
    }
    foreach(var t in ts.Where(t=>t.name=="苏醒室分段石基"||t.name=="通廊石基"||t.name=="试炼间分段石基")){
       var g=t.GetComponentInChildren<LODGroup>();if(!g)continue;
       var r=g.GetLODs()[0].renderers[0];var b=r.bounds;
       foreach(float x in new[]{b.min.x+.18f,b.max.x-.18f})foreach(float z in new[]{b.min.z+.18f,b.max.z-.18f})Point("主殿基座·"+t.name,new Vector3(x,b.min.y,z));
    }
    for(float z=4;z>=-17;z-=1)foreach(float x in new[]{16.28f,17.35f,18.42f})Point("崖径·石门下方",new Vector3(x,-.04f,z));
 }
 static void Path(string name,Vector3 a,Vector3 b,float xOffset=0){
    int steps=Mathf.CeilToInt(Vector3.Distance(a,b)/.22f);
    float min=float.PositiveInfinity,max=float.NegativeInfinity,maxStep=0,prev=float.NaN;
    int missing=0;var dev=new HashSet<string>(); var atMid=Vector3.Lerp(a,b,.5f);
    var side=Vector3.Cross(Vector3.up,(b-a).normalized).normalized;
    Vector3 first=a+side*xOffset,last=b+side*xOffset;
    float r=.24f;
    for(int i=0;i<=steps;i++){
       var pos=Vector3.Lerp(first,last,i/(float)steps);
       if(!PhysicalAt(pos,out var hit)){missing++;dev.Add("floor missing @"+pos);continue;}
       float y=hit.point.y;min=Mathf.Min(min,y);max=Mathf.Max(max,y);if(!float.IsNaN(prev))maxStep=Mathf.Max(maxStep,Mathf.Abs(prev-y));prev=y;
       pos.y=y;
       var ob=Physics.OverlapCapsule(pos+Vector3.up*(r+.08f),pos+Vector3.up*(1.73f-r),r,~(1<<30),QueryTriggerInteraction.Ignore);
       foreach(var c in ob)if(c!=hit.collider && c.bounds.max.y>y+.18f)dev.Add("capsule "+Full(c.transform)+" @ "+pos.ToString("F2"));
    }
    walk.AppendLine(name+","+S(xOffset)+","+(steps+1)+","+missing+","+S(min)+","+S(max)+","+S(maxStep)+",\""+string.Join(" | ",dev.Take(4)).Replace("\"","'")+"\"");
 }
 public static void Run(string output){
    var ts=Object.FindObjectsByType<Transform>(FindObjectsSortMode.None);
    visibleGround.Clear();rows.Clear();walk.Clear();rows.AppendLine("类别,x,基准或脚底Y,z,岩体可见表面Y,岩体,铺装可见表面Y,铺装,基准减最高可见承托,物理站立Y,命中碰撞体");
    walk.AppendLine("路径,侧移米,采样,无地面,最低,最高,最大踏步,几何碰撞检查");
    SurfaceList(ts);Footprints(ts);
    var foundation=visibleGround.FirstOrDefault(s=>s.label=="连续院墙石基");
    if(foundation!=null){
      var results=new StringBuilder("wall,x,z,wallBottom,foundationTop,foundationBottom,terrainTop,upperContactGap,rockEmbed\n");
      var maxRockGap=-100f;
      foreach(var w in ts.Where(t=>t.name=="WallStraight"||t.name=="WallCorner"||t.name=="WallEnd")){
        var rb=w.GetComponentInChildren<LODGroup>().GetLODs()[0].renderers[0].bounds;
        var probe=w.position;float rock=SurfaceY(probe,true,out var rockname);var ray=new Ray(probe+Vector3.up*2,Vector3.down);
        bool on=foundation.collider.Raycast(ray,out var hit,10);float top=on?hit.point.y:float.NaN;float baseY=foundation.collider.bounds.min.y;
        results.AppendLine(string.Join(",",new[]{w.name,S(probe.x),S(probe.z),S(rb.min.y),S(top),S(baseY),S(rock),S(rb.min.y-top),S(rock-baseY)}));
      }
      File.WriteAllText(output+"/wall-footings.csv",results.ToString(),new UTF8Encoding(true));
    }
    foreach(float x in new[]{-.56f,0,.56f}){
        Path("院门前后",new Vector3(17.65f,0,52.4f),new Vector3(17.65f,0,46.8f),x);
        Path("天仪阁入口",new Vector3(17.35f,0,23.3f),new Vector3(17.35f,0,20.1f),x);
        Path("天仪阁出口",new Vector3(17.35f,0,15.1f),new Vector3(17.35f,0,11.8f),x);
        Path("崖径与石门",new Vector3(17.35f,0,3.8f),new Vector3(17.35f,0,-17f),x);
    }
    foreach(var t in ts.Where(t=>t.Find("WalkwayConnection"))){
       Path("工坊进门 "+t.name,t.TransformPoint(new Vector3(0,0,3.8f)),t.TransformPoint(new Vector3(0,0,1.3f)));
    }
    File.WriteAllText(output+"/ground-contacts.csv",rows.ToString(),new UTF8Encoding(true));File.WriteAllText(output+"/door-landings.csv",walk.ToString(),new UTF8Encoding(true));
 }
}



