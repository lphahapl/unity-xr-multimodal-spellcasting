using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using Object=UnityEngine.Object;
// Orthogonal estimate of submitting real triangles behind independent opaque architecture.
public static class CourtyardEyeOcclusion {
 class State {
    public Renderer r;public bool off;public Material[] mats;public MaterialPropertyBlock properties;
    public State(Renderer source) {r=source;off=r.forceRenderingOff;mats=r.sharedMaterials;properties=new MaterialPropertyBlock();r.GetPropertyBlock(properties);}
    public void Restore(){r.forceRenderingOff=off;r.sharedMaterials=mats;r.SetPropertyBlock(properties);}
 }
 static bool Opaque(Renderer r){
    if(!(r is MeshRenderer)&&!(r is SkinnedMeshRenderer))return false;
    var ms=r.sharedMaterials;
    return ms.Length>0&&ms.All(m=>m&&m.renderQueue<=2450&&!m.IsKeywordEnabled("_ALPHATEST_ON")
       &&(!m.HasProperty("_AlphaClip")||m.GetFloat("_AlphaClip")<.1f)
       &&(!m.HasProperty("_Cull")||m.GetFloat("_Cull")>=1f)
       &&(m.shader.name=="Universal Render Pipeline/Lit"||m.shader.name=="Universal Render Pipeline/Simple Lit"||m.shader.name=="Standard"||m.shader.name=="NarutoVR/Opening Grass"));
 }
 static long Tris(Renderer r){var f=r.GetComponent<MeshFilter>();var m=r is SkinnedMeshRenderer sk?sk.sharedMesh:(f?f.sharedMesh:null);if(!m)return 0;long n=0;for(int i=0;i<m.subMeshCount;i++)if(m.GetTopology(i)==MeshTopology.Triangles)n+=m.GetIndexCount(i)/3;return n;}
 public static string Sample(string name,Camera cam,List<Renderer> visible,Renderer[] rs,LODGroup[] groups,string dst) {
    var state=rs.Select(r=>new State(r)).ToArray();var gr=groups.Where(g=>g.enabled).ToArray();
    var m=new Material(Shader.Find("Hidden/CourtyardReviewID"));var grassMat=new Material(m);grassMat.SetInt("_AuditCull",0);grassMat.SetFloat("_IsGrass",1);var prop=new MaterialPropertyBlock();
    var solid=visible.Where(Opaque).ToArray();var other=visible.Where(r=>!Opaque(r)).ToArray();
    int w=824,h=770;var rt=new RenderTexture(w,h,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.Linear){antiAliasing=1};rt.Create();
    var d=cam.GetUniversalAdditionalCameraData();d.renderPostProcessing=false;d.renderShadows=false;cam.allowMSAA=false;cam.allowHDR=false;
    var oldFlags=cam.clearFlags;var oldBG=cam.backgroundColor;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Color.black;cam.targetTexture=rt;
    int[] coverage=new int[solid.Length];int unmapped=0;
    try{
       foreach(var g in gr)g.enabled=false;
       foreach(var rr in rs)rr.forceRenderingOff=true;
       if(solid.Length>=4095)throw new Exception("Review ID capacity exceeded "+solid.Length);
       for(int i=0;i<solid.Length;i++){
          int v=i+1;var r=solid[i];r.forceRenderingOff=false;var mats=r.sharedMaterials;
          for(int j=0;j<mats.Length;j++)mats[j]=mats[j]&&mats[j].shader.name=="NarutoVR/Opening Grass"?grassMat:m;r.sharedMaterials=mats;r.SetPropertyBlock(null);
          prop.Clear();prop.SetVector("_ReviewId",new Vector4((v&15)*17/255f,((v>>4)&15)*17/255f,((v>>8)&15)*17/255f,1));r.SetPropertyBlock(prop);
       }
       cam.Render();RenderTexture.active=rt;var screen=new Texture2D(w,h,TextureFormat.RGBA32,false,true);
       screen.ReadPixels(new Rect(0,0,w,h),0,0);screen.Apply();
       foreach(var px in screen.GetPixels32()){
          int id=(int)Mathf.Round(px.r/17f)|((int)Mathf.Round(px.g/17f)<<4)|((int)Mathf.Round(px.b/17f)<<8);
          if(id==0)continue;if(id>coverage.Length){unmapped++;continue;}coverage[id-1]++;
       }
       File.WriteAllBytes(Path.Combine(dst,name+"_opaque_id.png"),screen.EncodeToPNG());Object.DestroyImmediate(screen);
    }finally {
       foreach(var g in gr)g.enabled=true;foreach(var r in state)r.Restore();
       cam.targetTexture=null;RenderTexture.active=null;cam.clearFlags=oldFlags;cam.backgroundColor=oldBG;
       rt.Release();Object.DestroyImmediate(rt);Object.DestroyImmediate(m);Object.DestroyImmediate(grassMat);
    }
    var vset=solid.Where((r,i)=>coverage[i]>0).ToArray();
    if(vset.Length==0||unmapped>100)throw new Exception("Invalid GPU ID buffer "+name+" visible="+vset.Length+" unknownPixels="+unmapped);
    long non=other.Sum(Tris),visibleCount=vset.Sum(Tris);int unmat=vset.Concat(other).SelectMany(x=>x.sharedMaterials).Where(x=>x).Distinct().Count();
    return string.Join(",",new object[]{name,solid.Length,vset.Length,other.Length,TrisTotal(solid),visibleCount,non,visibleCount+non,unmat,unmapped});
 }
 static long TrisTotal(Renderer[] rs){return rs.Sum(Tris);}
}

