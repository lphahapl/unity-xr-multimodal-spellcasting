using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using NarutoVR.SealCombat.Rpg;
using Object=UnityEngine.Object;
public static class CourtyardEyeBudget {
    const string directory="CourtyardEyeQA";
    static string Part(Transform t) {return t? (t.parent?Part(t.parent)+"/":"")+t.name:"";}
    static Mesh MeshOf(Renderer r){if(r is SkinnedMeshRenderer sk)return sk.sharedMesh;var f=r.GetComponent<MeshFilter>();return f?f.sharedMesh:null;}
    static List<Renderer> Select(Vector3 head,Camera c,Renderer[] r,LODGroup[] groups,out Dictionary<Renderer,int> tiers) {
        var rs=new HashSet<Renderer>();var allGrouped=new HashSet<Renderer>();tiers=new Dictionary<Renderer,int>();
        foreach(var g in groups.Where(o=>o.enabled)){
            var levels=g.GetLODs();foreach(var l in levels)foreach(var o in l.renderers)if(o)allGrouped.Add(o);
            var scale=g.transform.lossyScale;float size=g.size*Mathf.Max(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z));
            float d=(g.transform.TransformPoint(g.localReferencePoint)-head).magnitude;
            float ratio=size*QualitySettings.lodBias/(Mathf.Max(.0001f,d)*2*Mathf.Tan(c.fieldOfView*.5f*Mathf.Deg2Rad));
            int tier=Array.FindIndex(levels,x=>ratio>=x.screenRelativeTransitionHeight);
            if(tier<0||levels.Length==0)continue;tier=Mathf.Max(tier,Mathf.Min(levels.Length-1,QualitySettings.maximumLODLevel));
            foreach(var rr in levels[tier].renderers)if(rr){rs.Add(rr);tiers[rr]=tier;}
        }
        foreach(var rr in r)if(!allGrouped.Contains(rr))rs.Add(rr);
        var planes=GeometryUtility.CalculateFrustumPlanes(c);
        return rs.Where(rr=>rr&&rr.enabled&&!rr.forceRenderingOff&&rr.gameObject.activeInHierarchy&&((1<<rr.gameObject.layer)&c.cullingMask)!=0&&GeometryUtility.TestPlanesAABB(planes,rr.bounds)).ToList();
    }
    static long Tris(Mesh m){if(!m)return 0;long count=0;for(int s=0;s<m.subMeshCount;s++)if(m.GetTopology(s)==MeshTopology.Triangles)count+=m.GetIndexCount(s)/3;return count;}
    static string Csv(string v)=>"\""+v.Replace("\"","\"\"")+"\"";
    static void CamStats(){
        var rs=Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None);var gs=Object.FindObjectsByType<LODGroup>(FindObjectsSortMode.None);
        var baseline=Camera.main??Object.FindFirstObjectByType<Camera>();
        var cam=new GameObject("Left eye conservative proxy").AddComponent<Camera>();cam.enabled=false;
        cam.fieldOfView=92;cam.aspect=1.07f;cam.nearClipPlane=.05f;cam.farClipPlane=baseline?baseline.farClipPlane:200;
        cam.cullingMask=baseline?baseline.cullingMask:~0;
        var player=Object.FindFirstObjectByType<LinearRpgController>();var initial=player.CheckpointAt(0);
        var checkpoint=initial.floorPosition;var spawn=checkpoint+Vector3.up*1.60f;
        var pts=new[]{spawn,new Vector3(17.65f,1.60f,52.25f),new Vector3(17.35f,1.6f,33),new Vector3(17.65f,1.6f,21.15f)};
        var targets=new[]{spawn+initial.transform.forward,new Vector3(17.35f,1.65f,26),new Vector3(17.9f,1.85f,17.55f),new Vector3(17.35f,1.92f,17.55f)};
        var names=new[]{"出生点","院门","量水道","天仪阁入口"};var summary=new StringBuilder();
        summary.AppendLine("Camera,x,y,z,targetX,targetY,targetZ,renderers,meshRenderers,uniqueMaterials,meshDrawSlots,triangles,LOD0,LOD1,LOD2+,ungrouped,dynamicNonMesh");
        var full=new StringBuilder("Camera,Renderer,LOD,triangles,subMeshes,materials\n");
        var grassBudget=new StringBuilder("Camera,submittedGrassRenderers,submittedGrassTriangles,whollyBeyond18mGrassRenderers,whollyBeyond18mGrassTriangles\n"); var occ=new StringBuilder("Camera,frustumOpaqueMeshes,pixelVisibleOpaqueMeshes,retainedCustomAlphaOrOther,frustumOpaqueTriangles,pixelVisibleOpaqueTriangles,retainedCustomAlphaOrOtherTriangles,potentialVisibleTriangles,uniqueMaterials,unmappedPixels\n");
        for(int i=0;i<pts.Length;i++) {
            cam.transform.position=pts[i];cam.transform.LookAt(targets[i]);
            var visible=Select(pts[i],cam,rs,gs,out var tiers);
            var mats=new HashSet<Material>();long tris=0;int n=0,slots=0;var hist=new int[4];int dynamics=0;
            foreach(var rr in visible.OrderByDescending(r=>Tris(MeshOf(r)))){
                var mesh=MeshOf(rr);int t=tiers.TryGetValue(rr,out var lvl)?lvl:-1;hist[t<0?3:Mathf.Min(2,t)]++;
                foreach(var m in rr.sharedMaterials)if(m)mats.Add(m);
                var count=Tris(mesh);if(mesh){n++;tris+=count;slots+=Mathf.Max(mesh.subMeshCount,rr.sharedMaterials.Length);}
                else dynamics++;
                full.AppendLine(Csv(names[i])+","+Csv(Part(rr.transform))+","+t+","+count+","+(mesh?mesh.subMeshCount:0)+","+Csv(string.Join("|",rr.sharedMaterials.Select(m=>m?m.name:"NULL"))));
            }
            var grass=visible.Where(r=>r.sharedMaterials.Any(m=>m && m.shader.name=="NarutoVR/Opening Grass")).ToArray();var farGrass=grass.Where(r=>r.bounds.SqrDistance(pts[i])>18*18).ToArray();grassBudget.AppendLine(string.Join(",",new object[]{names[i],grass.Length,grass.Sum(rr=>Tris(MeshOf(rr))),farGrass.Length,farGrass.Sum(rr=>Tris(MeshOf(rr)))}));try{occ.AppendLine(CourtyardEyeOcclusion.Sample(names[i],cam,visible,rs,gs,directory));}catch(Exception ex){occ.AppendLine(names[i]+",estimator failed: "+ex.Message);}
            var e=pts[i];var a=targets[i];summary.AppendLine(string.Join(",",new object[]{names[i],e.x,e.y,e.z,a.x,a.y,a.z,visible.Count,n,mats.Count,slots,tris,hist[0],hist[1],hist[2],hist[3],dynamics}));
        }
        File.WriteAllText(directory+"/eye-budgets.csv",summary.ToString(),new UTF8Encoding(true));
        File.WriteAllText(directory+"/grass-distance.csv",grassBudget.ToString(),new UTF8Encoding(true));File.WriteAllText(directory+"/opaque-pixel-estimate.csv",occ.ToString(),new UTF8Encoding(true));
        File.WriteAllText(directory+"/frustum-renderers.csv",full.ToString(),new UTF8Encoding(true));
        File.WriteAllText(directory+"/method.txt","Unity="+Application.unityVersion+" target="+EditorUserBuildSettings.activeBuildTarget+" quality="+QualitySettings.names[QualitySettings.GetQualityLevel()]+" lodBias="+QualitySettings.lodBias+" maxLOD="+QualitySettings.maximumLODLevel+" near="+cam.nearClipPlane+" far="+cam.farClipPlane+" verticalFOV=92 aspect=1.07 cullingMask="+cam.cullingMask+"\nSpawn checkpoint="+initial.nodeId+" look="+initial.transform.forward+" at eye height 1.60m above the serialized landing.\nEach mesh touching the eye frustum is counted at its selected LOD in full. Opaque occlusion, draw batching, shader passes, live GPU dispatches, animation and runtime particles are outside this mono editor estimate.\n");
        Object.DestroyImmediate(cam.gameObject);
    }
    public static void Run(){
        CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;
        string scene="Assets/Scene/Chapter01_Courtyard.unity";EditorSceneManager.OpenScene(scene);
        int mobile=Array.IndexOf(QualitySettings.names,"Mobile");if(mobile<0)throw new Exception("Missing Mobile Android profile");QualitySettings.SetQualityLevel(mobile,true);Directory.CreateDirectory(directory);CamStats();CourtyardContactChecks.Run(directory);
        Debug.Log("COURTYARD_FULL_GEOMETRY_QA_PASS");
    }
}


