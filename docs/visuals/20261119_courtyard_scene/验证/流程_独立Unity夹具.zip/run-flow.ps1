param([string]$tag,[string]$scene)
$env:ALLUSERSPROFILE=[Environment]::GetFolderPath('CommonApplicationData')
$iso='D:/Temp/CH01-CourtyardRoutePlay-20261119'
$env:CH01_FLOW_OUT="$iso/flow-$tag.txt";$env:CH01_FLOW_SCENE=$scene
$proc=Start-Process 'D:/unity_hub/6000.3.10f1/Editor/Unity.exe' -PassThru -WindowStyle Hidden -WorkingDirectory $iso -ArgumentList @('-batchmode','-force-d3d11','-buildTarget','Android','-projectPath',$iso,'-executeMethod','CourtyardFlowProbe.Run','-logFile',"$iso/flow-$tag.log")
$proc.Id
