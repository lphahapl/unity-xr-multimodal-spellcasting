using System;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using NarutoVR.SealCombat.Rpg;

// Candidate exploration uses the same floor, sweep and overlap queries as walk input.
// Accepted sample segments are then executed by the production movement controller.
public class CourtyardWalkDriver {
    const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic;
    static readonly MethodInfo Floor=typeof(RpgLocomotionController).GetMethod("SmoothFloor",Flags);
    static readonly MethodInfo Leg=typeof(RpgLocomotionController).GetMethod("TrySmoothLeg",Flags);
    static readonly MethodInfo Step=typeof(RpgLocomotionController).GetMethod("TrySmoothStep",Flags);
    static readonly FieldInfo Walking=typeof(RpgLocomotionController).GetField("walking",Flags);
    static readonly Vector2Int[] Steps={
      new Vector2Int(0,1),new Vector2Int(1,0),new Vector2Int(0,-1),new Vector2Int(-1,0),
      new Vector2Int(1,1),new Vector2Int(1,-1),new Vector2Int(-1,-1),new Vector2Int(-1,1)};
    const float Grid=.32f;
    struct Spot { public Vector2Int prior;public RaycastHit floor;public float cost; }
    public static bool Walk(RpgLocomotionController loc,Vector3 dest,Func<Vector3,bool> within,Action<string> log){
      var from=loc.PlayerFloorPosition;if(within(from))return true;
      Physics.SyncTransforms();object[] f={from,default(RaycastHit),null};
      if(!(bool)Floor.Invoke(loc,f)){log("no starting floor "+from);return false;}
      var ground=(RaycastHit)f[1];var root=Vector2Int.zero;var spaces=new Dictionary<Vector2Int,Spot>{{root,new Spot{floor=ground}}};
      var queue=new SortedSet<(float,int,Vector2Int)>(Comparer<(float,int,Vector2Int)>.Create((a,b)=>a.Item1==b.Item1?a.Item2.CompareTo(b.Item2):a.Item1.CompareTo(b.Item1)));
      float Distance(Vector3 position)=>Vector2.Distance(new Vector2(position.x,position.z),new Vector2(dest.x,dest.z));
      const float tolerance=.016f;int unique=0;queue.Add((Distance(from),unique,root));
      var closed=new HashSet<Vector2Int>();var blocked=new Dictionary<string,int>();var best=ground.point;float closest=Distance(from);
      while(queue.Count>0&&closed.Count<23000){
        var item=queue.Min;queue.Remove(item);var key=item.Item3;if(!closed.Add(key))continue;
        var row=spaces[key];if(within(row.floor.point)){
           var path=new List<Vector3>();var v=key;while(v!=root){path.Add(spaces[v].floor.point);v=spaces[v].prior;}path.Reverse();
           bool prior=(bool)Walking.GetValue(loc);try {
             Walking.SetValue(loc,true);float meters=0;
             foreach(var at in path){var delta=at-loc.PlayerFloorPosition;delta.y=0;object[] a={delta,Vector3.zero,null};
               if(!(bool)Step.Invoke(loc,a)){log("execution blocked at "+loc.PlayerFloorPosition+" toward "+at+" "+a[2]);return false;}
               meters+=((Vector3)a[1]).magnitude;
             }
             log("walk OK "+from+" -> "+loc.PlayerFloorPosition+" distance="+meters.ToString("F2")+"m checkedSteps="+path.Count);return within(loc.PlayerFloorPosition);
           }finally{Walking.SetValue(loc,prior);}
        }
        foreach(var shift in Steps){
          var next=key+shift;if(closed.Contains(next))continue;
          Vector3 push=new Vector3(shift.x*Grid,0,shift.y*Grid);var cost=row.cost+push.magnitude;
          if(spaces.TryGetValue(next,out var has)&&has.cost<=cost+tolerance)continue;
          var target=row.floor.point+push;
          if(target.x<Mathf.Min(from.x,dest.x)-9||target.x>Mathf.Max(from.x,dest.x)+9||target.z<Mathf.Min(from.z,dest.z)-9||target.z>Mathf.Max(from.z,dest.z)+9)continue;
          object[] a={row.floor,row.floor.point,push,0f,default(RaycastHit),default(RaycastHit),null};
          if(!(bool)Leg.Invoke(loc,a)){
            var other=((RaycastHit)a[5]).collider;var reason=other?CourtyardWalkChecks.Full(other.transform):(string)a[6]??"?";
            blocked.TryGetValue(reason,out var n);blocked[reason]=n+1;continue;
          }
          var floor=(RaycastHit)a[4];var remaining=Distance(floor.point);
          if(remaining<closest){closest=remaining;best=floor.point;}
          spaces[next]=new Spot{floor=floor,cost=cost,prior=key};queue.Add((cost+remaining,++unique,next));
        }
      }
      log("NO WALK PATH "+from+" -> "+dest+" nearest="+best+" gap="+closest.ToString("F2")+" tried="+closed.Count+" colliders="+string.Join(" | ",blocked.OrderByDescending(b=>b.Value).Take(6).Select(b=>b.Key+" ("+b.Value+")")));return false;
    }
}
