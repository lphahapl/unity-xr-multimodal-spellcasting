using System;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using NarutoVR.SealCombat;
using NarutoVR.SealCombat.Rpg;
using NarutoVR.SealCombat.Enemies;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class CourtyardFlowProbe {
    const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
    const string Key="CourtyardFlowProbe.";
    static readonly string Out=Environment.GetEnvironmentVariable("CH01_FLOW_OUT");
    static LinearRpgController p;static OpeningTrialChapter ch;
    static string last="";static double started,changed,givenAt;static int current=-1;
    static readonly List<string> lines=new List<string>();
    static readonly HashSet<string> observed=new HashSet<string>();
    static readonly HashSet<string> doors=new HashSet<string>();
    static Type handType;
    static double Now=>EditorApplication.timeSinceStartup;
    static bool solved,collected,seated,cleared;static int snapped;
    static CourtyardFlowProbe(){
        EditorApplication.playModeStateChanged+=s=>{
            if(!SessionState.GetBool(Key+"on",false))return;
            if(s==PlayModeStateChange.EnteredPlayMode){started=changed=Now;EditorApplication.update+=Tick;}
            if(s==PlayModeStateChange.EnteredEditMode){SessionState.SetBool(Key+"on",false);EditorApplication.Exit(SessionState.GetInt(Key+"code",1));}
        };
    }
    public static void Run(){
        if(!Application.dataPath.Contains("CH01-CourtyardRoutePlay-20261119"))throw new Exception("Must use independent test sandbox");
        string src="Assets/Scene/"+(Environment.GetEnvironmentVariable("CH01_FLOW_SCENE")??"Chapter01_Awakening")+".unity";
        var scene=EditorSceneManager.OpenScene(src);var p=Object.FindFirstObjectByType<LinearRpgController>();
        p.autoLoad=false;p.saveFileName="probe-mvc-flow-"+Guid.NewGuid().ToString("N")+".json";p.skills.voice.autoStartInEditor=false;
        foreach(var nar in Object.FindObjectsByType<NarrationController>(FindObjectsInactive.Include,FindObjectsSortMode.None))nar.GetComponent<AudioSource>().pitch=2.75f;
        // This isolated scene copy is independent of both the user's scene and the existing save.
        EditorSceneManager.SaveScene(scene,"Assets/Scene/Probe_CourtyardFlow.unity");
        SessionState.SetBool(Key+"on",true);SessionState.SetInt(Key+"code",1);
        File.WriteAllText(Out,"source "+src+"; test save "+p.saveFileName+"\n");
        EditorApplication.EnterPlaymode();
    }
    static void Log(string s){lines.Add(s);File.AppendAllText(Out,DateTimeOffset.Now.ToString("o")+" "+s+"\n");}
    static void Need(bool condition,string msg){if(!condition)throw new Exception(msg);}
    static void Once(string k,Action action){if(observed.Add(k))action();}
    static bool Inside(BoxCollider area,Vector3 at){
        var v=area.transform.InverseTransformPoint(at)-area.center;
        var h=area.size*.5f;
        return Mathf.Abs(v.x)<=h.x && Mathf.Abs(v.y)<=h.y && Mathf.Abs(v.z)<=h.z;
    }
    static void ToArea(BoxCollider area){
        if(!area||Inside(area,p.locomotion.PlayerFloorPosition))return;
        var via=area.transform.TransformPoint(area.center);
        Need(CourtyardWalkDriver.Walk(p.locomotion,via,at=>Inside(area,at),s=>Log("walk "+area.name+" "+s)),"unreachable objective "+area.name);
    }
    static void WithinReach(Transform feature,float radius){
        var point=feature.position;bool near(Vector3 at)=>Vector2.Distance(new Vector2(point.x,point.z),new Vector2(at.x,at.z))<=radius;
        if(near(p.locomotion.PlayerFloorPosition))return;
        Need(CourtyardWalkDriver.Walk(p.locomotion,point,near,s=>Log("approach "+feature.name+" "+s)),"cannot approach "+feature.name);
    }
    static void TargetProjectile(SkillTrainingTarget target){
        var hit=target.GetComponentInChildren<Collider>();Need(hit,"Missing target collider");
        var fx=p.skills.effects;var head=p.locomotion.head;var goal=hit.bounds.center;
        var dir=(goal-head.position).normalized;var origin=head.position+dir*.36f-Vector3.up*.16f;
        var orig=fx.WristPoseOverride;
        try {
            fx.WristPoseOverride=left=>new Pose(origin,Quaternion.LookRotation(dir));
            float before=p.Player.Mana;
            bool ok=p.DebugCast("fireball");
            if(!ok){Once("denied"+target.name,()=>Log("cast temporarily rejected "+target.name+" mana="+before));return;}
            var held=fx.HeldThrowPosition;
            fx.GetType().GetMethod("Launch",Flags).Invoke(fx,new object[]{(goal-held).normalized});
            Log("paid fireball; synthetic release vector from "+held+" toward "+target.name+" "+goal+" range="+Vector3.Distance(goal,held).ToString("F2")+" mana="+before.ToString("F1")+"->"+p.Player.Mana.ToString("F1"));
        }finally{fx.WristPoseOverride=orig;}
    }
    static void Toggle(){
        var m=p.wristMenu;double now=Time.realtimeSinceStartupAsDouble;var h=p.locomotion.head;
        var f=new PlayerHandObservation(){leftValid=true,rightValid=true,mountValid=true,leftObserved=now,rightObserved=now,leftRotation=Quaternion.identity,mountRotation=Quaternion.identity,headForward=h.forward,headPosition=h.position,leftWrist=h.position+h.forward*.32f-Vector3.up*.15f,rightTip=h.position+h.forward*.28f};
        // Inject the hardware switch edge after pose preparation, retaining the wrist state/controller and its actual event.
        m.GetType().GetField("preparedAt",Flags).SetValue(m,now);
        m.GetType().GetField("deviceToggle",Flags).SetValue(m,true);m.Tick(f,p,false,now);
    }
    static void Hand(Action<Action<Vector3,bool>> fn){
        if(handType==null)handType=typeof(NarutoVR.SealCombat.Editor.OpeningRouteCheckpointChecks).GetNestedType("PuzzleHand",BindingFlags.NonPublic);
        var h=(IDisposable)Activator.CreateInstance(handType,Flags,null,new object[]{p,ch.puzzle},null);
        try {var m=handType.GetMethod("Move");fn((at,pressed)=>m.Invoke(h,new object[]{at,pressed}));}finally{h.Dispose();}
    }
    static void Align(){
        var pu=ch.puzzle;WithinReach(pu.outerDisc,.84f);Hand(move=>{
            void Turn(Transform disc,Transform grip){
                var v=grip.position;var basePos=pu.outerDisc.position;var degrees=Mathf.DeltaAngle(disc.localEulerAngles.y,0);
                var rot=Quaternion.AngleAxis(degrees,pu.outerDisc.parent.up);
                move(v,false);move(v,true);move(basePos+rot*(v-basePos),true);move(basePos+rot*(v-basePos),false);
            }
            Turn(pu.outerDisc,pu.outerHandle);Turn(pu.innerDisc,pu.innerHandle);
        });
    }
    static void KeepSlotVisible(){
        for(var t=ch.puzzle.slot.transform;t;t=t.parent)if(!t.gameObject.activeSelf)t.gameObject.SetActive(true);
    }
    static void End(bool ok,string why){
        EditorApplication.update-=Tick;Log((ok?"PASS ":"FAIL ")+why);
        SessionState.SetInt(Key+"code",ok?0:1);EditorApplication.ExitPlaymode();
    }
    static int lastFrame=-1;
    static void Tick(){
        if(!EditorApplication.isPlaying || lastFrame==Time.frameCount)return;lastFrame=Time.frameCount;
        try {
            if(Now-started>600)throw new Exception("Run timed out");
            if(!p)p=Object.FindFirstObjectByType<LinearRpgController>();
            if(!p || !p.IsReady){if(Now-started>75)throw new Exception("Player init "+(p?p.Status:"absent"));return;}
            if(!ch){
                ch=(OpeningTrialChapter)p.chapter;
                ch.puzzle.Solved+=()=>{solved=true;Log("puzzle solved by physical turn");};
                ch.puzzle.Collected+=()=>{collected=true;Log("leaf collected");};
                ch.wristSlot.OnPointReached+=(o,i)=>{if(o==ch.puzzle.leaf)snapped++;};
                ch.wristSlot.OnSnapCompleted+=o=>{if(o==ch.puzzle.leaf){seated=true;Log("slot completed points="+snapped);}};
                ch.encounter.Cleared+=()=>{cleared=true;Log("encounter clear");};
                p.skills.effects.ProjectileHitTarget+=t=>Log("skill projectile collision "+t.name+" hitCount="+t.HitCount);
                Time.timeScale=2;Application.targetFrameRate=50;
                Log("ready, stage count "+p.StageCount);
            }
            if(p.CampaignComplete){
                Need(current==p.StageCount-1 && solved&&collected&&seated&&snapped==3&&cleared,"Missing baseline progression observables");
                CourtyardWalkChecks.Audit(p,s=>Log("walk "+s));var before=p.CaptureProgressSnapshot();Need(File.Exists(p.SavePath),"No automatic save");
                Need(p.RestoreCheckpoint(),"restore failed "+p.Status);var after=p.CaptureProgressSnapshot();
                Need(p.CampaignComplete && after.completedStageIds.SequenceEqual(before.completedStageIds) && after.items.Any(it=>it.itemId==ch.puzzle.leafId && it.activated) && p.locomotion.CurrentNodeId==ch.finalCheckpoint.nodeId,"Restored state mismatch");
                End(true,"All "+p.StageCount+" stages naturally completed, final save restored; checkpoint "+p.locomotion.CurrentNodeId+", completed="+after.completedStageIds.Count+", activated leaf="+ch.puzzle.leafId);return;
            }
            int index=p.StageIndex;var section=ch.sections.Single(s=>s.stage.stageId==p.StageAt(index).stageId);
            if(index!=current){
                Need(index==current+1,"Stage jump "+current+" -> "+index);
                current=index;changed=Now;Log("stage "+index+" "+section.stage.stageId+" floor="+p.locomotion.PlayerFloorPosition);
                foreach(var s in ch.sections.Where(s=>s.doorOpenedOnCompletion)){
                    bool complete=p.Model.Chapter.IsComplete(s.stage.stageId);
                    Need(s.doorOpenedOnCompletion.activeSelf!=complete,"door conflicts with stage "+s.stage.stageId);
                    if(complete && doors.Add(s.stage.stageId))Log("door opened "+s.doorOpenedOnCompletion.name+" after "+s.stage.stageId);
                }
            }
            var entry=section.startCondition as ReachAreaChapterObjective;if(entry && !entry.IsComplete)ToArea(entry.area);
            if(section.lines.Any(x=>x.action==OpeningAction.ClearRoom)&&!ch.encounter.PlayerInside)ToArea(ch.encounter.area);
            var step=section.narration.CurrentStep;
            var lesson=step==null?null:section.lines.Single(ln=>ln.id==step.LineId);var desc=section.stage.stageId+"/"+(step==null?"entry":step.Index+" "+lesson.id+" "+lesson.action);
            if(desc!=last){last=desc;changed=Now;givenAt=0;Log(desc);}
            if(Now-changed>50)throw new Exception("stalled "+desc+" narration="+section.narration.Status+" player="+p.Status+" locomotion="+p.locomotion.Status+" encounter="+ch.encounter.Status+" puzzle="+ch.puzzle.outerDisc.localEulerAngles+"/"+ch.puzzle.innerDisc.localEulerAngles+" hand="+p.Input.InteractionOwnsHand);
            if(section.alignDiscs && !solved && step!=null && Now-givenAt>1.3){givenAt=Now;Align();}
            if(step==null || step.OperationDone)return;
            var ln=lesson;
            switch(ln.action){
                case OpeningAction.OpenWrist:
                    if(Now-givenAt>.35){givenAt=Now;Toggle();}break;
                case OpeningAction.StopAtMarker:
                    p.wristMenu.ClosePanel();ToArea(ln.area);break;
                case OpeningAction.ReachArea:
                    if(ln.operationTarget is ReachAreaChapterObjective a)ToArea(a.area);else ToArea(ln.area);break;
                case OpeningAction.HitTarget:
                    if(Now-givenAt>1){givenAt=Now;TargetProjectile(ln.target);}break;
                case OpeningAction.RecoverMana: Once("startingMana",()=>Log("natural mana recovery starts at "+p.Player.Mana+" / "+p.Player.MaxMana));break;
                case OpeningAction.AbsorbBolt:
                    if(Now-givenAt>1 && p.PlayerView.ShieldPoints<ch.defense.damage){givenAt=Now;var ok=p.DebugCast("buff.voice");Log("shield cast via DebugCast="+ok+" points="+p.PlayerView.ShieldPoints);}break;
                case OpeningAction.Retreat:
                    if(Now-givenAt>.6){givenAt=Now;p.DebugMove(true,Vector2.down);}break;
                case OpeningAction.ClearRoom:
                    if(ch.encounter.HasStarted && !ch.encounter.IsComplete && Now-givenAt>.4){
                        givenAt=Now; foreach(var e in Object.FindObjectsByType<EnemyObj>(FindObjectsSortMode.None))
                            if(e.isActiveAndEnabled && ch.encounter.area.bounds.Contains(e.transform.position)){Once("enemy."+e.GetInstanceID(),()=>Log("live encounter enemy "+e.name+" at "+e.transform.position+"; submitting synthetic combat hit to EnemyObj.ReceiveHit"));e.ReceiveHit("probe."+Guid.NewGuid(),100,25,null,p.locomotion.head);}
                    }break;
                case OpeningAction.CollectLeaf:
                    if(!collected && Now-givenAt>.25){givenAt=Now;var pu=ch.puzzle;Hand(m=>{var v=pu.prizeRest.position;m(v,false);m(v,true);m(v,false);});}break;
                case OpeningAction.InsertLeaf:
                    KeepSlotVisible();if(!seated && !ch.puzzle.slot.SnappedObject && Now-givenAt>.4){
                        givenAt=Now;var pu=ch.puzzle;
                        Hand(m=>{var v=pu.leaf.transform.position;m(v,false);m(v,true);m(pu.slotEntry.position,true);m(pu.slotEntry.position+pu.slotEntry.right*.08f,false);}); if(pu.slot.SnappedObject==pu.leaf){Log("tracked wrist accepted release, production SnapZone Advance before visual tracking disappears; points="+pu.slot.PointCount);pu.slot.GetType().GetMethod("Advance",Flags).Invoke(pu.slot,new object[]{2f});} else Once("failedSeat",()=>Log("release not accepted: "+pu.slot.LastFailure+" active="+pu.slot.isActiveAndEnabled+" canInsert="+pu.GetType().GetField("canInsert",Flags).GetValue(pu)+" held="+p.Input.InteractionOwnsHand));
                    }break;
                case OpeningAction.VerifyWrist:
                    WithinReach(ch.puzzle.verifier,.72f);KeepSlotVisible();ch.puzzle.slot.transform.position=ch.puzzle.verifier.position;break;
            }
        }catch(Exception e){End(false,e.ToString());}
    }
}






