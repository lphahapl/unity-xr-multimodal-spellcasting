using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using NarutoVR.SealCombat.Rpg;
using Object=UnityEngine.Object;

public static class CourtyardWalkChecks {
    const BindingFlags Flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
    public static string Full(Transform t)=>t.parent?Full(t.parent)+"/"+t.name:t.name;
    static readonly MethodInfo Floor=typeof(RpgLocomotionController).GetMethod("TryFloor",Flags);
    static readonly MethodInfo Capsule=typeof(RpgLocomotionController).GetMethod("Capsule",Flags);
    static readonly MethodInfo Visible=typeof(RpgLocomotionController).GetMethod("Visible",Flags);
    static string Site(RpgLocomotionController loc,NavigationNode n,out Vector3 pos){
        pos=n.floorPosition;
        object[] a={pos,n.overrideLayers?n.floorLayers.value:loc.floorLayers.value,default(RaycastHit),null};
        if(!(bool)Floor.Invoke(loc,a))return "NO_FLOOR "+a[3];
        var floor=(RaycastHit)a[2];pos=floor.point;
        object[] c={floor,floor.point,Vector3.zero,Vector3.zero,0f};Capsule.Invoke(loc,c);
        var hits=Physics.OverlapCapsule((Vector3)c[2],(Vector3)c[3],(float)c[4], n.overrideLayers?n.obstacleLayers.value:loc.obstacleLayers.value,QueryTriggerInteraction.Ignore)
          .Where(h=>h.transform!=loc.rigRoot&&!h.transform.IsChildOf(loc.rigRoot)).ToArray();
        if(hits.Length>0)return "BLOCKED by "+string.Join(" | ",hits.Select(h=>Full(h.transform)+" "+h.GetType().Name+" center="+h.bounds.center+" size="+h.bounds.size))+"; floor="+Full(floor.collider.transform);
        if(Mathf.Abs(pos.y-n.floorPosition.y)>loc.targetFloorTolerance)return "GROUNDED AT WRONG HEIGHT "+pos.y+" / "+n.floorPosition.y+" by "+Full(floor.collider.transform);
        return "";
    }
    public static void Audit(LinearRpgController p,Action<string> feedback){
        Physics.SyncTransforms();var loc=p.locomotion;var nodes=Object.FindObjectsByType<NavigationNode>(FindObjectsSortMode.None);
        var sites=new Dictionary<NavigationNode,Vector3>();var initial=p.CheckpointAt(0);
        foreach(var n in nodes.OrderBy(k=>k.nodeId)){
            var status=Site(loc,n,out var at);if(status=="")sites.Add(n,at);
            if(status!=""||n.nodeId.StartsWith("opening."))feedback(n.nodeId+" authored="+n.floorPosition+" "+status);
        }
        if(!sites.ContainsKey(initial)){feedback("SPAWN BLOCKED "+initial.nodeId);return;}
        var reached=new HashSet<NavigationNode>{initial};var q=new Queue<NavigationNode>();q.Enqueue(initial);
        while(q.Count>0){
            var n=q.Dequeue();foreach(var v in n.neighbors){
                if(!v||reached.Contains(v)||!sites.ContainsKey(v))continue;
                if(Mathf.Abs(sites[n].y-sites[v].y)>loc.maximumFloorStep)continue;
                if(!(bool)Visible.Invoke(loc,new object[]{sites[n],sites[v],v.overrideLayers?v.obstacleLayers.value:loc.obstacleLayers.value}))continue;
                reached.Add(v);q.Enqueue(v);
            }
        }
        feedback("reachable navigation "+reached.Count+"/"+nodes.Length+" landingOK="+sites.Count+"; named missing="+string.Join(",",nodes.Where(n=>n.nodeId.StartsWith("opening.")&&!reached.Contains(n)).Select(n=>n.nodeId)));
        var c=(OpeningTrialChapter)p.chapter;
        foreach(var row in c.sections){
           var a=row.startCondition as ReachAreaChapterObjective;
           if(a&&a.area)feedback("entry "+row.stage.stageId+" = "+a.area.bounds.center);
           foreach(var line in row.lines){if(line.area)feedback("task "+line.id+" = "+line.area.bounds.center);}
        }
        feedback("final physically reachable in authored nav graph="+reached.Contains(c.finalCheckpoint)+" final="+c.finalCheckpoint.nodeId);
    }
    public static void Run(){
       var src="Assets/Scene/"+(Environment.GetEnvironmentVariable("CH01_FLOW_SCENE")??"Chapter01_Courtyard")+".unity";
       EditorSceneManager.OpenScene(src);var p=Object.FindFirstObjectByType<LinearRpgController>();
       var path=Environment.GetEnvironmentVariable("CH01_FLOW_OUT");File.WriteAllText(path,"static physics "+src+"\n");
       Audit(p,s=>File.AppendAllText(path,s+"\n"));EditorApplication.Exit(0);
    }
}
