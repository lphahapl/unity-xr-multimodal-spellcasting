using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using NarutoVR.SealCombat.Rpg;
using Object=UnityEngine.Object;

[InitializeOnLoad]
public class CourtyardColdRestore {
    const string Key="CourtyardColdRestoreProbe";
    static readonly string Out=Environment.GetEnvironmentVariable("CH01_FLOW_OUT");
    static double deadline;
    static CourtyardColdRestore(){
        EditorApplication.playModeStateChanged+=mode=>{
            if(!SessionState.GetBool(Key,false))return;
            if(mode==PlayModeStateChange.EnteredPlayMode){deadline=EditorApplication.timeSinceStartup+90;EditorApplication.update+=Check;}
            if(mode==PlayModeStateChange.EnteredEditMode){SessionState.SetBool(Key,false);EditorApplication.Exit(SessionState.GetInt(Key+"code",1));}
        };
    }
    static void End(bool ok,string reason){
       EditorApplication.update-=Check;File.AppendAllText(Out,DateTimeOffset.Now.ToString("o")+" "+(ok?"PASS ":"FAIL ")+reason+"\n");
       SessionState.SetInt(Key+"code",ok?0:1);EditorApplication.ExitPlaymode();
    }
    public static void Run(){
       if(!Application.dataPath.Contains("CH01-CourtyardRoutePlay-20261119"))throw new InvalidOperationException("isolated project required");
       string path=Environment.GetEnvironmentVariable("CH01_FLOW_INPUT");var text=File.ReadAllText(path);
       var save=Regex.Match(text,@"test save (probe-mvc-flow-[a-fA-F0-9]{32}\.json)").Groups[1].Value;
       if(save.Length==0||!text.Contains("PASS All "))throw new InvalidOperationException("prior completed independent flow required");
       string src="Assets/Scene/"+Environment.GetEnvironmentVariable("CH01_FLOW_SCENE")+".unity";
       var sc=EditorSceneManager.OpenScene(src);var p=Object.FindFirstObjectByType<LinearRpgController>();
       p.autoLoad=true;p.saveFileName=save;p.skills.voice.autoStartInEditor=false; 
       EditorSceneManager.SaveScene(sc,"Assets/Scene/Probe_CourtyardColdRestore.unity");
       SessionState.SetBool(Key,true);File.WriteAllText(Out,"cold process; scene "+src+"; existing save "+save+"\n");
       EditorApplication.EnterPlaymode();
    }
    static int phase, sceneHandle;
    static double sampled;
    static float gameTime;
    static Quaternion ringOrientation,shellOrientation;
    static Transform ring,shell;
    static NarutoVR.SceneArt.SceneTravelGate gate;
    static bool requiredWalks=true;
    static string restored="";
    static void Note(string s)=>File.AppendAllText(Out,DateTimeOffset.Now.ToString("o")+" "+s+"\n");
    static bool Travel(LinearRpgController p,string name,float x,float z,float radius){
        var target=new Vector3(x,-.03f,z);
        bool Fits(Vector3 pos)=>Vector2.Distance(new Vector2(pos.x,pos.z),new Vector2(x,z))<=radius;
        bool passed=CourtyardWalkDriver.Walk(p.locomotion,target,Fits,msg=>Note("walk "+name+" "+msg));
        Note("destination "+name+" reachable="+passed+" feet="+p.locomotion.PlayerFloorPosition);
        return passed;
    }
    static void Check(){
        try {
            if(!EditorApplication.isPlaying)return;
            var p=Object.FindFirstObjectByType<LinearRpgController>();
            if(!p||!p.IsReady){if(EditorApplication.timeSinceStartup>deadline)End(false,"init timeout "+(p?p.Status:"none"));return;}
            var chapter=(OpeningTrialChapter)p.chapter;
            if(phase==0){
               var snap=p.CaptureProgressSnapshot();if(snap==null)return;
               bool doors=chapter.sections.Where(x=>x.doorOpenedOnCompletion).All(x=>!x.doorOpenedOnCompletion.activeSelf);
               bool leaf=snap.items.Any(it=>it.itemId==chapter.puzzle.leafId&&it.activated);
               var landing=p.locomotion.CurrentNodeId;
               bool ok=p.CampaignComplete&&snap.completedStageIds.Count==p.StageCount&&landing==chapter.finalCheckpoint.nodeId&&doors&&leaf&&chapter.puzzle.IsSeated;
               restored="fresh process loaded disk; chapterComplete="+p.CampaignComplete+" completed="+snap.completedStageIds.Count+" checkpoint="+landing+" leafActivated="+leaf+" wristSeated="+chapter.puzzle.IsSeated+" allGatesOpen="+doors+" saveBytes="+new FileInfo(p.SavePath).Length;
               Note(restored);if(!ok){End(false,restored);return;}
               if(Environment.GetEnvironmentVariable("CH01_FLOW_SCENE")!="Chapter01_Courtyard"){End(true,restored);return;}
               requiredWalks &= Travel(p,"pavilion front door",17.35f,20.45f,.3f);
               requiredWalks &= Travel(p,"around dais west aisle",15.62f,18.04f,.4f);
               requiredWalks &= Travel(p,"pavilion back door",17.35f,14.05f,.44f);
               var motion=Object.FindObjectsByType<NarutoVR.SceneArt.ArmillaryRingMotion>(FindObjectsSortMode.None).OrderBy(m=>Vector3.Distance(m.transform.position,new Vector3(17.35f,2,17.55f))).First();
               ring=motion.IntactRing;
               var housing=Object.FindObjectsByType<Transform>(FindObjectsSortMode.None).Where(t=>t.name=="StarShell").OrderBy(t=>Vector3.Distance(t.position,motion.transform.position)).First();
               var mesh=housing.GetComponentsInChildren<MeshRenderer>(true).FirstOrDefault(r=>r.name.Contains("LOD0"));shell=mesh?mesh.transform:housing;
               ringOrientation=ring.rotation;shellOrientation=shell.rotation;
               Note("armed ring="+CourtyardWalkChecks.Full(ring)+" shell="+CourtyardWalkChecks.Full(shell)+" authoredSpeed="+motion.DegreesPerSecond);
               requiredWalks &= Travel(p,"cliff stone gate",17.35f,-15.4f,.24f);
               gate=Object.FindObjectsByType<NarutoVR.SceneArt.SceneTravelGate>(FindObjectsSortMode.None).OrderBy(g=>Vector3.Distance(g.transform.position,new Vector3(17.35f,1,-15.4f))).First();
               var box=gate.GetComponent<BoxCollider>();var local=box.transform.InverseTransformPoint(p.locomotion.head.position)-box.center;var ext=box.size*.5f;
               bool inside=Mathf.Abs(local.x)<=ext.x && Mathf.Abs(local.y)<=ext.y && Mathf.Abs(local.z)<=ext.z;
               Note("gate="+CourtyardWalkChecks.Full(gate.transform)+" headInsideTrigger="+inside+" activeTrigger="+box.isTrigger+" destination='"+gate.DestinationScene+"' loadingEnabled="+gate.LoadEnabled);
               requiredWalks &= inside && box.isTrigger && !gate.LoadEnabled && string.IsNullOrWhiteSpace(gate.DestinationScene);
               sceneHandle=UnityEngine.SceneManagement.SceneManager.GetActiveScene().handle;
               sampled=EditorApplication.timeSinceStartup;gameTime=Time.time;phase=1;return;
            }
            if(EditorApplication.timeSinceStartup-sampled<1.24)return;
            float ringDelta=Quaternion.Angle(ringOrientation,ring.rotation),shellDelta=Quaternion.Angle(shellOrientation,shell.rotation);
            bool same=sceneHandle==UnityEngine.SceneManagement.SceneManager.GetActiveScene().handle;
            Note("rotation sampled realSeconds="+(EditorApplication.timeSinceStartup-sampled).ToString("F3")+" gameSeconds="+(Time.time-gameTime).ToString("F3")+" movingRingDegrees="+ringDelta.ToString("F3")+" staticShellDegrees="+shellDelta.ToString("F3")+" sameSceneAfterEnteringGate="+same);
            requiredWalks &= ringDelta>.4f && shellDelta<.05f && same;
            requiredWalks &= Travel(p,"R06 return",17.4f,22.28f,.5f);
            requiredWalks &= Travel(p,"tool workshop interior",25.75f,28.65f,.7f);
            requiredWalks &= Travel(p,"east workshop interior",6.3f,46.4f,.7f);
            requiredWalks &= Travel(p,"west workshop interior",-5.75f,44.6f,.7f);
            End(requiredWalks,restored+"; required post-chapter walks and live ring/shell/gate="+requiredWalks);
        }catch(Exception e){End(false,e.ToString());}
    }
}


