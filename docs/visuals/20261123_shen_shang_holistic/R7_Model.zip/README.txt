Shen Shang R7. Full-body A-pose 3D visual review model. Units: meters. All materials and textures are embedded. Decode GLB with a glTF 2.0 viewer supporting KHR_draco_mesh_compression, e.g. Blender 5.2. This lightweight review copy derives from the source workbench GLB. Geometry and texture sampling have been reduced for transfer.
Editable source SHA256: AFEF1640D35BDE6E848BBBA11CD14040AF51871730EAC0C3250F6E1797122328
Workbench GLB SHA256: 3e28f6b9d106930ea734d82f3ed07758b7c4e34ae04e68bcc0f91c66541094c4
Review GLB SHA256: df4d64bc19882952cd811015c0a3c1f7545270b6a8507376a180e7b8e0fb70ae
