Shen Shang R7. Display correction to the reviewed full-body A-pose asset. Only the scalp-cap base colour texture's vertical addressing changes from repeat to clamp at the texture edge. The embedded geometry, texture pixels and posing are byte-identical to their corresponding accepted R7 GLBs. In the first ZIP thumbnails the reduced 3D model itself is rendered using the native scene cameras and studio lights. The interactive model uses compressed glTF 2.0 (KHR_draco_mesh_compression).
Native R7 SHA256: AFEF1640D35BDE6E848BBBA11CD14040AF51871730EAC0C3250F6E1797122328
Workbench corrected GLB SHA256: 50cbf27e9e32d849a392e9848188acd3412f82f1b560412f90533836c85d8b3e
Archive model SHA256: a339a8bd7c07264fd4bece4ce01f3d5921b33ba022c20cfda103fa5f0f245424
Previously approved archive SHA256: 69be1a19f2ac1b7436915e6a39e7713bd86d43193b96051887c72587358e5f94
