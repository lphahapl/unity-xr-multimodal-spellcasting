"""Create two packed data textures from tiny skin-only samples and analytic relief; never project a portrait."""
from pathlib import Path
import json, numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, map_coordinates
root=Path('D:/UnityProjects/NarutoVR/docs/visuals/20261121_shen_shang_character')
out=Path(__file__).parent
rng=np.random.default_rng(633229);n=1024
samples={'01':[(462,124,481,136),(531,123,546,136),(484,77,501,90)],'02':[(365,79,376,93),(388,79,397,92)],'03':[(660,324,702,350),(699,340,719,367),(795,235,825,252)]}
notes={};patches=[]
for k,rects in samples.items():
    src=np.array(Image.open(next(root.glob(k+'*.png'))).convert('RGB'),float)/255
    notes[k]=[]
    for x,y,X,Y in rects:
        rgb=src[y:Y,x:X];notes[k].append({'rect':[x,y,X,Y],'median_sRGB_255':np.round(np.median(rgb,axis=(0,1))*255).astype(int).tolist()})
        gray=rgb@np.array([.299,.587,.114]);h=gray-gaussian_filter(gray,2.6)
        # Learn only the statistics of pigment flecks from the artwork. Random phases erase feature positions.
        patches.append(h)
def unit(x):return (x-x.mean())/(x.std()+1e-9)
def band(lo,hi):
    a=rng.normal(size=(n,n))
    return unit(gaussian_filter(a,lo,mode='wrap')-gaussian_filter(a,hi,mode='wrap'))
# Isotropic reference spectrum. No literal facial feature or source-patch pixels are copied into the map.
bins=np.linspace(0.,.72,24);pows=np.zeros(23);nums=np.zeros(23)
for h in patches:
    ps=np.abs(np.fft.fft2(h))**2/h.size
    fy,fx=np.meshgrid(np.fft.fftfreq(h.shape[0]),np.fft.fftfreq(h.shape[1]),indexing='ij')
    r=(fx*fx+fy*fy)**.5
    pows+=np.histogram(r,bins,weights=ps)[0];nums+=np.histogram(r,bins)[0]
freq=np.fft.fftfreq(n);rr=(freq[:,None]**2+freq[None,:]**2)**.5
spectrum=np.interp(rr,(bins[1:]+bins[:-1])/2,pows/np.maximum(nums,1));spectrum[0,0]=0
detail=unit(np.fft.ifft2(np.fft.fft2(rng.normal(size=(n,n)))*np.sqrt(np.maximum(spectrum,0))).real)
# Blue-noise-like irregular pores with mixed diameters and restrained raised rims.
pores=np.zeros((n,n));rim=np.zeros((n,n))
for count,sigma,ratio in [(4200,.82,1.4),(2500,1.2,1.5),(650,1.7,1.4)]:
    v=np.zeros((n,n));yy=rng.integers(0,n,count);xx=rng.integers(0,n,count)
    np.add.at(v,(yy,xx),rng.uniform(.65,1.1,count))
    pores+=gaussian_filter(v,(sigma*ratio,sigma),mode='wrap')*(2*np.pi*sigma*sigma*ratio)
    rim+=gaussian_filter(v,(sigma*ratio*1.7,sigma*1.7),mode='wrap')*(2*np.pi*sigma*sigma*ratio)
freckle=np.zeros((n,n)); ids=rng.integers(0,n,(2,170));np.add.at(freckle,tuple(ids),rng.uniform(.4,1,170));freckle=gaussian_filter(freckle,2.2,mode='wrap')*30
red=.52+.084*band(5,16)+.031*detail+.035*band(22,48)-.39*freckle
green=.54+.22*rim-.34*pores+.016*detail+.025*band(2.2,5)
blue=.51+.095*band(3,12)+.04*detail+.075*pores
img=np.stack([red,green,blue],2);Image.fromarray((np.clip(img,0,1)*255+.5).astype('uint8')).save(out/'Shen_SkinMicrostructure.png')
(out/'skin_reference_samples.json').write_text(json.dumps(notes,indent=2),encoding='utf8')

