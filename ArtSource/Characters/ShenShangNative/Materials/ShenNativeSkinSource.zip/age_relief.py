"""Native local skin detailing in millimetre units. No image of a face is sampled here."""
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
out=Path(__file__).parent;N=1536
x=np.linspace(-.09,.09,N)[None,:];z=np.linspace(1.652,1.468,N)[:,None]
height=np.zeros((N,N));pig=np.zeros_like(height);oil=np.zeros_like(height);rng=np.random.default_rng(11904)
def crease(distance,w,gate,strength,hue):
    global height,pig,oil
    q=distance/w;val=np.exp(-.5*q*q)*gate
    # The raised shoulder is much broader and shallower than the indentation.
    shoulder=gate*(.18*np.exp(-.5*((q-1.7)/1.05)**2)+.12*np.exp(-.5*((q+1.8)/1.15)**2))
    height+=strength*(-val+shoulder);pig-=hue*val;oil+=.03*val
for side in [-1,1]:
    u=x*side
    # Upper medial brow compresses in two separate directions. The ridges stop before the hairline.
    bottom=1.5993+(side>0)*.0008;length=.0162 if side<0 else .0131;t=np.clip((z-bottom)/length,0,1)
    pos=(.0022 if side<0 else .0034)+.0013*np.sin(np.pi*t*.85)+t*t*(.0022 if side<0 else .0012)+.00036*np.sin(4.5*t+side)
    gate=((z>bottom)&(z<bottom+length))*np.sin(np.pi*t)**.96
    if side>0:gate=gate*(.70+.30*np.cos(6*t)**2)
    crease(u-pos,.00070+.00030*np.sin(np.pi*t),gate,.28 if side<0 else .23,.107 if side<0 else .088)
    # Nasal wing to outer mouth, strong only at its origin and fading through a wide cheek to the corner.
    start=1.5492+(side<0)*.0008;length=.029 if side<0 else .0275;t=np.clip((start-z)/length,0,1)
    center=.0176+.0084*np.sin(t*np.pi*.62)+.0016*t+.00032*np.sin(7*t+side)
    gate=((z<start)&(z>start-length))*np.sin(np.pi*t)**.70*(1-.55*t)
    crease(u-center,.00084+.00061*t,gate,.18 if side<0 else .17,.075)
    broad=gate*np.exp(-.5*((u-center-.0014)/.0021)**2)
    pig-=.018*broad
    for i,(start,end,base,sag,width,amp) in enumerate([(.017,.047,1.5834,.0034,.00031,.090),(.025,.050,1.5787,.0020,.00029,.064),(.042,.055,1.5841,.0004,.00027,.065)]):
        t=np.clip((u-start)/(end-start),0,1)
        line=base-sag*np.sin(np.pi*t)+(i==2)*.003*t+.00030*np.sin(t*11+side*i)
        gate=(u>start)*(u<end)*np.sin(np.pi*t)**1.25*(.66+.34*np.sin(10*t+1.4*i)**2)
        crease(z-line,width,gate,amp,.025)
    # Sparse asymmetric old sunlight flecks; a few resolving at 600–900 px portrait distance.
    for idx in range(21):
        qx=rng.uniform(.028,.062);qz=rng.uniform(1.551,1.575)-max(0,qx-.053)*.25
        sx=rng.uniform(.00027,.00105);sz=sx*rng.uniform(.65,1.15)
        dist=((u-qx)/sx)**2+((z-qz)/sz)**2
        spot=np.exp(-.5*dist)
        pig-=spot*rng.uniform(.055,.195);oil+=.017*spot
    # Low-frequency small irregular groups do not compete with the cheekplane.
    for idx in range(5):
        qx=rng.uniform(.033,.058);qz=rng.uniform(1.555,1.574)
        spot=np.exp(-.5*(((u-qx)/rng.uniform(.0014,.0036))**2+((z-qz)/rng.uniform(.0016,.0030))**2))
        pig-=rng.uniform(.014,.041)*spot
data=np.stack([.5+pig,.5+height,.5+oil],2)
Image.fromarray(np.uint8(np.rint(np.clip(data,0,1)*255))).save(out/'Shen_FacialMicrofolds.png')

