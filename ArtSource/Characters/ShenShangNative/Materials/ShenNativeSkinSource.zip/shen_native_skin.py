"""Editable native Blender skin for Shen Shang. Call apply_skin(head_object) or apply_skin([head, ears, lids]).
The shader packs its two data textures. It never projects source portraits or paints eyes, lips, brows, hair or whiskers.
"""
from pathlib import Path
import numpy as np
import bpy

SKIN_NAME="Shen_Skin_Dermis"
ATTR_TINT="Shen_DermalColor"
ATTR_ROUGH="Shen_Dryness"
ATTR_PORES="Shen_PoreWeight"
ATTR_REST="Shen_DermalRestM"
ATTR_FOLDS="Shen_FoldProjection"
ATTR_FRONT="Shen_FrontalSkin"
ATTR_PIGMENT="Shen_SunExposure"
SOURCE=Path(__file__).resolve().parent if "__file__" in globals() else Path(bpy.path.abspath("//"))

def srgb_linear(rgb):
    val=np.clip(np.asarray(rgb,float)/255,0,1)
    return np.where(val<.04045,val/12.92,((val+.055)/1.055)**2.4)

def fields(obj):
    mesh=obj.data
    loc=np.empty(len(mesh.vertices)*3,np.float32);mesh.vertices.foreach_get("co",loc)
    m=np.asarray(obj.matrix_world);pts=loc.reshape(-1,3)@m[:3,:3].T+m[:3,3]
    x,y,z=pts.T;ax=np.abs(x);n=len(x)
    def exp3(cx,cy,cz,sx,sy,sz,sym=True):
        u=ax if sym else x
        return np.exp(-.5*(((u-cx)/sx)**2+((y-cy)/sy)**2+((z-cz)/sz)**2))
    def tint(rgb,weight):
        nonlocal col
        col+=np.asarray(rgb)[None,:]*np.asarray(weight)[:,None]
    # The diffuse baseline sits between the shaded and lit cheek samples from the two neutral design plates.
    col=np.empty((n,3));col[:]=[145.,100.,62.]
    cheek=exp3(.046,-.067,1.564,.020,.028,.017)
    cheek_outer=exp3(.055,-.050,1.552,.016,.028,.018)
    eye=exp3(.030,-.079,1.580,.014,.017,.0048)
    temple=exp3(.059,-.049,1.596,.013,.026,.022)
    forehead=exp3(.020,-.070,1.619,.040,.034,.017)
    nose=exp3(.007,-.097,1.556,.014,.018,.013)
    perinasal=exp3(.017,-.090,1.549,.005,.011,.005)
    ears=exp3(.073,.002,1.575,.012,.037,.027)
    neck=exp3(.026,-.002,1.455,.041,.070,.033)
    upperlip=exp3(.012,-.084,1.535,.014,.017,.0045)
    chin=exp3(.017,-.075,1.499,.023,.020,.013)
    jaw=exp3(.050,-.038,1.518,.018,.033,.015)
    tip=exp3(0,-.108,1.555,.011,.010,.009)
    tint([7,1,-1],cheek);tint([1,-2,-3],cheek_outer)
    tint([-10,-8,-1],eye);tint([-6,-5,-2],temple)
    tint([1,5,1],forehead);tint([5,-1,-1],nose);tint([4,-3,-2],perinasal)
    tint([12,-1,1],ears);tint([-5,-5,-4],neck)
    # Soft low-saturation follicle undertone; hair groom supplies the actual stubble strands.
    beard=np.clip(upperlip*.60+chin*.67+jaw*.62,0,1)
    tint([-13,-8,-3],beard)
    # Gentle asymmetry in the epidermis, without an invented scar or a repeated freckle motif.
    tint([3,-2,-2],exp3(.042,-.077,1.564,.006,.012,.009,sym=False))
    tint([-3,-2,-1],exp3(-.049,-.069,1.571,.010,.018,.004,sym=False))
    rough=np.clip(.575+.045*cheek_outer+.026*beard+.018*eye-.032*forehead-.052*tip-.018*nose+.02*neck,.49,.66)
    pore=np.clip(.53+.37*cheek+.22*nose-.35*eye-.10*ears,.20,1)
    # Coordinates stick to the native head during future animation and do not depend on UV seam layout.
    rest=pts-[0.,0.,1.54]
    fold=np.column_stack(((x+.09)/.18,(z-1.468)/.184,np.zeros(n)))
    front=np.clip((-y-.025)/.031,0,1)
    def set_attr(name,typ,values):
        a=mesh.attributes.get(name) or mesh.attributes.new(name,typ,'POINT')
        prop={'FLOAT':'value','FLOAT_VECTOR':'vector','FLOAT_COLOR':'color'}[typ]
        a.data.foreach_set(prop,np.ascontiguousarray(values,dtype=np.float32).ravel())
    set_attr(ATTR_TINT,'FLOAT_COLOR',np.column_stack((srgb_linear(col),np.ones(n))))
    set_attr(ATTR_ROUGH,'FLOAT',rough);set_attr(ATTR_PORES,'FLOAT',pore)
    set_attr(ATTR_PIGMENT,'FLOAT',np.clip(.14+.72*cheek+.35*cheek_outer+.31*forehead+.35*temple-.32*eye-.1*neck,0,1))
    set_attr(ATTR_REST,'FLOAT_VECTOR',rest);set_attr(ATTR_FOLDS,'FLOAT_VECTOR',fold);set_attr(ATTR_FRONT,'FLOAT',front)
    mesh.update()

def make_material():
    mat=bpy.data.materials.get(SKIN_NAME) or bpy.data.materials.new(SKIN_NAME)
    if mat.get("ShenSkinVersion")==4:return mat
    mat["ShenSkinVersion"]=4;mat["Source"]="Native skin-only samples from concept plates 01–03; analytic relief; measurements in metres."
    mat.diffuse_color=(*srgb_linear([145,100,62]),1)
    mat.use_nodes=True;tree=mat.node_tree;nodes=tree.nodes;links=tree.links;nodes.clear()
    def node(kind,name,x,y):
        n=nodes.new(kind);n.label=name;n.location=(x,y);return n
    def ins(n,i,value):
        if isinstance(value,bpy.types.NodeSocket):links.new(value,n.inputs[i])
        else:n.inputs[i].default_value=value
    def attr(name,x,y,typ="Fac"):
        a=node("ShaderNodeAttribute",name,x,y);a.attribute_name=name;return a.outputs[typ]
    def calc(op,name,x,y,a,b):
        q=node("ShaderNodeMath",name,x,y);q.operation=op;ins(q,0,a);ins(q,1,b);return q.outputs[0]
    def scale(name,x,y,a,f):
        q=node("ShaderNodeVectorMath",name,x,y);q.operation='SCALE';ins(q,0,a);ins(q,'Scale',f);return q.outputs['Vector']
    def data_texture(name,filename,x,y,vector,box):
        path=SOURCE/filename
        im=bpy.data.images.get(filename)
        if im is None:im=bpy.data.images.load(str(path),check_existing=False);im.name=filename
        im.colorspace_settings.name='Non-Color'
        if not im.packed_file:im.pack()
        t=node('ShaderNodeTexImage',name,x,y);t.image=im;t.extension='REPEAT' if box else 'EXTEND'
        t.interpolation='Linear';t.projection='BOX' if box else 'FLAT'
        if box:t.projection_blend=.30
        ins(t,'Vector',vector);return t.outputs['Color']
    rest=attr(ATTR_REST,-1540,260,'Vector')
    micro_vec=scale("57 mm seamless tile", -1330,160,rest,17.54)
    micro=data_texture("Pigment / pore relief / dry islands","Shen_SkinMicrostructure.png",-1100,150,micro_vec,True)
    chan=node("ShaderNodeSeparateColor","Packed data channels",-830,150);ins(chan,0,micro)
    skin=attr(ATTR_TINT,-550,650,'Color')
    mott=node("ShaderNodeTexNoise","Epidermal colour breakup · 8–16 mm",-1080,510);ins(mott,'Vector',rest);ins(mott,'Scale',90.);ins(mott,'Detail',3.2);ins(mott,'Roughness',.61)
    a=calc('MULTIPLY',"Local pigment depth",-580,485,chan.outputs['Red'],.68)
    b=calc('MULTIPLY',"Broad mottling",-580,355,mott.outputs['Fac'],.27)
    c=calc('ADD',"Broad + fine",-390,460,a,b);c=calc('ADD',"Conserve mean diffuse value",-200,450,c,.525)
    # Solar lentigines are separate from pore relief. Using distances in 3D makes sparse irregular spots
    # that stay with the head, varied by realistic exposure zones and suppressed around the lids.
    speck=node('ShaderNodeTexVoronoi','Scattered pigment cells · 3.7 mm spacing',-1360,840)
    speck.voronoi_dimensions='3D';speck.feature='F1';ins(speck,'Vector',rest);ins(speck,'Scale',270.0)
    ramp=node('ShaderNodeValToRGB','Soft pigmented spots · 0.3–0.9 mm',-1100,840)
    ramp.color_ramp.interpolation='EASE';ramp.color_ramp.elements[0].position=.055;ramp.color_ramp.elements[0].color=(1,1,1,1)
    ramp.color_ramp.elements[1].position=.24;ramp.color_ramp.elements[1].color=(0,0,0,1);ins(ramp,'Fac',speck.outputs['Distance'])
    sun=attr(ATTR_PIGMENT,-1080,1100)
    sp=calc('MULTIPLY','Uneven sun exposure',-770,860,ramp.outputs[0],sun)
    sp=calc('MULTIPLY','Small brown macules',-560,880,sp,.45)
    c=calc('SUBTRACT','Subtle cumulative pigmentation',-370,855,c,sp)
    base=scale("Reference skin tones",-15,590,skin,c)
    native_rough=attr(ATTR_ROUGH,-600,-40);r=calc('SUBTRACT',"Neutral roughness centre",-590,100,chan.outputs['Blue'],.5)
    r=calc('MULTIPLY',"Small roughness variations",-380,65,r,.18);rough=calc('ADD',"Surface oil variation",-170,60,native_rough,r)
    weight=attr(ATTR_PORES,-835,-300);h=calc('SUBTRACT',"Pore height midline",-610,-185,chan.outputs['Green'],.54)
    h=calc('MULTIPLY',"Per-region pore intensity",-370,-230,h,weight)
    uv=attr(ATTR_FOLDS,-1540,-600,'Vector');fold=data_texture("Glabella, lower lids and nasolabial microfolds","Shen_FacialMicrofolds.png",-1330,-590,uv,False)
    local=node("ShaderNodeSeparateColor","Local melanin / fold depth / dryness",-1100,-580);ins(local,0,fold)
    forward=attr(ATTR_FRONT,-1080,-820)
    d=calc("SUBTRACT","Local pigment centre",-860,-755,local.outputs['Red'],.5)
    d=calc("MULTIPLY","Local creases and cheek flecks",-655,-765,d,forward)
    d=calc("MULTIPLY","Translucent pigment layer",-450,-765,d,1.30)
    d=calc("ADD","Local pigment modulation",-255,-765,d,1)
    base=scale("Warm skin and regional pigmentation",100,590,base,d)
    f=calc('SUBTRACT',"Local height midline",-850,-555,local.outputs['Green'],.5)
    f=calc('MULTIPLY',"Anterior face restriction",-610,-555,f,forward)
    bump=node("ShaderNodeBump","Micropores · 0.21 mm maximum range",120,-235)
    ins(bump,'Height',h);ins(bump,'Strength',.55);ins(bump,'Distance',.00021)
    fold_bump=node("ShaderNodeBump","Gentle expression folds; physical depth up to 0.24 mm",360,-230)
    ins(fold_bump,'Height',f);ins(fold_bump,'Distance',.00140);ins(fold_bump,'Strength',.68);ins(fold_bump,'Normal',bump.outputs['Normal'])
    bs=node("ShaderNodeBsdfPrincipled","Tanned skin · superficial scattering",420,520)
    ins(bs,'Base Color',base);ins(bs,'Roughness',rough);ins(bs,'Normal',fold_bump.outputs['Normal'])
    for name,value in [('IOR',1.4),('Specular IOR Level',.34),('Subsurface Weight',.065),('Subsurface Scale',.0012),('Subsurface Radius',(1.,.48,.24)),('Coat Weight',0)]:
        if bs.inputs.get(name):ins(bs,name,value)
    output=node('ShaderNodeOutputMaterial','Surface',740,470);ins(output,'Surface',bs.outputs[0])
    return mat

def apply_skin(head_object,skin_material_names=None):
    """Attach to specified skin surfaces. Pass the head and both ears (or every object using Shen_Skin)."""
    objects=[head_object] if isinstance(head_object,bpy.types.Object) else list(head_object)
    names=set(skin_material_names or ['Shen_Skin',SKIN_NAME]);mat=make_material()
    updated=[]
    for ob in objects:
        if ob is None or ob.type!='MESH':continue
        slots=[i for i,m in enumerate(ob.data.materials) if m and (m.name in names or m.name.rsplit('.',1)[0] in names)]
        if not ob.data.materials and (ob.name.startswith('Shen_HeadSkin') or ob.name.startswith('Shen_Ear')):
            ob.data.materials.append(mat);slots=[0]
        if not slots:continue
        fields(ob)
        for i in slots:ob.data.materials[i]=mat
        updated.append(ob.name)
    if not updated:raise ValueError("No matching native skin slots on supplied objects: "+str([o.name for o in objects]))
    # Preserve a callable copy with the material. Reopened files reuse the packed procedural maps.
    source_path=SOURCE/"shen_native_skin.py"
    if source_path.is_file() and not bpy.data.texts.get("Shen_NativeSkin.py"):
        text=bpy.data.texts.new("Shen_NativeSkin.py")
        text.write(source_path.read_text(encoding="utf8"))
        text.use_fake_user=True
    return mat

