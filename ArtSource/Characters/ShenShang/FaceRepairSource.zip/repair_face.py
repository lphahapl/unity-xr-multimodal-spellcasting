"""Reproject the approved frontal portrait onto the facial UV islands only."""
from pathlib import Path
import argparse
import cv2
import numpy as np
from scipy.interpolate import RBFInterpolator
from scipy.ndimage import distance_transform_edt
from PIL import Image
parser=argparse.ArgumentParser()
parser.add_argument('--portrait',default='D:/UnityProjects/NarutoVR/ArtSource/Characters/ShenShang/ShenShang_ModelReference.png')
parser.add_argument('--atlas',default='D:/Temp/ShenPlayer-20261121/Rig/Local/Package/Textures/ShenShang_BaseColor.png')
parser.add_argument('--workdir',type=Path,default=Path(__file__).parent)
args=parser.parse_args()
root=args.workdir
# Correspondences use the locked Blender review camera and a 3x portrait crop.
starts=np.array([
[380,183],[310,199],[451,199],
[270,274],[306,271],[346,280],[402,280],[449,270],[486,274],
[280,318],[311,316],[340,319],[407,319],[437,316],[470,317],
[312,330],[438,330],[380,312],[380,366],
[347,398],[381,402],[411,398],
[317,451],[380,447],[439,451],[380,471],
[265,362],[497,361],[275,431],[490,432],[322,507],[380,535],[437,506],
[244,312],[512,312],[262,237],[489,237],
],dtype=np.float64)
ends=np.array([
[342,24],[264,37],[420,38],
[213,145],[254,132],[314,145],[369,145],[433,133],[469,139],
[225,180],[269,175],[303,184],[379,184],[414,175],[462,178],
[268,197],[416,198],[344,171],[341,234],
[302,269],[341,280],[379,267],
[279,334],[342,328],[408,332],[343,350],
[210,237],[477,236],[212,316],[475,317],[269,393],[342,421],[415,390],
[183,183],[498,181],[204,91],[477,93],
],dtype=np.float64)
photo=Image.open(args.portrait).convert('RGB').crop((400,65,615,225)).resize((645,480),Image.Resampling.LANCZOS)
photo=np.asarray(photo,dtype=np.float32)
mesh=np.load(root/'face_mesh.npz')
p,uv=mesh['p'],mesh['uv']
base=np.array(Image.open(args.atlas).convert('RGB'))
height,width=base.shape[:2]
flat=np.array(Image.open(root/'flat-front.png').convert('RGB'),dtype=np.float32)
# Smooth thin-plate warp across the interior only, with explicit lid/canthus anchors.
x0,y0,x1,y1=235,180,522,537
yy,xx=np.mgrid[y0:y1,x0:x1].astype(np.float32)
warp=RBFInterpolator(starts,ends,kernel='thin_plate_spline',smoothing=3)
xy=np.stack([xx,yy],axis=-1)
mapped=np.concatenate([warp(t) for t in np.array_split(xy.reshape(-1,2),32)]).reshape(*xx.shape,2).astype(np.float32)
portrait=cv2.remap(photo,mapped,None,cv2.INTER_CUBIC,borderMode=cv2.BORDER_REPLICATE)
# Match skin colour and broad lighting only. Preserve the original lid and iris contrast.
flat_crop=flat[y0:y1,x0:x1]
blur=lambda a,s:cv2.GaussianBlur(a,(0,0),s)
paint=np.clip(portrait + .86*(blur(flat_crop,22)-blur(portrait,22)),0,255)
def smooth(t):
    t=np.clip(t,0.,1.)
    return t*t*(3-2*t)
def oval(cx,cy,rx,ry,edge):
    r=np.sqrt(((xx-cx)/rx)**2+((yy-cy)/ry)**2)
    return smooth((1-r)/edge)
eyes=np.maximum(oval(314,305,67,61,.24),oval(441,305,67,61,.24))
interior=oval(379,363,138,181,.22)
alpha=np.maximum(eyes,interior*.86)
# Keep full strength through brows, both lids and eye whites. Fade clear of hair/ears.
area=np.maximum(eyes,interior)
target_rgb=flat.copy()
target_rgb[y0:y1,x0:x1]=flat_crop*(1-alpha[:,:,None])+paint*alpha[:,:,None]
Image.fromarray(np.uint8(np.clip(target_rgb,0,255))).save(root/'target-flat.png')
# Local projection uses retained UV coordinates and clips back-of-head faces in world space.
tex=(uv*np.array([width,-height])+np.array([-.5,height-.5]))
coords=np.stack([379.5+p[:,:,0]*2375,299.5-(p[:,:,2]-1.608)*2375],axis=2)
active=((coords[:,:,0].max(1)>=x0)&(coords[:,:,0].min(1)<x1)&(coords[:,:,1].max(1)>=y0)&(coords[:,:,1].min(1)<y1)&(p[:,:,1].min(1)<-.027))
sample_y=[];sample_x=[];sample_screen=[];z_values=[]
for tri,pix,screen in zip(p[active],tex[active],coords[active]):
    lo=np.maximum(np.floor(pix.min(0)).astype(int),0)
    hi=np.minimum(np.ceil(pix.max(0)).astype(int),[width-1,height-1])
    if np.any(hi<lo):continue
    uu=pix[1]-pix[0];vv=pix[2]-pix[0];det=uu[0]*vv[1]-vv[0]*uu[1]
    if abs(det)<.0001:continue
    ys,xs=np.mgrid[lo[1]:hi[1]+1,lo[0]:hi[0]+1]
    dx=xs-pix[0,0];dy=ys-pix[0,1]
    b=(dx*vv[1]-dy*vv[0])/det;c=(dy*uu[0]-dx*uu[1])/det
    keep=(b>=0)&(c>=0)&(b+c<=1)
    if not keep.any():continue
    bc=np.stack((1-b[keep]-c[keep],b[keep],c[keep]),axis=1)
    src=bc@screen
    inside=(src[:,0]>=x0)&(src[:,0]<x1-1)&(src[:,1]>=y0)&(src[:,1]<y1-1)
    if not inside.any():continue
    sample_y.append(ys[keep][inside]);sample_x.append(xs[keep][inside]);sample_screen.append(src[inside]);z_values.append((bc@tri[:,1])[inside])
xs=np.concatenate(sample_x);ys=np.concatenate(sample_y)
src=np.concatenate(sample_screen)-[x0,y0];z=np.concatenate(z_values)
def sample(array):
    # OpenCV's side limit is 32767 even on a single raster row.
    return np.concatenate([cv2.remap(array,part[None].astype(np.float32),None,cv2.INTER_LINEAR).reshape(-1,*array.shape[2:]) for part in np.array_split(src,max(1,len(src)//12000+1))])
weights=sample(alpha)*smooth((-.025-z)/.014)
keep=weights>.0001
xs,ys=xs[keep],ys[keep]
original=base[ys,xs].copy()
target=sample(paint)[keep]
weighted=(target-original)*weights[keep,None]
base[ys,xs]=np.uint8(np.clip(original+weighted,0,255))
# Extend the correction four texels just outside the rasterised UV island to avoid mip seams.
lo=np.array([xs.min(),ys.min()])-5; hi=np.array([xs.max(),ys.max()])+6
lo=np.maximum(lo,0);hi=np.minimum(hi,[width,height])
sl=np.s_[lo[1]:hi[1],lo[0]:hi[0]]
coverage=np.zeros((hi[1]-lo[1],hi[0]-lo[0]),np.uint8);coverage[ys-lo[1],xs-lo[0]]=1
dist,ii=distance_transform_edt(1-coverage,return_indices=True)
delta=np.zeros((*coverage.shape,3),np.float32);delta[ys-lo[1],xs-lo[0]]=weighted
neighbour=(dist>0)&(dist<4.5)
# Only fill existing padding texels that match the source-edge colour.
old=np.array(Image.open(args.atlas).convert('RGB'))[sl].astype(np.float32)
near_original=old[ii[0,neighbour],ii[1,neighbour]]
similarity=np.linalg.norm(old[neighbour]-near_original,axis=1)
extension=delta[ii[0,neighbour],ii[1,neighbour]]*smooth((60.-similarity)/40.)[:,None]*smooth((4.5-dist[neighbour])/2.5)[:,None]
base[sl][neighbour]=np.uint8(np.clip(base[sl][neighbour]+extension,0,255))
Image.fromarray(base).save(root/'ShenShang_BaseColor.png',compress_level=4)
print('Painted face texels',len(xs),'out of',width*height,'bbox',lo,hi)

