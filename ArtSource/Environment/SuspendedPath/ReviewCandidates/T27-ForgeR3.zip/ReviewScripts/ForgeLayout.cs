using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public static partial class ForgeReview
{
    const string CaseName="T27 · 炉房 F1 · 左炉右案";
    const string Opening="Assets/Art/Environment/Opening/";
    static Transform house,arrangement;
    static Transform RootNamed(string name) => objects.First(t=>t.name==name && t.parent && t.parent.name!=name && !t.name.EndsWith("_LOD0"));
    static Transform Nearby(string name) => objects.Where(t=>t.name==name && t.parent && t.parent.name!=name)
        .OrderBy(t=>Vector3.Distance(house.position,t.position)).First();
    static Vector3 At(float x,float y,float z)=>house.TransformPoint(new Vector3(x,y,z));
    static Vector3 Axis(float x,float y,float z)=>house.TransformDirection(new Vector3(x,y,z));
    static void Place(Transform t,float x,float y,float z,float yaw,Vector3 scale)
    {
        t.SetPositionAndRotation(At(x,y,z),house.rotation*Quaternion.Euler(0,yaw,0));
        t.localScale=scale;
    }
    static GameObject Spawn(string path,string name,float x,float y,float z,float yaw,Vector3 scale,bool decor=false)
    {
        var obj=(GameObject)PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath<GameObject>(path),arrangement);obj.name=name;
        Place(obj.transform,x,y,z,yaw,scale);
        if(decor) foreach(var col in obj.GetComponentsInChildren<Collider>(true))col.enabled=false;
        return obj;
    }
    static void Views(string phase)
    {
        // 'Reference' approximates the clipboard crop. The other two views use a 1.62 m head height.
        Shot(phase+"-exterior",At(1.00f,4.08f,-13.68f),At(.00f,1.73f,0),44);
        Shot(phase+"-entry",At(1.13f,1.62f,-3.96f),At(-.08f,1.47f,1.48f),68);
        Shot(phase+"-eye",At(1.72f,1.62f,-11.5f),At(-.70f,1.70f,-.35f),49);
        Shot(phase+"-bench",At(-.43f,1.84f,-.78f),At(.75f,1.33f,1.5f),70);
        Shot(phase+"-A1",new Vector3(32.3f,1.62f,15.3f),new Vector3(27,5,68),58);
        Shot(phase+"-A2",new Vector3(-8.7f,81.62f,20.75f),new Vector3(35.6f,48.6f,20.4f),62);
    }
    static Mesh AssetMesh(string name,Mesh m)
    {
        const string folder="Assets/T27Candidate";
        if(!AssetDatabase.IsValidFolder(folder))AssetDatabase.CreateFolder("Assets","T27Candidate");
        var path=folder+"/"+name+".asset";var old=AssetDatabase.LoadAssetAtPath<Mesh>(path);
        if(!old){m.name=name;AssetDatabase.CreateAsset(m,path);return m;}
        old.Clear(false);EditorUtility.CopySerialized(m,old);old.MarkModified();old.UploadMeshData(false);EditorUtility.SetDirty(old);
        UnityEngine.Object.DestroyImmediate(m);return old;
    }
    static Vector3 Front(Transform stove)
    {
        var mouth=stove.GetComponentsInChildren<Transform>(true).Single(t=>t.name=="MouthFacing");
        return Vector3.ProjectOnPlane(stove.InverseTransformPoint(mouth.position),Vector3.up).normalized;
    }
    static Vector3 ForgeShape(Vector3 p,Vector3 front)
    {
        float h=p.y,k=Mathf.Clamp01((h-1.95f)/.83f);
        var depth=Vector3.Dot(p,front);
        var lateral=Vector3.ProjectOnPlane(p,Vector3.up)-front*depth;
        var aim=lateral*Mathf.Lerp(1.04f,.93f,k)+front*(depth*Mathf.Lerp(1.57f,.88f,k)-.56f*k);
        float level=h<1.95f?h*.71f:h<2.78f?1.3845f+(h-1.95f)*.87f:2.1066f+(h-2.78f)*1.34f;
        return aim+Vector3.up*level;
    }
    static Mesh Coal(Transform stove,MeshFilter mf,Vector3 front)
    {
        var mesh=mf.sharedMesh;var v=mesh.vertices;var u=mesh.uv;var rr=mf.GetComponent<Renderer>();var pts=new List<Vector3>();var tex=new List<Vector2>();
        for(int s=0;s<mesh.subMeshCount;s++)
        {
            var m=rr.sharedMaterials[s];if(!m.name.Contains("Fuel")&&!m.name.Contains("Ember"))continue;
            var ids=mesh.GetTriangles(s);
            for(int i=0;i<ids.Length;i+=3)
            {
                var p=new Vector3[3];
                for(int j=0;j<3;j++)p[j]=stove.InverseTransformPoint(mf.transform.TransformPoint(v[ids[i+j]]));
                var c=(p[0]+p[1]+p[2])/3f;
                if(c.y<.78f||c.y>1.03f||p.Any(a=>Vector3.ProjectOnPlane(a,Vector3.up).magnitude>.79f))continue;
                for(int j=0;j<3;j++){var a=p[j];pts.Add(new Vector3(a.x,(a.y-.73f)*1.24f,a.z));tex.Add(u[ids[i+j]]);}
            }
        }
        var result=new Mesh();result.SetVertices(pts);result.SetUVs(0,tex);result.SetTriangles(Enumerable.Range(0,pts.Count).ToArray(),0);result.RecalculateNormals();result.RecalculateBounds();result.RecalculateTangents();
        return AssetMesh("RecoveredCharcoal",result);
    }
    static void Furnace()
    {
        var stove=Named("锻造房正炉 · 拱膛与风道");var front=Front(stove);
        var mfs=stove.GetComponentsInChildren<MeshFilter>(true);
        var source=mfs.Single(f=>f.name.EndsWith("LOD0"));var charcoal=Coal(stove,source,front);
        foreach(var mf in mfs)
        {
            var m=UnityEngine.Object.Instantiate(mf.sharedMesh);var v=m.vertices;
            for(int i=0;i<v.Length;i++)
            {var p=stove.InverseTransformPoint(mf.transform.TransformPoint(v[i]));v[i]=mf.transform.InverseTransformPoint(stove.TransformPoint(ForgeShape(p,front)));}
            m.vertices=v;m.RecalculateNormals();m.RecalculateBounds();m.RecalculateTangents();mf.sharedMesh=AssetMesh("SideForge_"+mf.name,m);
            PrefabUtility.RecordPrefabInstancePropertyModifications(mf);
        }
        foreach(var t in stove.GetComponentsInChildren<Transform>(true).Where(t=>t.name=="ChimneyExit"||t.name=="MouthFacing"||t.name.Contains("轻烟")))
            t.position=stove.TransformPoint(ForgeShape(stove.InverseTransformPoint(t.position),front));
        stove.position=At(-3.10f,.01f,-3.62f);stove.localScale=Vector3.one*1.04f;
        var dir=Vector3.ProjectOnPlane(Axis(.58f,0,-.72f),Vector3.up).normalized;
        stove.rotation=Quaternion.LookRotation(dir)*Quaternion.Inverse(Quaternion.LookRotation(front));
        foreach(var g in stove.GetComponentsInChildren<LODGroup>(true))g.RecalculateBounds();
        var colliders=Named("工坊器物 · 炉与工案").GetComponents<BoxCollider>();
        var original=colliders.OrderBy(c=>Vector3.Distance(c.bounds.center,new Vector3(13.5f,.47f,43.65f))).First();
        // The original root contains both forges. Move this collider into furnace coordinates without changing the other forge.
        original.enabled=false;
        var body=stove.gameObject.AddComponent<BoxCollider>();body.center=Vector3.up*.66f;body.size=new Vector3(2f,1.32f,2.11f);

        var tray=Spawn(Opening+"MeasureRoomProps/DividerPartsTray.prefab","炭槽 · 炉边备料",-4.44f,.025f,-2.85f,12,new Vector3(1.86f,1.62f,1.65f));
        var pile=new GameObject("木炭 · 从原炉床复用");pile.transform.SetParent(arrangement,false);
        Place(pile.transform,-4.43f,.17f,-2.85f,12,new Vector3(.96f,1.02f,.88f));
        pile.AddComponent<MeshFilter>().sharedMesh=charcoal;var fuelRenderer=pile.AddComponent<MeshRenderer>();
        fuelRenderer.sharedMaterial=AssetDatabase.LoadAssetAtPath<Material>("Assets/Art/Environment/SuspendedPath/ApprovedWorkshop/CarbonizedFuel.mat");
        var glow=new GameObject("炉膛反光");glow.transform.SetParent(arrangement,false);
        glow.transform.position=stove.position+dir*1.02f+Vector3.up*.83f;
        var lamp=glow.AddComponent<Light>();lamp.type=LightType.Point;lamp.range=4.85f;lamp.intensity=2.15f;lamp.color=new Color(1,.43f,.16f);lamp.shadows=LightShadows.None;
    }
    static void Furniture()
    {
        var bench=Nearby("TrialMendingBench");
        Place(bench,.26f,.235f,1.29f,180,new Vector3(1.88f,1.00f,1.60f));
        var vice=Nearby("WestViseAndInk");Place(vice,.02f,.98f,1.20f,180,new Vector3(1.03f,1.17f,1.04f));
        // The former oversized tool proxy beside the right-hand window is reused as the enclosed storage footprint.
        var oldToolProxy=Named("工坊器物 · 炉与工案").GetComponentsInChildren<BoxCollider>(true)
          .OrderBy(c=>Vector3.Distance(c.bounds.center,new Vector3(13.65f,.45f,48.50f))).First();
        oldToolProxy.transform.SetPositionAndRotation(At(3.08f,.68f,1.06f),house.rotation);
        oldToolProxy.size=new Vector3(1.7f,.89f,.71f);
        var cabinet=Spawn(Opening+"FurnishWorkshopsB/PartsCabinet.prefab","成件柜 · 右壁",3.08f,.23f,1.06f,180,new Vector3(1.32f,1.10f,1.30f),true);
        var caseObj=Nearby("AssemblyPartsCase");Place(caseObj,2.86f,1.12f,1.12f,180,new Vector3(1.04f,.93f,.96f));
        var rail=Nearby("HangingMandrels");Place(rail,.08f,2.22f,1.62f,180,new Vector3(1.42f,1.31f,1.00f));
        Spawn(Opening+"FurnishWallGauges/WestWallSquares.prefab","量规 · 案上挂架",1.31f,1.87f,1.61f,180,new Vector3(.88f,.97f,.90f),true);
        Spawn(Opening+"FurnishWorkshopsB/EastGaugeCase.prefab","量匣 · 成件柜顶",3.64f,1.16f,1.02f,90,new Vector3(.57f,.74f,.68f),true);
        Spawn(Opening+"FurnishWallGauges/AssemblySaddle.prefab","承砧 · 热件落座",-2.35f,.235f,-.63f,-8,new Vector3(1.31f,1.10f,1.28f));
        Spawn(Opening+"FurnishWallGauges/EastFiveStraightedges.prefab","坯尺 · 左壁",-3.89f,1.50f,.63f,90,new Vector3(.78f,1.00f,1f),true);
        Spawn(Opening+"FurnishWorkshopsB/WestAngleSamples.prefab","样件 · 待校工件",-.99f,1.05f,1.18f,165,new Vector3(.65f,.62f,.67f),true);
        // Reuse the native closed-panel collider as the left wall and mark its matched right panel. Existing roof and nav components remain intact.
        var wall=house.GetComponents<BoxCollider>().Single(c=>c.size.y>3.5f&&c.size.z>4);
        wall.center=new Vector3(-2.85f,1.71f,-1.99f);wall.size=new Vector3(3.06f,3.0f,.24f);
        var right=new GameObject("右窗栏板 · 门洞净开");right.transform.SetParent(arrangement,false);Place(right.transform,2.85f,1.71f,-1.99f,0,Vector3.one);
        right.AddComponent<BoxCollider>().size=wall.size;
    }
    public static void Render()
    {
        Open();house=Named("F1 · 锻造房");Views("before");Facts("before");
        arrangement=new GameObject(CaseName).transform;
        Furnace();Furniture();OldFire();ClearBackWall();TouchSurfaces();MetalContact();
        Physics.SyncTransforms();Views("after");Facts("after");
        AssetDatabase.SaveAssets();
        EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),"Assets/T27Candidate/F1-ForgeR3.unity");
    }
    static void Facts(string key)
    {
        var scene=SceneManager.GetActiveScene();
        var nodes=scene.GetRootGameObjects().SelectMany(t=>t.GetComponentsInChildren<Transform>(true)).ToArray();
        var cols=nodes.SelectMany(t=>t.GetComponents<Collider>()).Where(c=>c.enabled&&c.gameObject.activeInHierarchy&&!c.isTrigger).ToArray();
        var roof=Named("ForgeRoofPost");var enemy=roof.GetComponentsInChildren<Transform>(true).First(t=>t.name=="ZhiHuoCanJi_Enemy");
        var nav=NavMesh.CalculateTriangulation();
        var lines=new List<string>{"solidColliders="+cols.Length,"roof="+roof.position.ToString("F3")+" "+roof.GetComponent<MeshCollider>().sharedMesh.name,"shooter="+enemy.position.ToString("F3"),"navigation="+nav.vertices.Length+" vertices / "+nav.indices.Length/3+" triangles","nav_sha256="+NavHash(),"frame="+house.position.ToString("F3")+" "+house.rotation.eulerAngles.ToString("F1")};
        const float radius=.26f;
        for(float width=-1.3f;width<1.31f;width+=.1f)
        {
            int clear=0,total=0;var hits=new HashSet<string>();
            for(float depth=-4.8f;depth<=.51f;depth+=.10f)
            {
                var f=At(width,0,depth);
                var support=Physics.RaycastAll(f+Vector3.up*.80f,Vector3.down,1.0f,~0,QueryTriggerInteraction.Ignore)
                                   .Where(h=>h.normal.y>.80f).OrderBy(h=>h.distance).ToArray();
                if(support.Length>0)f.y=support[0].point.y+.015f;
                else {total++;hits.Add("no tread");continue;}
                var blockers=Physics.OverlapCapsule(f+Vector3.up*(radius+.04f),f+Vector3.up*(1.72f-radius),radius,~0,QueryTriggerInteraction.Ignore).Where(c=>!c.GetComponentInParent<Light>()).ToArray();
                total++;if(blockers.Length==0)clear++;else foreach(var c in blockers)hits.Add(c.name);
            }
            lines.Add("lane "+width.ToString("F1")+" "+clear+"/"+total+" "+String.Join("|",hits));
        }
        File.WriteAllLines(Output+"/"+key+"-validation.txt",lines);
    }
}
