using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.AI;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System;

public static partial class ForgeReview
{
    const string Output="D:/Temp/Ch02ForgeReview1125";
    const string ScenePath="Assets/Scene/Chapter02_SuspendedPath.unity";
    static Transform[] objects;
    static Transform Named(string n)=>objects.Single(x=>x.name==n);
    static string Hier(Transform t)=>t.parent?Hier(t.parent)+"/"+t.name:t.name;
    static void Open()
    {
        var scene=EditorSceneManager.OpenScene(ScenePath);
        objects=scene.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<Transform>(true)).ToArray();
        Physics.SyncTransforms();
    }
    public static void Probe()
    {
        Open();var lines=new List<string>();
        foreach(var t in objects)
        {
            var c=t.GetComponent<Collider>();var r=t.GetComponent<Renderer>();
            bool local=t.position.x>5&&t.position.x<18&&t.position.z>37&&t.position.z<53&&t.position.y<10;
            if(!local && !t.name.Contains("射手") && !t.name.Contains("导航") && !(c && c.bounds.SqrDistance(new Vector3(11,1,44))<57))continue;
            lines.Add(Hier(t)+"\t"+t.position.ToString("F2")+"\t"+t.rotation.eulerAngles.ToString("F1")+"\t"+t.lossyScale.ToString("F2")+"\t"+(c?c.GetType().Name+" "+c.enabled+" trigger="+c.isTrigger+" "+c.bounds:"")+"\t"+(r?r.GetType().Name+" "+r.enabled+" "+r.bounds:""));
        }
        File.WriteAllLines(Output+"/probe.tsv",lines);
        var list=Directory.GetFiles("Assets/Art/Environment/Opening","*.prefab",SearchOption.AllDirectories).Where(x=>x.Contains("Furnish")||x.Contains("MeasureRoomProps")||x.Contains("Surface"));
        var output=new List<string>();
        foreach(var raw in list)
        {
            var path=raw.Replace('\\','/');var a=AssetDatabase.LoadAssetAtPath<GameObject>(path);var rr=a.GetComponentsInChildren<Renderer>(true);
            if(rr.Length==0)continue;var b=rr[0].bounds;foreach(var one in rr)b.Encapsulate(one.bounds);
            output.Add(path+"\t"+b.center+"\t"+b.size+"\t"+a.GetComponentsInChildren<Collider>(true).Length);
        }
        File.WriteAllLines(Output+"/props.tsv",output);
        Shot("probe-front",new Vector3(23.6f,2.75f,42.9f),new Vector3(10.6f,1.82f,44.65f),48);
        Shot("probe-entry",new Vector3(15.05f,1.62f,44.55f),new Vector3(8.01f,1.48f,44.62f),75);
        Shot("probe-cross",new Vector3(11.2f,1.62f,42.2f),new Vector3(9.7f,1.25f,48.2f),73);
    }
    static void Shot(string name,Vector3 eye,Vector3 target,float fov)
    {
        var go=new GameObject("Review Camera");var cam=go.AddComponent<Camera>();cam.transform.SetPositionAndRotation(eye,Quaternion.LookRotation(target-eye));
        cam.fieldOfView=fov;cam.aspect=16f/9;cam.nearClipPlane=.055f;cam.farClipPlane=700;cam.allowHDR=true;cam.allowMSAA=true;
        cam.backgroundColor=RenderSettings.ambientSkyColor;cam.clearFlags=CameraClearFlags.Skybox;
        var rt=RenderTexture.GetTemporary(1600,900,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
        var frame=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);
        var prev=RenderTexture.active;
        try{cam.targetTexture=rt;cam.Render();RenderTexture.active=rt;frame.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);frame.Apply();File.WriteAllBytes(Output+"/shots/"+name+".jpg",frame.EncodeToJPG(96));}
        finally{RenderTexture.active=prev;cam.targetTexture=null;RenderTexture.ReleaseTemporary(rt);UnityEngine.Object.DestroyImmediate(frame);UnityEngine.Object.DestroyImmediate(go);}
    }
}
