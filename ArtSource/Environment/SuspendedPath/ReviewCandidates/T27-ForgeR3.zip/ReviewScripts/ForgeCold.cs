using System.Linq;
using System.IO;
using UnityEditor.SceneManagement;
using UnityEngine;
public static partial class ForgeReview
{
    public static void Cold()
    {
        var s=EditorSceneManager.OpenScene("Assets/T27Candidate/F1-ForgeR3.unity");
        objects=s.GetRootGameObjects().SelectMany(go=>go.GetComponentsInChildren<Transform>(true)).ToArray();
        house=Named("F1 · 锻造房");Physics.SyncTransforms();Views("cold");Facts("cold");
        var hit=new System.Collections.Generic.List<string>();
        foreach(var name in new[]{"锻造房正炉 · 拱膛与风道","TrialMendingBench","WestViseAndInk","AssemblyPartsCase","HangingMandrels"})
        {var t=Nearby(name);hit.Add(name+" "+t.position.ToString("F3"));}
        File.WriteAllLines(Output+"/cold-layout.txt",hit);
    }
}
