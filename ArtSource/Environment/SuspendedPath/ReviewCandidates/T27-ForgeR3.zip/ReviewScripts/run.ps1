param([string]$method,[string]$log)
$ErrorActionPreference='Stop'
$env:ALLUSERSPROFILE=[Environment]::GetFolderPath('CommonApplicationData')
$exe='D:/unity_hub/6000.3.10f1/Editor/Unity.exe'
$dir='D:/Temp/Ch02ForgeReview1125'
$arguments=@('-batchmode','-force-d3d11','-quit','-projectPath',"$dir/Unity",'-executeMethod',"ForgeReview.$method",'-logFile',"$dir/$log.log")
$proc=Start-Process -FilePath $exe -ArgumentList $arguments -WindowStyle Hidden -PassThru -Wait
exit $proc.ExitCode
