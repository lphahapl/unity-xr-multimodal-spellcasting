using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.AI;

public static partial class ForgeReview
{
    static void OldFire()
    {
        var stove=Named("锻造房正炉 · 拱膛与风道");
        var prop=Named("锻造与修械工位 · 器具");var mf=prop.GetComponent<MeshFilter>();var mesh=UnityEngine.Object.Instantiate(mf.sharedMesh);
        var v=mesh.vertices;var affected=new HashSet<int>();var counts=new List<int>();
        for(int s=0;s<mesh.subMeshCount;s++)
        {
            int n=0;var ids=mesh.GetTriangles(s);
            for(int i=0;i<ids.Length;i+=3)
            {
                var p=(v[ids[i]]+v[ids[i+1]]+v[ids[i+2]])/3;
                if(Mathf.Abs(p.x-7.15f)>=1.3f||Mathf.Abs(p.z-21.10f)>=1.3f)continue;
                n++;affected.Add(ids[i]);affected.Add(ids[i+1]);affected.Add(ids[i+2]);
            }
            if(n!=0)counts.Add(n);
        }
        if(counts.Sum()!=108)throw new Exception("Unrecognised F1 legacy fire components "+string.Join(",",counts));
        var b=new Bounds(v[affected.First()],Vector3.zero);foreach(int index in affected)b.Encapsulate(v[index]);
        var front=Front(stove);Vector3 sideways=Vector3.Cross(Vector3.up,front).normalized;
        foreach(int i in affected)
        {
            var q=v[i]-b.center;
            var local=front*(.16f+q.z*.63f)+sideways*q.x*.78f+Vector3.up*(.46f+q.y*.26f);
            v[i]=prop.InverseTransformPoint(stove.TransformPoint(local));
        }
        mesh.vertices=v;mesh.RecalculateNormals();mesh.RecalculateBounds();mesh.RecalculateTangents();mf.sharedMesh=AssetMesh("LegacyFireRelocated",mesh);
        File.WriteAllText(Output+"/fire.txt",string.Join(",",counts)+" triangles from the native fire grate and cones positioned inside the revised hearth.");
    }
    static float Shelter(float a,float b,float x)=>Mathf.SmoothStep(0,1,Mathf.InverseLerp(a,b,x));
    static void ClearBackWall()
    {
        var recess=Named("工坊背岩 · 檐后岩窝");
        var log=new List<string>();
        foreach(var mf in recess.GetComponentsInChildren<MeshFilter>(true))
        {
            var mesh=UnityEngine.Object.Instantiate(mf.sharedMesh);var v=mesh.vertices;int changes=0;
            for(int i=0;i<v.Length;i++)
            {
                var w=mf.transform.TransformPoint(v[i]);var p=house.InverseTransformPoint(w);
                float taper=(1-Shelter(5.0f,6.2f,Mathf.Abs(p.x)))*(1-Shelter(3.62f,4.85f,p.y))*Shelter(-1.31f,-.15f,p.y);
                if(taper<=0||p.z>=2.36f)continue;
                p.z=Mathf.Lerp(p.z,2.36f,taper);v[i]=mf.transform.InverseTransformPoint(house.TransformPoint(p));changes++;
            }
            mesh.vertices=v;mesh.RecalculateNormals();mesh.RecalculateTangents();mesh.RecalculateBounds();mf.sharedMesh=AssetMesh("F1Recess_"+mf.name,mesh);PrefabUtility.RecordPrefabInstancePropertyModifications(mf);
            log.Add(mf.name+" "+changes+" local photo-shell vertices behind rear plaster wall.");
        }
        File.WriteAllLines(Output+"/back-wall.txt",log);
    }
    static void Block(string name,float vx,float vy,float vz,float sx,float sy,float sz,string mat,bool threshold=false)
    {
        var orig=AssetDatabase.LoadAllAssetsAtPath("Assets/Art/Environment/SuspendedPath/SuspendedPathGeometry.asset").OfType<Mesh>().Single(m=>m.name=="工坊院场 · 地面与崖基");
        var ids=orig.GetTriangles(0);var vs=orig.vertices;var bounds=new Bounds(vs[ids[0]],Vector3.zero);
        foreach(int i in ids)bounds.Encapsulate(vs[i]);var pts=new List<Vector3>();var uv=new List<Vector2>();
        for(int i=0;i<ids.Length;i+=3)
        {
            var normal=Vector3.Cross(vs[ids[i+1]]-vs[ids[i]],vs[ids[i+2]]-vs[ids[i]]).normalized;
            for(int j=0;j<3;j++)
            {
                var p=vs[ids[i+j]]-bounds.min;
                var q=new Vector3((p.x/bounds.size.x-.5f)*sx,(p.y/bounds.size.y)*sy,(p.z/bounds.size.z-.5f)*sz);
                if(threshold) q.y=p.y<.05f?-.015f:Mathf.Lerp(.008f,.228f,p.z/bounds.size.z);
                pts.Add(q);
                float bx=Mathf.Abs(normal.x)>.7f?q.z:q.x;
                float by=Mathf.Abs(normal.y)>.7f?q.z:q.y;
                // The scan runs horizontally: longitudinal board surfaces follow U, and V crosses the width.
                uv.Add(new Vector2(bx/(threshold?2.15f:1.35f)+vx*.31f+vz*.43f,by/(threshold?2.15f:1.35f)+vz*.67f+vx*.13f));
            }
        }
        var mesh=new Mesh();mesh.SetVertices(pts);mesh.SetUVs(0,uv);mesh.SetTriangles(Enumerable.Range(0,pts.Count).ToArray(),0);mesh.RecalculateNormals();mesh.RecalculateBounds();mesh.RecalculateTangents();mesh=AssetMesh(name,mesh);
        var go=new GameObject(name);go.transform.SetParent(arrangement,false);Place(go.transform,vx,vy,vz,0,Vector3.one);
        go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=AssetDatabase.LoadAssetAtPath<Material>(mat);
        if(threshold)go.AddComponent<MeshCollider>().sharedMesh=mesh;
    }
    static void TouchSurfaces()
    {
        const string surfaces="Assets/Art/Environment/SuspendedPath/MountainCraft/Materials/";
        Block("门槛接坡",0,0,-2.94f,2.36f,.225f,1.33f,"Assets/Art/Environment/SuspendedPath/ApprovedWorkshop/WorkshopFlagstones.mat",true);
        // Thin replaceable boards on the existing bench. Separate edges keep end grain and joints visible at hand distance.
        for(int i=0;i<3;i++)Block("案面榆木板"+(i+1),.26f,.951f,.975f+i*.225f,2.44f,.052f,.216f,surfaces+"Timber.mat");
        var vice=Nearby("WestViseAndInk");Place(vice,.09f,1.015f,1.12f,180,new Vector3(1.04f,1.15f,1.08f));
        var sample=arrangement.Find("样件 · 待校工件");sample.position=At(-.62f,1.016f,1.23f);
        // The back wall has an active roof shooter on top. Keep the wall and its cover; attach gauges on its interior face.
        var timber=AssetDatabase.LoadAssetAtPath<Material>(surfaces+"Timber.mat");
        var pin=Spawn(Opening+"FurnishWallGauges/WestWallSquares.prefab","夹具 · 炉房副钩",-1.18f,1.88f,1.58f,180,new Vector3(.78f,.87f,1),true);
        // Use the authored wall-mounted graduated rulers as the raw measuring stock resting against the reserve wall.
        var rack=Spawn(Opening+"MeasureRoomProps/GraduatedRuleRack.prefab","备料条架 · 水平码放",-2.85f,.234f,1.15f,180,new Vector3(.87f,.89f,.91f),true);
    }

    static void MetalContact()
    {
        var vise=Nearby("WestViseAndInk");
        var bronze=AssetDatabase.LoadAssetAtPath<Material>("Assets/Art/Environment/Opening/PreqinGateFittings/GateHammeredBronze.mat");
        foreach(var mf in vise.GetComponentsInChildren<MeshFilter>(true))
        {
            var src=mf.sharedMesh;var verts=src.vertices.ToList();var normals=src.normals.ToList();var uv=src.uv.ToList();
            var tris=new List<int>[src.subMeshCount+1];for(int j=0;j<tris.Length;j++)tris[j]=new List<int>();
            var canonical=verts.Select(v=>vise.InverseTransformPoint(mf.transform.TransformPoint(v))).ToArray();
            for(int slot=0;slot<src.subMeshCount;slot++)
            {
                var old=src.GetTriangles(slot);
                for(int j=0;j<old.Length;j+=3)
                {
                    int a=old[j],b=old[j+1],c=old[j+2];var center=(canonical[a]+canonical[b]+canonical[c])/3;
                    float x=Mathf.Abs(center.x);bool jaw=Mathf.Abs(x-.66f)<.064f||Mathf.Abs(x-.30f)<.064f;
                    if(!jaw||center.y<.214f){tris[slot].Add(a);tris[slot].Add(b);tris[slot].Add(c);continue;}
                    foreach(int k in new[]{a,b,c})
                    {
                        tris[src.subMeshCount].Add(verts.Count);verts.Add(verts[k]);normals.Add(normals[k]);
                        var v=canonical[k];uv.Add(new Vector2(v.x,v.z)/.285f);
                    }
                }
            }
            if(tris[src.subMeshCount].Count==0)continue;
            var mesh=new Mesh();mesh.SetVertices(verts);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.subMeshCount=tris.Length;
            for(int j=0;j<tris.Length;j++)mesh.SetTriangles(tris[j],j,false);
            mesh.RecalculateBounds();mesh.RecalculateTangents();
            mf.sharedMesh=AssetMesh("F1_JawCaps_"+mf.name,mesh);
            var r=mf.GetComponent<MeshRenderer>();r.sharedMaterials=r.sharedMaterials.Concat(new[]{bronze}).ToArray();
            PrefabUtility.RecordPrefabInstancePropertyModifications(mf);PrefabUtility.RecordPrefabInstancePropertyModifications(r);
        }
    }
    static string NavHash()
    {
        var n=NavMesh.CalculateTriangulation();using(var mem=new MemoryStream())using(var w=new BinaryWriter(mem))using(var h=System.Security.Cryptography.SHA256.Create())
        {
            foreach(var p in n.vertices){w.Write(p.x);w.Write(p.y);w.Write(p.z);}foreach(var i in n.indices)w.Write(i);foreach(var a in n.areas)w.Write(a);w.Flush();
            return BitConverter.ToString(h.ComputeHash(mem.ToArray())).Replace("-","").ToLowerInvariant();
        }
    }
}
