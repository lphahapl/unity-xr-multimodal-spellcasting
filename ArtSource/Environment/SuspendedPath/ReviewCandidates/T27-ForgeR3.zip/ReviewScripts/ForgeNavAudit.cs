using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
public static partial class ForgeReview
{
    public static void AuditNavigation()
    {
        var report = new List<string>();
        foreach(var scenePath in new[]{ScenePath,"Assets/T27Candidate/F1-ForgeR3.unity"})
        {
            var scene=EditorSceneManager.OpenScene(scenePath);
            var o=scene.GetRootGameObjects().SelectMany(t=>t.GetComponentsInChildren<Transform>(true)).ToArray();
            var f1=o.Single(t=>t.name=="F1 · 锻造房");var nav=NavMesh.CalculateTriangulation();var polys=new List<string>();
            string V(Vector3 v)=>v.x.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+","+v.y.ToString("R",System.Globalization.CultureInfo.InvariantCulture)+","+v.z.ToString("R",System.Globalization.CultureInfo.InvariantCulture);
            for(int j=0;j<nav.indices.Length;j+=3)
            {
                var a=V(nav.vertices[nav.indices[j]]);var b=V(nav.vertices[nav.indices[j+1]]);var c=V(nav.vertices[nav.indices[j+2]]);
                var key=new[]{a+"/"+b+"/"+c,b+"/"+c+"/"+a,c+"/"+a+"/"+b}.OrderBy(k=>k,StringComparer.Ordinal).First();
                polys.Add(nav.areas[j/3]+" "+key);
            }
            polys.Sort(StringComparer.Ordinal);var text=string.Join("\n",polys);
            using(var h=System.Security.Cryptography.SHA256.Create())
            { report.Add(scenePath+" canonical oriented polygon geometry and areas "+BitConverter.ToString(h.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-","").ToLowerInvariant()+" triangles="+polys.Count); }
            foreach(var a in o.SelectMany(t=>t.GetComponents<Component>()).Where(c=>c&&c.GetType().Name=="NavMeshSurface"))
            {
                var ser=new SerializedObject(a);var data=ser.FindProperty("m_NavMeshData");var obj=data!=null?data.objectReferenceValue:null;
                report.Add(a.name+" "+(obj?AssetDatabase.GetAssetPath(obj):"no asset")+" "+V(a.transform.position));
            }
            foreach(var p in new[]{new Vector3(0,0,-5.2f),new Vector3(0,.23f,-.6f),new Vector3(0,.23f,.43f)})
            {
                var goal=f1.TransformPoint(p);NavMeshHit hit;bool ok=NavMesh.SamplePosition(goal,out hit,.45f,NavMesh.AllAreas);
                report.Add("nav sample at "+V(goal)+": "+ok+(ok?" "+hit.position:""));
            }
        }
        File.WriteAllLines(Output+"/R3/navigation-audit.txt",report);
    }
}
