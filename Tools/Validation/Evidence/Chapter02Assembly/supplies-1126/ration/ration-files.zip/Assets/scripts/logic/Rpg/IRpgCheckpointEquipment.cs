namespace NarutoVR.SealCombat.Rpg
{
    public interface IRpgCheckpointEquipment
    {
        void CaptureEquipment(RpgCheckpointData checkpoint);
        void RestoreEquipment(RpgCheckpointData checkpoint);
    }
}
