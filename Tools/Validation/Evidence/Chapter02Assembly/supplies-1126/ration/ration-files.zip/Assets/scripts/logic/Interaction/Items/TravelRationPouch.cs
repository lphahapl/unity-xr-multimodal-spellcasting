using UnityEngine;

namespace NarutoVR.SealCombat.Items
{
    public sealed class TravelRationPouch : GameItemBase
    {
        public GameObject closedVisual;
        public GameObject openVisual;
        public Transform clothFlap;
        public Transform paperFlap;
        public Quaternion foldedCloth = Quaternion.identity;
        public Quaternion foldedPaper = Quaternion.identity;
        public Vector3[] packedPositions = new Vector3[4];
        public Quaternion[] packedRotations = new Quaternion[4];
        public Transform[] biscuits = new Transform[4];
        public ConsumableItem servingPrefab;

        readonly bool[] eaten = new bool[4];
        int lifted = -1;
        ConsumableItem liftedItem;
        internal int ConsumedMask
        {
            get
            {
                int mask = 0;
                for (int i = 0; i < eaten.Length; i++)
                    if (eaten[i] || (i == lifted && liftedItem && liftedItem.Remaining == 0)) mask |= 1 << i;
                return mask;
            }
        }

        internal void RestoreContents(int mask)
        {
            for (int i = 0; i < eaten.Length; i++) eaten[i] = (mask & (1 << i)) != 0;
            UpdateAppearance();
        }

        float openness;
        Quaternion clothOpen, paperOpen;
        readonly Vector3[] displayedPositions = new Vector3[4];
        readonly Quaternion[] displayedRotations = new Quaternion[4];
        internal bool HasLifted => lifted >= 0;
        public bool Open => openness >= 1f;
        public int InPouch { get; private set; } = 4;
        public Vector3 NextBiscuitPosition
        {
            get
            {
                for (int i = eaten.Length - 1; i >= 0; i--)
                    if (!eaten[i] && i != lifted && biscuits[i]) return biscuits[i].position;
                return GripPosition;
            }
        }

        protected override void Awake()
        {
            base.Awake();
            if (clothFlap) clothOpen = clothFlap.localRotation;
            if (paperFlap) paperOpen = paperFlap.localRotation;
            for (int i = 0; i < biscuits.Length; i++)
            {
                if (!biscuits[i]) continue;
                displayedPositions[i] = biscuits[i].localPosition;
                displayedRotations[i] = biscuits[i].localRotation;
            }
            UpdateAppearance();
        }

        protected override void LateUpdate()
        {
            base.LateUpdate();
            AdvanceOpening(Time.deltaTime);
        }

        internal void AdvanceOpening(float delta)
        {
            float next = Mathf.MoveTowards(openness, IsHeld ? 1f : 0f, delta / .42f);
            if (openness == next) return;
            openness = next;
            UpdateAppearance();
        }

        internal ConsumableItem LiftBiscuit(Vector3 pinch, float reach)
        {
            if (!IsHeld || !Open || lifted >= 0 || !servingPrefab) return null;
            int candidate = -1;
            float distance = reach * reach;
            for (int i = 0; i < eaten.Length; i++)
            {
                if (eaten[i] || !biscuits[i]) continue;
                float square = (pinch - biscuits[i].position).sqrMagnitude;
                if (square >= distance) continue;
                candidate = i;
                distance = square;
            }
            if (candidate < 0) return null;
            var serving = Instantiate(servingPrefab, biscuits[candidate].position, biscuits[candidate].rotation);
            if (!serving.Take())
            {
                Destroy(serving.gameObject);
                return null;
            }
            lifted = candidate;
            liftedItem = serving;
            UpdateAppearance();
            return serving;
        }

        internal void ReturnOrConsume(ConsumableItem serving)
        {
            if (lifted < 0) return;
            if (serving)
            {
                eaten[lifted] = serving.Remaining == 0;
                serving.gameObject.SetActive(false);
                Destroy(serving.gameObject);
            }
            lifted = -1;
            liftedItem = null;
            UpdateAppearance();
        }

        void UpdateAppearance()
        {
            if (closedVisual) closedVisual.SetActive(openness == 0);
            if (openVisual) openVisual.SetActive(openness > 0);
            if (clothFlap)
                clothFlap.localRotation = Quaternion.Slerp(
                    foldedCloth, clothOpen, Mathf.SmoothStep(0, 1, openness));
            if (paperFlap)
                paperFlap.localRotation = Quaternion.Slerp(
                    foldedPaper, paperOpen,
                    Mathf.SmoothStep(0, 1, Mathf.InverseLerp(.25f, .92f, openness)));
            int count = 0;
            for (int i = 0; i < eaten.Length; i++)
            {
                bool inPouch = i != lifted && !eaten[i];
                if (inPouch) count++;
                if (!biscuits[i]) continue;
                float appear = Mathf.SmoothStep(0, 1, Mathf.InverseLerp(.46f, .95f, openness));
                biscuits[i].SetLocalPositionAndRotation(
                    Vector3.Lerp(packedPositions[i], displayedPositions[i], appear),
                    Quaternion.Slerp(packedRotations[i], displayedRotations[i], appear));
                biscuits[i].gameObject.SetActive(inPouch && openness >= .62f);
            }
            InPouch = count;
        }
    }
}

