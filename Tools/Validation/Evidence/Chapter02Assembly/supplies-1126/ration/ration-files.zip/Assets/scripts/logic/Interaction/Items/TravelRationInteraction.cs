using NarutoVR.SealCombat.Rpg;
using NeuGameMRTools.Runtime.Components;
using NarutoVR.SealLab;
using Oculus.Interaction.Input;
using UnityEngine;

namespace NarutoVR.SealCombat.Items
{
    [DefaultExecutionOrder(370)]
    public class TravelRationInteraction : MonoBehaviour
    {
        public LinearRpgController player;
        public TravelRationPouch pouch;
        public MouthConsumeZone mouth;
        public Transform belt;
        // When supplied, the chapter belt alone owns both the input claim and return-to-slot policy.
        [HideInInspector] public ToolBeltInteraction sharedBelt;
        public Vector3 beltOffset = new(0, -.39f, .16f);
        public Vector3 mouthOffset = new(0, -.085f, .055f);
        public float bagReach = .04f;
        public float biscuitReach = .023f;
        public float returnReach = .16f;

        readonly bool[] armed = new bool[2];
        int bagHand = -1;
        long claim;
        ConsumableItem serving;
        bool finishing, initialised, lostBag, lostServing;
        Quaternion yaw = Quaternion.identity;

        public readonly struct PinchSample
        {
            public readonly Vector3 Position;
            public readonly Quaternion Rotation;
            public readonly float Span;
            public readonly bool Valid;

            public PinchSample(Vector3 position, Quaternion rotation, float span)
            { Position = position; Rotation = rotation; Span = span; Valid = true; }
        }

        public bool HasServing => serving;
        public int BagHand => bagHand;

        protected virtual void LateUpdate()
        {
            if (!player || !player.IsReady || !pouch || !mouth) return;
            var head = player.locomotion ? player.locomotion.head : null;
            if (!head) return;
            var forward = Vector3.ProjectOnPlane(head.forward, Vector3.up);
            if (forward.sqrMagnitude > .01f) yaw = Quaternion.LookRotation(forward);
            if (!sharedBelt && belt) belt.SetPositionAndRotation(head.position + yaw * beltOffset, yaw);
            mouth.transform.SetPositionAndRotation(head.TransformPoint(mouthOffset), head.rotation);
            if (!sharedBelt && !initialised)
            {
                if (pouch.home is ToolBeltSlot slot && slot.opening)
                {
                    var end = slot.opening;
                    pouch.transform.SetPositionAndRotation(end.position - end.up * .038f,
                        end.rotation * Quaternion.Euler(pouch.stowEuler));
                    pouch.TryDock(slot, Quaternion.Euler(pouch.stowEuler));
                }
                initialised = true;
            }
            double now = Time.realtimeSinceStartupAsDouble;
            Step(ReadHand(true, now), ReadHand(false, now), Time.deltaTime);
        }

        protected virtual PinchSample ReadHand(bool left, double now) => ObserveHand(player, left, now);

        internal static PinchSample ObserveHand(LinearRpgController player, bool left, double now)
        {
            var tracking = player.handTracking ? player.handTracking : player.skills ? player.skills.lab : null;
            var frame = tracking ? tracking.Frame : null;
            if (frame == null) return default;
            var hand = left ? frame.left : frame.right;
            if (hand == null || !hand.connected || !hand.tracked ||
                !PlayerHandObservation.Fresh(hand.fresh, hand.observedAt, now, player.handSampleMaxAge)) return default;
            int index = (int)HandJointId.HandIndexTip, thumb = (int)HandJointId.HandThumbTip;
            int wrist = (int)HandJointId.HandWristRoot, baseIndex = (int)HandJointId.HandIndex1;
            if (!hand.jointValid[index] || !hand.jointValid[thumb] || !hand.jointValid[wrist] ||
                !hand.jointValid[baseIndex] || !SealFeatureExtractor.PalmNormal(hand, left, out var normal)) return default;
            var origin = tracking.recordingOrigin;
            Vector3 World(int joint) => origin ? origin.TransformPoint(hand.joints[joint].position) : hand.joints[joint].position;
            var a = World(index);
            var b = World(thumb);
            var axis = World(baseIndex) - World(wrist);
            var up = origin ? -origin.TransformDirection(normal) : -normal;
            if (!PlayerHandObservation.Finite(a) || !PlayerHandObservation.Finite(b) ||
                !PlayerHandObservation.Finite(axis) || !PlayerHandObservation.Finite(up) ||
                axis.sqrMagnitude < .0004f || Vector3.Cross(axis.normalized, up).sqrMagnitude < .05f) return default;
            return new PinchSample((a + b) * .5f, Quaternion.LookRotation(axis, up), Vector3.Distance(a, b));
        }

        internal void Step(PinchSample left, PinchSample right, float delta)
        {
            if (!pouch || !pouch.isActiveAndEnabled || !mouth || !player.CanAct || player.UiInputOwned || player.StateCommitInProgress ||
                (bagHand >= 0 && sharedBelt && !sharedBelt.OwnsHeldItem(pouch)) ||
                (claim != 0 && !player.Input.OwnsInteraction(this, claim)))
            { Release(false); armed[0] = armed[1] = false; return; }

            bool leftDown = Pressed(0, left);
            bool rightDown = Pressed(1, right);
            // Re-confirm both pinches after a tracking gap before the last bite can commit.
            if (finishing && (!left.Valid || !right.Valid || left.Span >= .045f || right.Span >= .045f))
            {
                FinishServing();
                armed[0] = armed[1] = false;
            }
            mouth.UpdateFinish(player.Player, true);
            if (pouch.HasLifted && !serving) FinishServing();

            if (bagHand < 0)
            {
                if (leftDown && TryLiftBag(0, left)) return;
                if (rightDown) TryLiftBag(1, right);
                return;
            }

            var bag = bagHand == 0 ? left : right;
            var free = bagHand == 0 ? right : left;
            if (!pouch.IsHeld) { Release(false); return; }
            lostBag = !bag.Valid || (lostBag && bag.Span > .03f);
            if (!lostBag && bag.Span >= .045f)
            {
                pouch.MoveHeld(bag.Position, bag.Rotation);
                Release(true);
                return;
            }
            if (!lostBag) pouch.MoveHeld(bag.Position, bag.Rotation);

            if (serving)
            {
                if (serving.Remaining == 0 || (finishing && !mouth.GetComponent<SnapZone>().SnappedObject))
                { FinishServing(); return; }
                if (finishing) return;
                lostServing = !free.Valid || (lostServing && free.Span > .03f);
                if (lostBag || lostServing) { mouth.Observe(serving, player.Player, false, 0); return; }
                if (free.Span >= .045f) { FinishServing(); return; }
                serving.MoveHeld(free.Position, free.Rotation);
                finishing = mouth.Observe(serving, player.Player, true, delta);
                return;
            }
            if (!lostBag && (bagHand == 0 ? rightDown : leftDown))
            {
                serving = pouch.LiftBiscuit(free.Position, biscuitReach);
                if (serving && sharedBelt) serving.transform.SetParent(player.locomotion.transform, true);
            }
        }

        bool Pressed(int index, PinchSample sample)
        {
            if (!sample.Valid) { armed[index] = false; return false; }
            if (sample.Span >= .045f) { armed[index] = true; return false; }
            if (sample.Span > .03f || !armed[index]) return false;
            armed[index] = false;
            return true;
        }

        bool TryLiftBag(int index, PinchSample sample)
        {
            if (!pouch.isActiveAndEnabled || (sample.Position - pouch.GripPosition).sqrMagnitude > bagReach * bagReach) return false;
            if (sharedBelt)
            {
                if (!sharedBelt.TryTake(pouch, true)) return false;
                pouch.transform.SetParent(player.locomotion.transform, true);
            }
            else
            {
                if (!player.Input.TryAcquireInteraction(this, out claim)) return false;
                if (!pouch.Take()) { player.Input.ReleaseInteraction(this, claim); claim = 0; return false; }
            }
            bagHand = index;
            lostBag = false;
            pouch.MoveHeld(sample.Position, sample.Rotation);
            if (!sharedBelt && player.skills) player.skills.InvalidateEarlierVoice();
            return true;
        }

        void FinishServing()
        {
            if (!serving && (!pouch || !pouch.HasLifted)) return;
            if (mouth)
            {
                if (finishing) mouth.CancelFinish();
                else mouth.ResetContact();
            }
            if (pouch) pouch.ReturnOrConsume(serving);
            serving = null;
            finishing = false;
            lostServing = false;
        }

        void Release(bool putAway)
        {
            FinishServing();
            if (claim != 0 && player) player.Input.ReleaseInteraction(this, claim);
            claim = 0;
            if (bagHand < 0) return;
            bagHand = -1;
            if (!pouch) return;
            if (sharedBelt)
            {
                sharedBelt.ReleaseAuxiliary(pouch, putAway);
                if (!pouch.Dock && !pouch.IsHeld) pouch.transform.SetParent(null, true);
                return;
            }
            pouch.Drop();
            var home = pouch.PickupSource as ToolBeltSlot;
            if (putAway && home && home.opening &&
                pouch.DistanceToOpeningSquared(home.opening.position) <= returnReach * returnReach)
                pouch.ReturnToPickupSource();
        }

        internal void ResetInteraction()
        {
            Release(false);
            armed[0] = armed[1] = false;
        }

        void OnDisable() => ResetInteraction();
    }
}


