using System;
using NarutoVR.SealCombat.Rpg;
using UnityEngine;

namespace NarutoVR.SealCombat.Items
{
    [DisallowMultipleComponent, DefaultExecutionOrder(365)]
    public sealed class ChapterRationSupply : MonoBehaviour, IRpgCheckpointEquipment
    {
        [SerializeField] internal TravelRationInteraction interaction;
        [SerializeField] internal TravelRationPouch pouchPrefab;
        [SerializeField] internal ToolBeltSlot centralPocket;
        RpgRationCheckpoint pending;

        public bool HasPouch => interaction && interaction.pouch;
        bool Ready => interaction && interaction.sharedBelt && interaction.sharedBelt.Initialised &&
            interaction.sharedBelt.isActiveAndEnabled && interaction.player.IsReady;

        // Optional quest/pickup UnityEvent entry. No chapter grants a pouch by default.
        public void GrantFromReward() => TryGrant();

        public bool TryGrant()
        {
            if (!Ready || HasPouch || pending != null || !pouchPrefab || !centralPocket ||
                centralPocket.SnappedObject || !interaction.player.CanAct || interaction.player.StateCommitInProgress) return false;
            var pouch = Spawn(centralPocket.opening.position, centralPocket.opening.rotation);
            if (pouch.TryDock(centralPocket, Quaternion.Euler(pouch.stowEuler))) return true;
            RemovePouch();
            return false;
        }

        TravelRationPouch Spawn(Vector3 position, Quaternion rotation)
        {
            var pouch = Instantiate(pouchPrefab, position, rotation);
            if (pouch.gameObject.scene != gameObject.scene)
                UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(pouch.gameObject, gameObject.scene);
            pouch.transform.SetParent(interaction.player.locomotion.transform, true);
            pouch.home = centralPocket;
            interaction.pouch = pouch;
            return pouch;
        }

        public void CaptureEquipment(RpgCheckpointData checkpoint)
        {
            if (pending != null) { checkpoint.ration = pending; return; }
            if (!HasPouch) return;
            var pouch = interaction.pouch;
            var source = pouch.Dock ? pouch.Dock : pouch.IsHeld ? pouch.PickupSource : null;
            var slot = source as ToolBeltSlot;
            int index = slot ? Array.IndexOf(interaction.sharedBelt.slots, slot) : -1;
            var rotation = pouch.transform.rotation;
            if (index >= 0)
                rotation = pouch.IsHeld ? pouch.PickupRotation : Quaternion.Inverse(slot.opening.rotation) * slot.LandingPose.rotation;
            var position = pouch.transform.position;
            checkpoint.ration = new RpgRationCheckpoint {
                owned = true, spentMask = pouch.ConsumedMask, pocket = index + 1,
                x = position.x, y = position.y, z = position.z,
                qx = rotation.x, qy = rotation.y, qz = rotation.z, qw = rotation.w
            };
        }

        public void RestoreEquipment(RpgCheckpointData checkpoint)
        {
            RemovePouch();
            pending = checkpoint.ration != null && checkpoint.ration.owned ? checkpoint.ration : null;
        }

        void LateUpdate()
        {
            if (pending == null || !Ready) return;
            var saved = pending;
            pending = null;
            var rotation = new Quaternion(saved.qx, saved.qy, saved.qz, saved.qw);
            var position = new Vector3(saved.x, saved.y, saved.z);
            var slot = saved.pocket > 0 && saved.pocket <= interaction.sharedBelt.slots.Length
                ? interaction.sharedBelt.slots[saved.pocket - 1] as ToolBeltSlot : null;
            var pouch = Spawn(position, slot && slot.opening ? slot.opening.rotation * rotation : rotation);
            pouch.RestoreContents(saved.spentMask);
            if (slot && slot.opening && !slot.SnappedObject)
            {
                pouch.transform.position = slot.opening.position;
                if (pouch.TryDock(slot, rotation)) return;
                pouch.transform.position = position;
            }
            pouch.transform.SetParent(null, true);
            var body = pouch.GetComponent<Rigidbody>();
            body.isKinematic = false;
            body.useGravity = true;
        }

        void RemovePouch()
        {
            if (!interaction) return;
            interaction.ResetInteraction();
            var pouch = interaction.pouch;
            if (!pouch) return;
            interaction.pouch = null;
            pouch.gameObject.SetActive(false);
            Destroy(pouch.gameObject);
        }

        void OnDestroy() => RemovePouch();
    }
}
