using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NarutoVR.SealCombat.Rpg;
using Oculus.Interaction;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Scene = UnityEngine.SceneManagement.Scene;

namespace NarutoVR.SealCombat.Editor
{
    [InitializeOnLoad]
    public static class Chapter02CandidatePublisher
    {
        const string Target = "Assets/Scene/Chapter02_SuspendedPath.unity";
        const string Candidate = "Tools/Validation/Evidence/Chapter02Assembly/combined-1126/Chapter02_SuspendedPath.candidate.unity";
        const string Control = "D:/Temp/Ch02TenonIntegration1125/Joint1126/withhands";
        const string Original = "e82f24bdef5532e0a39fc9551860a00f7de6aa9c7a15277f842b1d1c8a33681f";
        const string Approved = "cf4b60b25f15aad2dd8400e8d302d97e470407ebaa11867ac1b5e23c216bb854";
        static Chapter02CandidatePublisher() { EditorApplication.update += Poll; }

        static string Hash(string path)
        {
            using var sha = SHA256.Create();
            using var input = File.OpenRead(path);
            return BitConverter.ToString(sha.ComputeHash(input)).Replace("-","").ToLowerInvariant();
        }

        static void Need(bool ok,string message)
        {
            if (!ok) throw new InvalidOperationException(message);
        }

        static void Poll()
        {
            if (Application.isBatchMode || !Application.dataPath.Replace('\\','/').Equals("D:/UnityProjects/NarutoVR/Assets",StringComparison.OrdinalIgnoreCase) ||
                EditorApplication.isCompiling || EditorApplication.isUpdating) return;
            var request = Path.Combine(Control,"main.request");
            if (!File.Exists(request)) return;
            var op = File.ReadAllText(request).Trim();
            if(op!="inspect" && op!="publish")return;
            File.Delete(request);
            var log = Path.Combine(Control,"main-"+op+".txt");
            void Record(string line) => File.AppendAllText(log,line+"\n");
            try
            {
                Record(DateTimeOffset.Now.ToString("O")+" Unity "+Application.unityVersion+" pid="+System.Diagnostics.Process.GetCurrentProcess().Id);
                var scenes = Enumerable.Range(0,SceneManager.sceneCount).Select(SceneManager.GetSceneAt).ToArray();
                foreach(var s in scenes)Record($"scene={s.path} loaded={s.isLoaded} dirty={s.isDirty} active={s==SceneManager.GetActiveScene()}");
                Record("play="+EditorApplication.isPlayingOrWillChangePlaymode+" disk="+Hash(Target)+" meta="+Hash(Target+".meta"));
                if(op=="inspect"){Record("INSPECTED");return;}
                Need(!EditorApplication.isPlayingOrWillChangePlaymode && !BuildPipeline.isBuildingPlayer, "Editor busy with play or build");
                Need(Hash(Target)==Original && Hash(Candidate)==Approved,"Disk input changed since handoff");
                var original = SceneManager.GetSceneByPath(Target);
                Need(original.IsValid() && original.isLoaded && !original.isDirty,"Chapter is not loaded and clean; no write");
                Need(scenes.Length==1 && original==SceneManager.GetActiveScene(),"Expected only the active chapter; no write");
                var meta=Hash(Target+".meta");
                var backup=Path.Combine(Control,"main-before-"+DateTime.Now.ToString("yyyyMMddHHmmssfff")+".unity");
                var temp=Path.Combine(Control,"main-staged-"+Guid.NewGuid().ToString("N")+".unity");
                File.Copy(Candidate,temp);
                Need(Hash(temp)==Approved,"Staging hash changed");
                var scratch = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
                bool replaced=false;
                try
                {
                    Need(EditorSceneManager.CloseScene(original,true),"Could not close verified clean original scene");
                    Need(Hash(Target)==Original,"Guarded baseline changed before replace");
                    File.Replace(temp,Path.GetFullPath(Target),backup);
                    replaced=true;
                    Need(Hash(backup)==Original && Hash(Target)==Approved && Hash(Target+".meta")==meta,"Atomic replacement hash check");
                    AssetDatabase.ImportAsset(Target,ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
                    var final=EditorSceneManager.OpenScene(Target,OpenSceneMode.Additive);
                    Need(SceneManager.SetActiveScene(final),"Could not restore active chapter");
                    var rs=final.GetRootGameObjects();
                    var p=rs.SelectMany(r=>r.GetComponentsInChildren<LinearRpgController>(true)).Single();
                    var input=p.handTracking.xrHandsSource;
                    var hands=rs.SelectMany(r=>r.GetComponentsInChildren<HandVisual>(true)).ToArray();
                    Need(input && input.IsConfigured && hands.Length==2,"Invalid official hand count/tracking source");
                    foreach(bool left in new[]{true,false})
                    {
                        var side=left?"Left":"Right";
                        var hand=left?input.leftHand:input.rightHand;
                        const string pack="Packages/com.meta.xr.sdk.interaction/Runtime/";
                        var prefab=pack+"UnityXR/Prefabs/Hands/UnityXRHandVisual"+side+".prefab";
                        var visual=hands.Single(h=>PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(h.gameObject)==prefab);
                        var so=new SerializedObject(visual);
                        var sk=(SkinnedMeshRenderer)so.FindProperty("_openXRSkinnedMeshRenderer").objectReferenceValue;
                        Need(visual.enabled && visual.gameObject.activeInHierarchy && so.FindProperty("_hand").objectReferenceValue==hand &&
                            sk && AssetDatabase.GetAssetPath(sk.sharedMesh)==pack+"Meshes/OpenXR"+side+"Hand.fbx" &&
                            so.FindProperty("_openXRJointTransforms").arraySize==26, "Official model or input mismatch "+side);
                        Record(side+" model="+prefab+" input="+hand.name+" vertices="+sk.sharedMesh.vertexCount+" joints=26");
                    }
                    var objective=rs.SelectMany(r=>r.GetComponentsInChildren<WorkshopTenonObjective>(true)).Single();
                    objective.ValidateObjective();
                    Need(objective.closedJaws.name=="LockedPins" && objective.openJaws.name=="OpenPins" &&
                        rs.SelectMany(r=>r.GetComponentsInChildren<Chapter02BridgeEquipment>(true)).Single().equipment.interaction.slots.Length==5,
                        "Candidate missing approved chapter bindings");
                    Need(!final.isDirty && Hash(Target)==Approved && Hash(Target+".meta")==meta,"Final readback failed");
                    Record("disk="+Hash(Target)+" meta="+meta+" baselineBackup="+backup+" dirty="+final.isDirty);
                }
                catch
                {
                    if (replaced && Hash(Target)==Approved && File.Exists(backup))
                    {
                        File.Copy(backup,temp,true);
                        File.Replace(temp,Path.GetFullPath(Target),null);
                        AssetDatabase.ImportAsset(Target,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
                        Record("Rolled back to "+Hash(Target));
                    }
                    var current=SceneManager.GetSceneByPath(Target);
                    if (current.IsValid() && current.isLoaded && !current.isDirty) EditorSceneManager.CloseScene(current,true);
                    SceneManager.SetActiveScene(EditorSceneManager.OpenScene(Target,OpenSceneMode.Additive));
                    throw;
                }
                finally
                {
                    if(scratch.IsValid() && scratch.isLoaded)EditorSceneManager.CloseScene(scratch,true);
                    if(File.Exists(temp))File.Delete(temp);
                }
                Record("PUBLISHED");
            }
            catch(Exception ex) {Record("STOP "+ex);}
        }
    }
}
