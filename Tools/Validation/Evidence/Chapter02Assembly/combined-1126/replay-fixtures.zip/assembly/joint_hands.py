from pathlib import Path
import hashlib
import json
import re

base=Path(__file__).parent
repo=Path('D:/UnityProjects/NarutoVR')
out=base/'Joint1126'
sub=out/'withhands'
sub.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ch1=repo/'Assets/Scene/Chapter01_Courtyard.unity'
ch1b=repo/'Assets/Scene/Chapter01_Awakening.unity'
prior=out/'Chapter02_SuspendedPath.candidate.unity'
assert digest(prior)=='f5d74c66207d7d01d2487d7240f7fa2779da771d7b3cf04c0a29a992a9b00c98'
def blocks(path):
    text=path.read_text(encoding='utf-8')
    split=list(re.finditer(r'^--- !u!\d+ &(-?\d+)(?: stripped)?$',text,re.M))
    return text,{m[1]:text[m.start():split[i+1].start() if i+1<len(split) else len(text)] for i,m in enumerate(split)}
_,donor=blocks(ch1)
_,awake=blocks(ch1b)
scene,target=blocks(prior)
guids=['67c4027c76c769346ab6711c6a38d07a','7c1640bff2820dd4ebbbc9aca5d3322d']
ids=['9043211110','9043211111','9043211112','9043211113']
assert all(k not in target and [l.rstrip() for l in donor[k].splitlines()]==[l.rstrip() for l in awake[k].splitlines()] for k in ids)
assert all(g in donor[k] and g not in scene for k,g in zip(ids[::2],guids))
for k in ('379468231','1508473943','1827239490'):
    assert k in target and k in donor
for k,side in [('9043211110','1508473943'),('9043211112','1827239490')]:
    assert re.search(r'propertyPath: _hand\s+value:\s+objectReference: \{fileID: '+side+r'\}',donor[k])
    assert 'm_TransformParent: {fileID: 379468229}' in donor[k]
parent=target['379468229']
for node in ids[1::2]:
    assert '  - {fileID: '+node+'}' in donor['379468229']
    assert node not in parent
insertion=''.join('  - {fileID: '+node+'}\n' for node in ids[1::2])
scene=scene.replace(parent,parent.replace('  m_Father:',insertion+'  m_Father:'))
assert scene.count('  showBoneLines: 1\n')==1
scene=scene.replace('  showBoneLines: 1\n','  showBoneLines: 0\n')
roots='--- !u!1660057539 &9223372036854775807'
assert scene.count(roots)==1
scene=scene.replace(roots,''.join(donor[i] for i in ids)+roots)
result=sub/'Chapter02_SuspendedPath.candidate.unity'
result.write_bytes(scene.encode('utf-8'))
readback=blocks(result)[1]
for k in ids:assert readback[k]==donor[k]
assert len(readback)==len(target)+4
meta_guids={}
for folder in ['Assets/Art/PlayerHands','Assets/Art/Characters']:
    for meta in (repo/folder).rglob('*.meta'):
        if meta.name.endswith(('.prefab.meta','.fbx.meta','.asset.meta')):
            m=re.search(r'^guid: (\w+)$',meta.read_text(encoding='utf-8-sig',errors='replace'),re.M)
            if m:meta_guids[m[1]]=meta.relative_to(repo).as_posix()
assert not any(g in scene for g in meta_guids)
report={'chapter01Courtyard':digest(ch1),'chapter01Awakening':digest(ch1b),'before':digest(prior),'after':digest(result),
        'sdkPrefabGuids':guids,'copiedChapter01Objects':ids,'xrSource':'379468231','leftHand':'1508473943','rightHand':'1827239490','customDirectRefs':0}
(sub/'hand-source.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
