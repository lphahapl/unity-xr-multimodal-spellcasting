using System;
using System.IO;
using System.Linq;
using NarutoVR.SealCombat.Enemies;
using NarutoVR.SealCombat.Rpg;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.XR.Management;
using Object = UnityEngine.Object;

namespace NarutoVR.SealCombat.Editor
{
    [InitializeOnLoad]
    public static class Joint1126Cold
    {
        const string Key = "Joint1126.ColdSeated";
        static int readyFrames;
        static double began;
        static Joint1126Cold() { EditorApplication.update += CheckState; }

        public static void Run()
        {
            EditorSceneManager.OpenScene(T25AltarRoomInstaller.ScenePath);
            var p = Object.FindFirstObjectByType<LinearRpgController>();
            p.autoLoad = true;
            p.saveFileName = "ch02-joint-seated-" + Guid.NewGuid().ToString("N") + ".json";
            File.Copy(Path.Combine(Joint1126Build.ReportDir, "seated.json"), Path.Combine(Application.persistentDataPath,p.saveFileName));
            if (XRGeneralSettings.Instance) XRGeneralSettings.Instance.InitManagerOnStart = false;
            SessionState.SetBool(Key, true);
            EditorApplication.EnterPlaymode();
        }

        static void Check(bool passed, string message)
        {
            if (!passed) throw new InvalidOperationException(message);
            File.AppendAllText(Path.Combine(Joint1126Build.ReportDir,"cold-seated.txt"), "PASS " + message + "\n");
        }

        static void CheckState()
        {
            if (!SessionState.GetBool(Key, false) || !Application.isPlaying || !EditorApplication.isPlaying) return;
            if (began == 0) began = EditorApplication.timeSinceStartup;
            try
            {
                var p = Object.FindFirstObjectByType<LinearRpgController>();
                if (EditorApplication.timeSinceStartup - began > 90) throw new TimeoutException(p.Status);
                if (!p.CanAct || ++readyFrames < 4) return;
                var obj = Object.FindFirstObjectByType<WorkshopTenonObjective>();
                var bridge = Object.FindFirstObjectByType<Chapter02BridgeEquipment>();
                var post = Object.FindFirstObjectByType<StoneCarrierPost>();
                var rooms = Object.FindObjectsByType<CombatRoomEncounter>(FindObjectsInactive.Include, FindObjectsSortMode.None);
                Check(p.StageAt(p.StageIndex).stageId == "CH02_B_DESCENT" && obj.IsSeated, "Cold seated save opens at B descent with tenon installed");
                Check(!obj.tenon.enabled && Vector3.Distance(obj.tenon.transform.position, obj.socket.bottom.position) < .001f,
                    "Original tenon stays seated at original socket bottom");
                Check(!obj.roof.enabled && !obj.courtyard.enabled && !obj.closedJaws.activeSelf && obj.openJaws.activeInHierarchy,
                    "Workshop rooms dormant, B1 shows open pins");
                Check(!obj.consoleFault.activeSelf && obj.consoleReady.activeSelf && obj.poweredCircuits.All(c => c.activeSelf),
                    "Blue console and both powered circuits persist");
                Check(!bridge.brokenBarrier.activeSelf && bridge.repairedDeck.activeInHierarchy &&
                    bridge.equipment.pen.Dock == bridge.equipment.pen.home, "Repaired bridge and original pen in sleeve persist");
                Check(rooms.Count(r => r.spawnPoints != null && r.spawnPoints.Any(s => s.point == post.transform && s.enemyId == "stone-carrier")) == 1 &&
                    post.basket && post.basket.slot, "Single altar carrier spawn and original basket slot remain wired");
                Check(true, "END");
                SessionState.EraseBool(Key);
                EditorApplication.Exit(0);
            }
            catch (Exception e)
            {
                File.AppendAllText(Path.Combine(Joint1126Build.ReportDir,"cold-seated.txt"), "FAIL " + e);
                SessionState.EraseBool(Key);
                EditorApplication.Exit(1);
            }
        }
    }
}
