using System;
using System.IO;
using System.Linq;
using System.Reflection;
using NarutoVR.SealCombat.Rpg;
using NarutoVR.SealLab;
using Oculus.Interaction;
using Oculus.Interaction.Input;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace NarutoVR.SealCombat.Editor
{
    public static class JointOfficialHands
    {
        static void Check(bool pass,string message)
        {
            File.AppendAllText(Path.Combine(Joint1126Build.ReportDir,"official-hands.txt"), (pass ? "PASS " : "FAIL ")+message+"\n");
            if (!pass) throw new InvalidOperationException(message);
        }

        static bool Custom(string path) => path.StartsWith("Assets/Art/PlayerHands/",StringComparison.OrdinalIgnoreCase) ||
            path.StartsWith("Assets/Art/Characters/ShenShang",StringComparison.OrdinalIgnoreCase) ||
            path.StartsWith("Assets/Art/Characters/TrackedAvatars/",StringComparison.OrdinalIgnoreCase);

        public static void Inspect(bool play)
        {
            var scene = SceneManager.GetActiveScene();
            var roots = scene.GetRootGameObjects();
            var player = roots.SelectMany(g=>g.GetComponentsInChildren<LinearRpgController>(true)).Single();
            var source = player.handTracking.xrHandsSource;
            var visuals = roots.SelectMany(g=>g.GetComponentsInChildren<HandVisual>(true)).ToArray();
            string state=play?"Play":"Edit";
            Check(source && source.IsConfigured && visuals.Length==2,state+" exactly two visuals and a configured bilateral XR Hands source");
            Check(!roots.SelectMany(g=>g.GetComponentsInChildren<SealLabView>(true)).Any(v=>v.showBoneLines),
                state+" debug skeleton lines disabled");
            Check(!AssetDatabase.GetDependencies(scene.path,true).Any(Custom),state+" transitive scene references exclude custom hand and Shen Shang character assets");
            Check(!roots.SelectMany(g=>g.GetComponentsInChildren<SkinnedMeshRenderer>(true)).Any(r=>r.sharedMesh && Custom(AssetDatabase.GetAssetPath(r.sharedMesh))),
                state+" no player body or custom hand meshes instantiated");
            var updateVisibility=typeof(HandVisual).GetMethod("UpdateVisibility", BindingFlags.NonPublic|BindingFlags.Instance);
            foreach(var left in new[]{true,false})
            {
                var side=left?"Left":"Right";
                var sourceHand=left?source.leftHand:source.rightHand;
                var opposite=left?source.rightHand:source.leftHand;
                var prefab="Packages/com.meta.xr.sdk.interaction/Runtime/UnityXR/Prefabs/Hands/UnityXRHandVisual"+side+".prefab";
                var mesh="Packages/com.meta.xr.sdk.interaction/Runtime/Meshes/OpenXR"+side+"Hand.fbx";
                var visual=visuals.Single(v=>new SerializedObject(v).FindProperty("_hand").objectReferenceValue==sourceHand);
                var data=new SerializedObject(visual);
                var renderer=(SkinnedMeshRenderer)data.FindProperty("_openXRSkinnedMeshRenderer").objectReferenceValue;
                var joints=data.FindProperty("_openXRJointTransforms");
                Check(visual.enabled && visual.gameObject.activeInHierarchy && visual.transform.IsChildOf(source.transform) &&
                    sourceHand!=opposite && (!play ? PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(visual.gameObject)==prefab &&
                    data.FindProperty("_hand").prefabOverride : ReferenceEquals(visual.Hand,sourceHand)),state+" "+side+" official component bound to "+sourceHand.name);
                Check(renderer && !renderer.forceRenderingOff && renderer.sharedMesh && AssetDatabase.GetAssetPath(renderer.sharedMesh)==mesh &&
                    renderer.rootBone && joints.arraySize==26 && Enumerable.Range(0,26).All(i=>joints.GetArrayElementAtIndex(i).objectReferenceValue),
                    state+" "+side+" "+mesh+" vertices="+renderer.sharedMesh.vertexCount+" joints=26");
                if(!play)continue;
                var observation=sourceHand.GetData();
                var origin=observation.RootPoseOrigin;
                try
                {
                    observation.RootPoseOrigin=PoseOrigin.SyntheticPose;
                    updateVisibility.Invoke(visual,null);
                    Check(visual.IsVisible && renderer.enabled && !visual.ForceOffVisibility,
                        side+" SDK shows the renderer for a synthetic valid tracking sample on its original input");
                    observation.RootPoseOrigin=PoseOrigin.None;
                    updateVisibility.Invoke(visual,null);
                    Check(!visual.IsVisible && !renderer.enabled,side+" SDK hides the renderer on tracking loss");
                }
                finally {observation.RootPoseOrigin=origin; updateVisibility.Invoke(visual,null);}
            }
        }
    }
}
