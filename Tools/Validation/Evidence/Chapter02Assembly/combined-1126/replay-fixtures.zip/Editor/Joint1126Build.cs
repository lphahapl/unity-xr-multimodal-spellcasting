using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using NarutoVR.SealCombat.Rpg;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace NarutoVR.SealCombat.Editor
{
    public static class Joint1126Build
    {
        public const string Art = "Assets/Art/Props/WorkshopPedestalB1/OrnamentTrial/WorkshopPedestal_B1_OrnamentTrial.prefab";
        const string ScenePath = T25AltarRoomInstaller.ScenePath;
        public static string ReportDir => Environment.GetEnvironmentVariable("JOINT1126_REPORT");

        static void Require(bool ok, string message)
        {
            if (!ok) throw new InvalidOperationException(message);
            File.AppendAllText(Path.Combine(ReportDir, "assembly.txt"), message + "\n");
        }

        static string Digest(string path)
        {
            using var hash = SHA256.Create();
            using var stream = File.OpenRead(path);
            return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }

        static void Verify(Scene scene)
        {
            var nodes = scene.GetRootGameObjects().SelectMany(r => r.GetComponentsInChildren<Transform>(true)).ToArray();
            var objective = nodes.Select(t => t.GetComponent<WorkshopTenonObjective>()).Single(o => o);
            var stand = nodes.Single(t => t.name == "主榫与承座");
            var instance = scene.GetRootGameObjects().Single(r => PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(r) == Art);
            Require(!stand.GetComponent<MeshRenderer>().enabled && stand.GetComponents<BoxCollider>().Count(c => c.enabled) == 2,
                "Original two support colliders enabled, whitebox seat renderer hidden");
            Require(objective.closedJaws == instance.transform.Find("LockedPins").gameObject &&
                    objective.openJaws == instance.transform.Find("OpenPins").gameObject &&
                    objective.closedJaws.activeSelf && !objective.openJaws.activeSelf, "Approved pins bound and initially locked");
            float gap = Vector3.Distance(objective.holder.position, instance.transform.Find("Holder").position);
            Require(gap < .0002f, $"Art marker against original gameplay holder: {gap:F6} m, yaw {instance.transform.eulerAngles.y:F3}");
            Require(instance.GetComponentsInChildren<Collider>(true).Length == 0, "Art adds no collision");
            objective.ValidateObjective();
            Require(!T25AltarRoomInstaller.Apply(scene), "Altar installer is idempotent on the combined scene");
        }

        public static void BuildAndPlay()
        {
            Require(Application.isBatchMode && Application.dataPath.Replace('\\','/').EndsWith("/Ch02TenonIntegration1125/Project/Assets"),
                "Isolated project");
            Require(Digest(ScenePath) == "894c19d83a27416978e423d86e6d4bead69de3a5f3fada354b7580af02f0772c", "Bridge input matches handoff SHA-256");
            var scene = EditorSceneManager.OpenScene(ScenePath);
            Require(T25AltarRoomInstaller.Apply(scene), "Altar applied once");
            var nodes = scene.GetRootGameObjects().SelectMany(r => r.GetComponentsInChildren<Transform>(true)).ToArray();
            var objective = nodes.Select(t => t.GetComponent<WorkshopTenonObjective>()).Single(o => o);
            var stand = nodes.Single(t => t.name == "主榫与承座");
            var approved = AssetDatabase.LoadAssetAtPath<GameObject>(Art);
            Require(approved, "Approved B1 ornament variant present");
            var body = (GameObject)PrefabUtility.InstantiatePrefab(approved, scene);
            var direction = Vector3.ProjectOnPlane(objective.courtyard.area.bounds.center - stand.position, Vector3.up);
            body.transform.SetPositionAndRotation(stand.position, Quaternion.LookRotation(direction.normalized, Vector3.up));
            PrefabUtility.RecordPrefabInstancePropertyModifications(body.transform);
            stand.GetComponent<MeshRenderer>().enabled = false;
            objective.closedJaws.SetActive(false);
            objective.openJaws.SetActive(false);
            objective.closedJaws = body.transform.Find("LockedPins").gameObject;
            objective.openJaws = body.transform.Find("OpenPins").gameObject;
            Verify(scene);
            EditorSceneManager.MarkSceneDirty(scene);
            Require(EditorSceneManager.SaveScene(scene), "Candidate serialized");
            Verify(EditorSceneManager.OpenScene(ScenePath));
            File.Copy(ScenePath, Path.Combine(ReportDir, "Chapter02_SuspendedPath.candidate.unity"), true);
            File.AppendAllText(Path.Combine(ReportDir, "assembly.txt"), "candidate SHA256 " + Digest(ScenePath) + "\n");
            Chapter02BridgeEquipmentPlayChecks.Run();
        }
    }
}
