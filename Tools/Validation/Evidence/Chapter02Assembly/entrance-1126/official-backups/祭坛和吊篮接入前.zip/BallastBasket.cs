using NarutoVR.SealCombat.Rpg;
using UnityEngine;
using UnityEngine.Events;

namespace NarutoVR.SealCombat.Enemies
{
    /// <summary>A 篮只接受该出生点在本轮持有的镇石。代表点进入篮体后开放符力，实际受力且抵达槽心才能入槽。</summary>
    [DisallowMultipleComponent]
    public sealed class BallastBasket : MonoBehaviour
    {
        [InspectorName("乘员空间")] public BoxCollider passengerVolume;
        [InspectorName("槽内石块中心")] public Transform slot;
        [InspectorName("承接半径（米）"), Range(.5f,.8f)] public float captureRadius = .65f;
        [InspectorName("镇石就位")] public UnityEvent onDocked = new();
        public bool Boarded { get; private set; }
        public BallastStone Stone { get; private set; }
        Transform player;
        StoneCarrierPost owner;
        CombatRoomEncounter encounter;
        bool requiresClear;

        internal bool TryBind(StoneCarrierPost source, BallastStone stone, Transform representative, CombatRoomEncounter room)
        {
            if (owner && owner != source) return false;
            if (Stone != stone) ResetBinding(source);
            owner = source;
            Stone = stone;
            player = representative;
            encounter = room;
            requiresClear = room;
            return true;
        }
        internal void ResetBinding(StoneCarrierPost source)
        {
            if (owner && owner != source) return;
            if (Stone && Stone.State != BallastStone.Phase.Carried)
            {
                Stone.gameObject.SetActive(false);
                Destroy(Stone.gameObject);
            }
            Stone = null;
            owner = null;
            player = null;
            encounter = null;
            requiresClear = Boarded = false;
        }
        // 读回已完成运输的安全落点时，从同一工奴配置还原槽内实物；不重发一次性入槽事件。
        internal void RestoreCheckpointStone(BallastStone prefab, bool docked)
        {
            if (!docked)
            {
                if (!owner && Stone) ResetBinding(null);
                return;
            }
            if (Stone) return;
            Stone = Instantiate(prefab, slot.position, slot.rotation);
            Stone.Dock(slot);
            Boarded = true;
        }

        void FixedUpdate()
        {
            if (!Stone || Stone.State != BallastStone.Phase.Dropped || !passengerVolume ||
                !passengerVolume.enabled || !slot || !player || !player.gameObject.activeInHierarchy ||
                (requiresClear && (!encounter || !encounter.isActiveAndEnabled || !encounter.IsComplete))) return;
            if (!Boarded)
            {
                var local = passengerVolume.transform.InverseTransformPoint(player.position) - passengerVolume.center;
                var half = passengerVolume.size * .5f;
                if (Mathf.Abs(local.x) > half.x || Mathf.Abs(local.y) > half.y || Mathf.Abs(local.z) > half.z) return;
                Boarded = true;
                Stone.AllowGlyph();
            }
            if (!Stone.MovedByGlyph || (Stone.transform.position - slot.position).sqrMagnitude > captureRadius * captureRadius) return;
            Stone.Dock(slot);
            onDocked.Invoke();
        }
    }
}
