using System;
using System.IO;
using System.Linq;
using Oculus.Interaction;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace QuestHandTrial
{
    public static class QuestRecordedTrialScene
    {
        const string Base="Assets/QuestHandTrial/";
        const string Output="D:/Temp/QuestHandReview1127/trial/Review/";
        [MenuItem("Tools/Quest Hand Trial/Create offline replay scene")]
        public static void Create()
        {
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var light=new GameObject("Key").AddComponent<Light>();
            light.type=LightType.Directional;light.intensity=1.65f;light.transform.rotation=Quaternion.Euler(57,-38,12);
            var fill=new GameObject("Fill").AddComponent<Light>();fill.type=LightType.Directional;
            fill.intensity=.7f;fill.transform.rotation=Quaternion.Euler(-35,140,-15);
            RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.ambientLight=Color.gray;
            var viewer=new GameObject("Recorded Frame Viewer").AddComponent<QuestRecordedPoseViewer>();
            var camera=new GameObject("Comparison Camera").AddComponent<Camera>();camera.tag="MainCamera";
            camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(.12f,.14f,.16f);
            camera.orthographic=true;camera.nearClipPlane=.005f;camera.farClipPlane=3;
            viewer.viewer=camera;viewer.recordedFrames=AssetDatabase.LoadAssetAtPath<TextAsset>(Base+"RecordedFrames.txt");
            viewer.metaVisuals=new[]{"Left","Right"}.Select(s=>AssetDatabase.LoadAssetAtPath<GameObject>(
                "Packages/com.meta.xr.sdk.interaction/Runtime/UnityXR/Prefabs/Hands/UnityXRHandVisual"+s+".prefab")).ToArray();
            viewer.unityModels=new[]{"Left","Right"}.Select(s=>AssetDatabase.LoadAssetAtPath<GameObject>(Base+"Models/"+s+"Hand.fbx")).ToArray();
            viewer.neutral=AssetDatabase.LoadAssetAtPath<Material>(Base+"NeutralReference.mat");
            if(!EditorSceneManager.SaveScene(scene, Base+"QuestHandRecordedFrames.unity"))throw new IOException("Cannot save QA scene");
        }
        public static void BuildAndPlay()
        {
            try { QuestHandTrialModes.Verify(); QuestHandComparisonBuild.Run(); RunPlay(); }
            catch(Exception ex) { File.WriteAllText(Output+"combined-error.txt",ex.ToString());EditorApplication.Exit(1); }
        }
        public static void RunPlay()
        {
            Create();
            SessionState.SetInt("QuestHandTrialPlayPhase",0);
            SessionState.SetBool("QuestHandTrialPlayActive",true);
            EditorApplication.EnterPlaymode();
        }
        [InitializeOnLoadMethod] static void Resume()
        {
            EditorApplication.update+=Update;
        }
        static void Update()
        {
            if (!SessionState.GetBool("QuestHandTrialPlayActive",false) || !EditorApplication.isPlaying || EditorApplication.isCompiling) return;
            if(Time.frameCount<5)return;
            try
            {
                var viewer=Object.FindFirstObjectByType<QuestRecordedPoseViewer>();
                var hands=Object.FindObjectsByType<OfficialHandDisplayTrial>(FindObjectsSortMode.None);
                if (!viewer||hands.Length!=2) throw new InvalidOperationException("Incomplete replay scene");
                int phase=SessionState.GetInt("QuestHandTrialPlayPhase",0);
                if(phase==0)
                {
                    foreach(var h in hands)if(!h.existing.IsVisible || h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("A visibility");
                    viewer.display=OfficialHandDisplayTrial.DisplayMode.UnityFixedLength;viewer.frameIndex=4;viewer.preserveBilateralPose=true;
                    SessionState.SetInt("QuestHandTrialPlayPhase",1);SessionState.SetInt("QuestHandTrialAfterFrame",Time.frameCount+3);return;
                }
                if(Time.frameCount<SessionState.GetInt("QuestHandTrialAfterFrame",0))return;
                if(phase==1)
                {
                    foreach(var h in hands)
                    {
                        if(h.existing.IsVisible || !h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("B visibility");
                        var replay=(ReplayHand)h.existing.Hand;var observation=replay.sample;
                        observation.jointValid[10]=false;h.Refresh();
                        if(h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("Stale segment shown");
                        observation.jointValid[10]=true;observation.fresh=false;h.Refresh();
                        if(h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("Stale observation shown");
                        if(OfficialHandDisplayTrial.IsFreshAndComplete(observation,observation.observedAt+.5,.12f))throw new Exception("Age gate failed");
                        observation.fresh=true;
                        if(OfficialHandDisplayTrial.IsFreshAndComplete(observation,observation.observedAt+.5,.12f) || OfficialHandDisplayTrial.IsFreshAndComplete(observation,observation.observedAt-.1,.12f))
                            throw new Exception("Observation epoch gate failed");
                        h.Refresh();
                        if(!h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("Complete hand did not recover");
                        if(!h.existing.Hand.GetRootPose(out var wrist)||Vector3.Distance(wrist.position,h.Bones[1].position)>.0001f)throw new Exception("Wrist drift");
                    }
                    viewer.display=OfficialHandDisplayTrial.DisplayMode.CurrentMeta;
                    SessionState.SetInt("QuestHandTrialPlayPhase",2);SessionState.SetInt("QuestHandTrialAfterFrame",Time.frameCount+3);return;
                }
                foreach(var h in hands)if(!h.existing.IsVisible||h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("A restore");
                File.WriteAllText(Output+"replay-play.txt","PASS initialized recorded Quest, two sides / A > B > A native visibility / change captured pose / bilateral wrist registration / missing fingertip hides / stale reports hide / future and expired epochs rejected / full observation restores. "+Application.unityVersion);
                End(0);
            }
            catch(Exception ex){File.WriteAllText(Output+"replay-play-error.txt",ex.ToString());End(1);}
        }
        static void End(int code){SessionState.SetBool("QuestHandTrialPlayActive",false);EditorApplication.ExitPlaymode();EditorApplication.Exit(code);}
    }
}