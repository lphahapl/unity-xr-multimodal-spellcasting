using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using NarutoVR.SealCombat.Items;
using NarutoVR.SealCombat.Rpg;
using NarutoVR.SealLab;
using Oculus.Interaction;
using Oculus.Interaction.Input;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace QuestHandTrial
{
    public static class QuestHandComparisonBuild
    {
        const string Base = "Assets/QuestHandTrial/";
        const string Chapter = "Assets/Scene/Chapter02_SuspendedPath.unity";
        const string ChapterCopy = Base + "Chapter02_QuestHandDisplayAB.unity";
        const string Package = "Packages/com.meta.xr.sdk.interaction/Runtime/UnityXR/Prefabs/Hands/";
        const string Out = "D:/Temp/QuestHandReview1127/trial/Review/";
        [Serializable] public sealed class Record { public string key; public SealFrame frame; }
        static GameObject ObjectAsset(string path) => AssetDatabase.LoadAssetAtPath<GameObject>(path) ?? throw new IOException(path);
        static GameObject Model(bool left) => ObjectAsset(Base+"Models/"+(left?"Left":"Right")+"Hand.fbx");
        static GameObject Meta(bool left) => ObjectAsset(Package+"UnityXRHandVisual"+(left?"Left":"Right")+".prefab");
        static Material Neutral()
        {
            string path = Base + "NeutralReference.mat";
            var mat = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (mat) return mat;
            mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
            mat.SetColor("_BaseColor", new Color(.62f,.68f,.70f,1));
            mat.SetFloat("_Smoothness", .24f);
            AssetDatabase.CreateAsset(mat,path);
            return mat;
        }
        static OfficialHandDisplayTrial AddB(HandVisual visual, bool left, Transform parent, Material gray)
        {
            var node = new GameObject(left?"Left visual only":"Right visual only");
            node.transform.SetParent(parent, false);
            var test = node.AddComponent<OfficialHandDisplayTrial>();
            test.existing = visual; test.left = left; test.neutralPreview = gray;
            test.unityModel = ((GameObject)PrefabUtility.InstantiatePrefab(Model(left), node.transform)).transform;
            test.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled = false;
            return test;
        }
        [MenuItem("Tools/Quest Hand Trial/Build isolated chapter and render recorded poses")]
        public static void Run()
        {
            try { Build(); File.WriteAllText(Out+"success.txt","Unity "+Application.unityVersion+" "+DateTime.Now.ToString("O")); }
            catch (Exception ex) { File.WriteAllText(Out+"error.txt",ex.ToString()); throw; }
        }
        static void Build()
        {
            Directory.CreateDirectory(Out);
            var gray = Neutral();
            var chapter = EditorSceneManager.OpenScene(Chapter);
            Object.FindFirstObjectByType<LinearRpgController>().saveFileName="quest-hand-display-trial-ch02.json";
            var tracking = Object.FindFirstObjectByType<SealXRHandsSource>();
            if (!tracking) throw new Exception("Missing chapter SealXRHandsSource");
            var old = tracking.GetComponentsInChildren<HandVisual>(true).Where(h=>h.name.StartsWith("UnityXRHandVisual")).ToArray();
            if (old.Length != 2) throw new Exception("Unexpected chapter hands " + old.Length);
            var toggle = new GameObject("Quest 手部显示 A·B（仅隔离）").AddComponent<ChapterHandDisplaySelector>();
            toggle.transform.SetParent(tracking.transform, false);
            toggle.hands = old.Select(h=>AddB(h,h.name.EndsWith("Left"),toggle.transform,gray)).ToArray();
            var frameSource=Object.FindObjectsByType<NarutoVR.SealLab.SealLab>(FindObjectsSortMode.None).Single(l=>l.xrHandsSource==tracking);
            foreach(var hand in toggle.hands) hand.trackingFrames=frameSource;
            if (!EditorSceneManager.SaveScene(chapter, ChapterCopy)) throw new IOException(ChapterCopy);
            var watch = Object.FindFirstObjectByType<WristMenuController>().wornDevice.transform;
            var menu = Object.FindFirstObjectByType<WristMenuController>();
            var pen = Object.FindObjectsByType<GameItemBase>(FindObjectsInactive.Include, FindObjectsSortMode.None).Single(i=>i.name=="PhysicalMoGuiPen");
            var trialScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
            SceneManager.SetActiveScene(trialScene);
            var accessories = new GameObject("Chapter visual fittings");
            var watchCopy = Object.Instantiate(watch.gameObject);
            watchCopy.transform.localScale = watch.lossyScale;
            var wristOffset = menu.deviceOffset; var wristEuler = menu.deviceEuler;
            var penCopy = Object.Instantiate(pen.gameObject).GetComponent<GameItemBase>();
            penCopy.transform.localScale = pen.transform.lossyScale * pen.definition.heldScaleMultiplier;
            watchCopy.transform.SetParent(accessories.transform,true); penCopy.transform.SetParent(accessories.transform,true);
            foreach (var c in accessories.GetComponentsInChildren<Canvas>(true)) c.enabled = false;
            foreach (var l in accessories.GetComponentsInChildren<Light>(true)) l.enabled = false;
            foreach (var behaviour in accessories.GetComponentsInChildren<MonoBehaviour>(true)) if (behaviour) behaviour.enabled = false;
            accessories.SetActive(false);
            EditorSceneManager.CloseScene(chapter, true);
            var keyLight = new GameObject("Key").AddComponent<Light>();
            keyLight.type = LightType.Directional; keyLight.intensity = 1.65f; keyLight.transform.rotation=Quaternion.Euler(57,-38,12);
            var fill = new GameObject("Fill").AddComponent<Light>(); fill.type = LightType.Directional;
            fill.intensity=.7f; fill.transform.rotation = Quaternion.Euler(-35,140,-15);
            RenderSettings.ambientMode = AmbientMode.Flat; RenderSettings.ambientLight = new Color(.52f,.52f,.52f);
            var cam = new GameObject("Compare camera").AddComponent<Camera>();
            cam.orthographic = true; cam.nearClipPlane=.005f; cam.farClipPlane=3; cam.allowHDR=false; cam.allowMSAA=false;
            cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = new Color(.12f,.14f,.16f,1);
            var rows = new List<string>{"frame,hand,model,wristErrorMm,palmWidthMm,thumbIndexSpanMm,tipMaxMm,jointsMaxMm,jointRmsMm,axisMaxDegrees,vertices,weightedBones,skinVerticesFinite,largestWeightSumResidual,boneLengthsMm(thumb2-index2-middle2-ring2-little2)"};
            var surfaces = new List<string>{"frame,side,model,tip,verticesHalfWeightedByDistalOrTip,trackedToNearestVertexMm,furthestAlongFingerFromTrackedTipMm,landmarkErrorMm"};
            var fittings = new List<string>{"frame,hand,model,anchor,originErrorMm,trackingToMeshContactMm"};
            var bindRows = new List<string>{"hand,joint,index,localXmm,localYmm,localZmm,worldRelXmm,worldRelYmm,worldRelZmm"};
            var hands = new OfficialHandDisplayTrial[2];
            var inputs = new ReplayHand[2];
            for(int s=0;s<2;s++)
            {
                bool left=s==0;
                var root=(GameObject)PrefabUtility.InstantiatePrefab(Meta(left));
                var vis=root.GetComponent<HandVisual>();
                var input=root.AddComponent<ReplayHand>(); input.isLeft=left;
                vis.InjectHand(input); inputs[s]=input;
                var sourceSkin=vis.GetComponentInChildren<SkinnedMeshRenderer>(true);
                sourceSkin.sharedMaterial=gray; sourceSkin.updateWhenOffscreen=true;
                hands[s]=AddB(vis,left,null,gray); hands[s].Configure();
                foreach(var b in hands[s].unityModel.GetComponentsInChildren<SkinnedMeshRenderer>(true)){b.updateWhenOffscreen=true;b.sharedMaterial=gray;}
                for (int j=0;j<26;j++)
                {
                    var t=hands[s].Bones[j];var rel=hands[s].RestPositions[j]*1000f;
                    bindRows.Add($"{s},{t.name},{j},{t.localPosition.x*1000:F5},{t.localPosition.y*1000:F5},{t.localPosition.z*1000:F5},{rel.x:F5},{rel.y:F5},{rel.z:F5}");
                }
            }
            foreach(string line in File.ReadLines(Base+"RecordedFrames.txt"))
            {
                var record=JsonUtility.FromJson<Record>(line);
                foreach(bool pair in new[]{false,true})
                {
                    // Per-hand wrists aligned for close up; pair camera preserves actual bilateral distance and rotations.
                    var frame=record.frame;
                    for(int s=0;s<2;s++)
                    {
                        var snap=s==0?frame.left:frame.right;
                        var at=pair?snap.joints[1]:new Pose(new Vector3((s==0?-1:1)*.102f,0,0),Quaternion.identity);
                        inputs[s].Load(snap,at);hands[s].existing.UpdateSkeleton();hands[s].Apply(inputs[s].World,snap.scale);
                    }
                    bool pointFit = !pair && (record.key=="historical-right-curled-fingers" || record.key=="quest3-1127-middle");
                    for(int mode=0;mode<2;mode++)
                    {
                        for(int s=0;s<2;s++)
                        {
                            var h=hands[s];var a=h.existing.GetComponentInChildren<SkinnedMeshRenderer>(true);
                            var b=h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>(true);
                            a.enabled=mode==0;b.enabled=mode==1;
                            if(!pair)
                            {
                                var measured = mode==0 ? h.existing.Joints.ToArray() : h.Bones;
                                if (mode == 1)
                                {
                                    h.adaptTips=false;h.Apply(inputs[s].World,inputs[s].Scale);
                                    Surface(surfaces,record.key,s,"Unity authored fingertip",h.Bones,inputs[s].World,b);
                                    h.adaptTips=true;h.Apply(inputs[s].World,inputs[s].Scale);
                                }
                                Surface(surfaces,record.key,s,mode==0?"Meta":"Unity adapted fingertip",measured,inputs[s].World,mode==0?a:b);
                                rows.Add(Metrics(record.key,s==0?"left":"right",mode==0?"Meta":"Unity",measured,inputs[s].World,mode==0?a:b));
                            }
                        }
                        var corners=inputs.SelectMany(i=>i.World).Select(p=>p.position).ToArray();
                        if(pair)
                        {
                            var mid=(frame.left.joints[1].position+frame.right.joints[1].position)*.5f;
                            var view = -mid; view.y=.14f; if(view.sqrMagnitude<.04f)view=new Vector3(0,.4f,-.5f);
                            Fit(cam,corners,view.normalized,Vector3.up);
                        }
                        else Fit(cam,corners,new Vector3(0,1,-.36f).normalized,Vector3.forward);
                        string prefix=record.key+"-"+(pair?"paired":"wrist")+"-"+(mode==0?"A":"B");
                        Photograph(cam,Out+prefix+".png");
                        if (!pair && record.key=="quest3-1127-middle") QuestHandContour.Capture(cam,hands[0],mode==0?"A":"B");
                        if(pointFit)
                        {
                            var p=inputs[0].World; Vector3 wrist=p[1].position;
                            Vector3 normal=Vector3.Cross(p[7].position-wrist,p[22].position-wrist);
                            var mount=Quaternion.LookRotation((p[7].position+p[22].position)*.5f-wrist,-normal);
                            watchCopy.transform.SetPositionAndRotation(wrist+mount*wristOffset,mount*Quaternion.Euler(wristEuler));
                            p=inputs[1].World; wrist=p[1].position;
                            normal=Vector3.Cross(p[7].position-wrist,p[22].position-wrist);
                            Vector3 grip=(p[7].position+p[12].position)*.5f;
                            penCopy.transform.rotation=Quaternion.LookRotation(grip-wrist,normal);
                            penCopy.transform.position += grip-penCopy.GripPosition;
                            accessories.SetActive(true);watchCopy.SetActive(true);penCopy.gameObject.SetActive(true);
                            var fitPoints=new List<Vector3>(corners);
                            foreach(var renderer in accessories.GetComponentsInChildren<MeshRenderer>())
                            { var bd=renderer.bounds;if(bd.size.magnitude<.6f){fitPoints.Add(bd.max);fitPoints.Add(bd.min);} }
                            Fit(cam,fitPoints.ToArray(),new Vector3(0,1,-.7f).normalized,Vector3.forward);
                            Photograph(cam,Out+prefix+"-chapter-fit.png");
                            var measured=mode==0?hands[1].existing.Joints.ToArray():hands[1].Bones;
                            var measuredLeft=mode==0?hands[0].existing.Joints.ToArray():hands[0].Bones;
                            fittings.Add($"{record.key},left,{mode},wrist,{Vector3.Distance(watchCopy.transform.position,inputs[0].World[1].position+mount*wristOffset)*1000:F5},{Vector3.Distance(measuredLeft[1].position,inputs[0].World[1].position)*1000:F4}");
                            fittings.Add($"{record.key},right,{mode},pen,{Vector3.Distance(penCopy.GripPosition,grip)*1000:F5},{Vector3.Distance((measured[7].position+measured[12].position)*.5f,grip)*1000:F4}");
                            accessories.SetActive(false);
                        }
                    }
                }
                File.WriteAllLines(Out+"pose-metrics.csv",rows);
            }
            File.WriteAllLines(Out+"fingertip-surface.csv",surfaces);
            File.WriteAllLines(Out+"bind-axes.csv",bindRows);
            File.WriteAllLines(Out+"fittings.csv",fittings);
        }
        static string Metrics(string key,string side,string model,Transform[] measured,Pose[] input,SkinnedMeshRenderer skin)
        {
            float[] errors=measured.Select((t,i)=>Vector3.Distance(t.position,input[i].position)*1000f).ToArray();
            float Length(int a,int b)=>Vector3.Distance(measured[a].position,measured[b].position)*1000f;
            int[] tips={5,10,15,20,25}; float angle=0;
            foreach(int i in new[]{2,3,4,6,7,8,9,11,12,13,14,16,17,18,19,21,22,23,24})
                angle=Mathf.Max(angle,Vector3.Angle(measured[i+1].position-measured[i].position,input[i+1].position-input[i].position));
            var baked=new Mesh(); skin.BakeMesh(baked);
            bool finite = baked.vertices.All(v=>float.IsFinite(v.x)&&float.IsFinite(v.y)&&float.IsFinite(v.z));


            // Model importers can keep meshes CPU unreadable. Bones and baked vertices are available at inspection time.
            float residual=0;
            var data=skin.sharedMesh.GetAllBoneWeights();
            var counts=skin.sharedMesh.GetBonesPerVertex();
            {
                int k=0;foreach(var n in counts){float sum=0;for(int j=0;j<n;j++)sum+=data[k++].weight;residual=Mathf.Max(residual,Mathf.Abs(1-sum));}
            }
            string row=$"{key},{side},{model},{errors[1]:F4},{Length(7,22):F4},{Length(5,10):F4},{tips.Max(i=>errors[i]):F4},{errors.Max():F4},{Mathf.Sqrt(errors.Select(e=>e*e).Average()):F4},{angle:F4},{baked.vertexCount},{skin.bones.Length},{finite},{residual:F6},";
            Object.DestroyImmediate(baked);
            return row+string.Join("/",new[]{3,7,12,17,22}.Select(i=>Length(i,i+1).ToString("F3",CultureInfo.InvariantCulture)));
        }
        static void Surface(List<string> rows,string key,int side,string model,Transform[] joints,Pose[] input,SkinnedMeshRenderer skin)
        {
            var baked=new Mesh();skin.BakeMesh(baked);var vertices=baked.vertices;
            var weights=skin.sharedMesh.GetAllBoneWeights();var counts=skin.sharedMesh.GetBonesPerVertex();
            var bones=skin.bones;
            foreach(int tip in new[]{5,10,15,20,25})
            {
                int end=Array.IndexOf(bones,joints[tip]), distal=Array.IndexOf(bones,joints[tip-1]);
                var axis=(input[tip].position-input[tip-1].position).normalized;
                int k=0, selected=0;float max=-1000,nearest=1000;
                for(int i=0;i<vertices.Length;i++)
                {
                    float weight=0;
                    for(int j=0;j<counts[i];j++){var w=weights[k++];if(w.boneIndex==end||w.boneIndex==distal)weight+=w.weight;}
                    if(weight<.5f)continue;
                    Vector3 delta=(skin.transform.TransformPoint(vertices[i])-input[tip].position)*1000f;
                    nearest=Mathf.Min(nearest,delta.magnitude);max=Mathf.Max(max,Vector3.Dot(delta,axis));selected++;
                }
                if(selected<1)throw new Exception("No distal weighted vertices "+tip);
                rows.Add($"{key},{side},{model},{tip},{selected},{nearest:F4},{max:F4},{Vector3.Distance(input[tip].position,joints[tip].position)*1000:F4}");
            }
            Object.DestroyImmediate(baked);
        }
        static void Fit(Camera cam,Vector3[] points,Vector3 view,Vector3 up)
        {
            var center = new Bounds(points[0], Vector3.zero); foreach(var v in points) center.Encapsulate(v);
            cam.transform.rotation=Quaternion.LookRotation(-view,up);
            var local=points.Select(v=>Quaternion.Inverse(cam.transform.rotation)*(v-center.center)).ToArray();
            var bounds=new Bounds(local[0],Vector3.zero);foreach(var v in local)bounds.Encapsulate(v);
            Vector3 target=center.center+cam.transform.rotation*bounds.center;
            cam.transform.position=target+view*.8f;
            cam.orthographicSize=Mathf.Max(.07f,Mathf.Max(bounds.extents.y,bounds.extents.x/1.6f)*1.28f+.012f);
        }
        static void Photograph(Camera cam,string path)
        {
            var rt=RenderTexture.GetTemporary(800,500,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
            var previous=RenderTexture.active;
            cam.targetTexture=rt;cam.aspect=1.6f;cam.Render();RenderTexture.active=rt;
            var tex=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);
            tex.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0);tex.Apply();File.WriteAllBytes(path,tex.EncodeToPNG());
            Object.DestroyImmediate(tex);RenderTexture.active=previous;cam.targetTexture=null;RenderTexture.ReleaseTemporary(rt);
        }
    }
}