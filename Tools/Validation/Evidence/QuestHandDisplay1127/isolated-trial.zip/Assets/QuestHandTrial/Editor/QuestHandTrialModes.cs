using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.XR.Management;
using UnityEngine;
using UnityEngine.XR.Management;

namespace QuestHandTrial
{
    public static class QuestHandTrialModes
    {
        const string Root="D:/Temp/Naruto-ChapterEntry-QA-1126/Project/Assets";
        const string Folder="Assets/QuestHandTrial/";
        [MenuItem("Tools/Quest Hand Trial/Open live chapter (PC OpenXR)")]
        static void Live() => Open(true);
        [MenuItem("Tools/Quest Hand Trial/Open offline recorded frames")]
        static void Offline() => Open(false);
        static void Open(bool live)
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Stop Play in the isolated editor first.");
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            SetMode(live,true);
            EditorSceneManager.OpenScene(Folder+(live?"Chapter02_QuestHandDisplayAB.unity":"QuestHandRecordedFrames.unity"));
        }
        public static void Verify()
        {
            var general=XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(BuildTargetGroup.Standalone);
            if(general.InitManagerOnStart||general.Manager.activeLoaders.Count!=0)
                throw new InvalidOperationException("Expected the isolated offline desktop configuration.");
            SetMode(true,false);SetMode(false,false);
            File.WriteAllText("D:/Temp/QuestHandReview1127/trial/Review/modes.txt",
                "PASS isolated Standalone OpenXR loader add/remove and init flag round trip in memory. No headset requested.");
        }
        static void SetMode(bool live,bool save)
        {
            if (!string.Equals(Path.GetFullPath(Application.dataPath).Replace('\\','/'), Root, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("This command is limited to the designated isolated project.");
            var general=XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(BuildTargetGroup.Standalone);
            var manager=general.Manager;
            var loader=AssetDatabase.LoadAssetAtPath<XRLoader>("Assets/XR/Loaders/OpenXRLoader.asset");
            if(!loader || manager.activeLoaders.Any(l=>l!=loader))throw new InvalidOperationException("Unexpected PC XR loader configuration.");
            bool present=manager.activeLoaders.Contains(loader);
            if(live&&!present&&!manager.TryAddLoader(loader)) throw new InvalidOperationException("OpenXR loader addition failed.");
            if(!live&&present&&!manager.TryRemoveLoader(loader)) throw new InvalidOperationException("OpenXR loader removal failed.");
            general.InitManagerOnStart=live;
            if(manager.activeLoaders.Contains(loader)!=live || general.InitManagerOnStart!=live)throw new InvalidOperationException("Loader verification failed.");
            if(save){EditorUtility.SetDirty(manager);EditorUtility.SetDirty(general);AssetDatabase.SaveAssetIfDirty(general);}
        }
    }
}