using System;
using System.IO;
using System.Linq;
using NarutoVR.SealCombat.Items;
using NarutoVR.SealCombat.Rpg;
using NarutoVR.SealLab;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Object=UnityEngine.Object;

namespace QuestHandTrial
{
    public static class QuestChapterTrialSmoke
    {
        public static void Run()
        {
            var scene=EditorSceneManager.OpenScene("Assets/QuestHandTrial/Chapter02_QuestHandDisplayAB.unity");
            var player=Object.FindFirstObjectByType<LinearRpgController>();
            player.saveFileName="quest-hand-display-trial-ch02.json";
            if (!EditorSceneManager.SaveScene(scene)) throw new IOException("QA chapter save slot");
            SessionState.SetBool("QuestChapterABSmoke",true);SessionState.SetInt("QuestChapterABSmokePhase",0);
            EditorApplication.EnterPlaymode();
        }
        [InitializeOnLoadMethod] static void Resume() => EditorApplication.update+=Tick;
        static void Tick()
        {
            if (!SessionState.GetBool("QuestChapterABSmoke",false) || !EditorApplication.isPlaying || Time.frameCount<20)return;
            const string output="D:/Temp/QuestHandReview1127/trial/Review/";
            try
            {
                var selector=Object.FindFirstObjectByType<ChapterHandDisplaySelector>();
                var menus=Object.FindFirstObjectByType<WristMenuController>();
                var pen=Object.FindObjectsByType<GameItemBase>(FindObjectsInactive.Include,FindObjectsSortMode.None).Single(p=>p.name=="PhysicalMoGuiPen");
                if(!selector||selector.hands.Length!=2 || !menus||!menus.wornDevice||!pen.grip)throw new Exception("Missing chapter player, pen, wrist or selector");
                var source=Object.FindFirstObjectByType<SealXRHandsSource>();
                int phase=SessionState.GetInt("QuestChapterABSmokePhase",0);
                if(phase>0 && Time.frameCount<SessionState.GetInt("QuestChapterWait",0))return;
                foreach(var h in selector.hands)
                {
                    if (!h.trackingFrames || h.trackingFrames.xrHandsSource!=source || h.existing.Hand!=(h.left?source.leftHand:source.rightHand))
                        throw new Exception("Live chapter provider reference changed");
                    if (h.unityModel.GetComponentInChildren<SkinnedMeshRenderer>().enabled)throw new Exception("Untracked visual active");
                    if (phase>0 && !h.existing.ForceOffVisibility)throw new Exception("Native visual not suppressed in B");
                }
                if(phase==0)
                {
                    selector.display=OfficialHandDisplayTrial.DisplayMode.UnityFixedLength;
                    SessionState.SetInt("QuestChapterABSmokePhase",1);SessionState.SetInt("QuestChapterWait",Time.frameCount+5);return;
                }
                File.WriteAllText(output+"chapter-play.txt","PASS isolated Chapter02 live candidate initialized, distinct trial save slot, real chapter pen grip and wrist object, two SDK hand sources preserved and two SealLab validity sources bound; offline tracking loss in B hides both visuals. No head-mounted session.");
                End(0);
            }
            catch(Exception ex){File.WriteAllText(output+"chapter-play-error.txt",ex.ToString());End(1);}
        }
        static void End(int status){SessionState.SetBool("QuestChapterABSmoke",false);EditorApplication.ExitPlaymode();EditorApplication.Exit(status);}
    }
}