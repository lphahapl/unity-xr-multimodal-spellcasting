using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Object=UnityEngine.Object;

namespace QuestHandTrial
{
    public static class QuestHandContour
    {
        const string Out="D:/Temp/QuestHandReview1127/trial/Review/contour/";
        public static void Capture(Camera cam,OfficialHandDisplayTrial hand,string mode)
        {
            Directory.CreateDirectory(Out);
            var skin=mode=="A" ? hand.existing.GetComponentInChildren<SkinnedMeshRenderer>(true) : hand.unityModel.GetComponentInChildren<SkinnedMeshRenderer>(true);
            var originalPos=cam.transform.position;
            float size=cam.orthographicSize, aspect=cam.aspect;
            var cropCenter=new Vector2(51.99f+.7996f*355*.5f,135.2f+.7996f*323*.5f);
            cam.transform.position += (cam.transform.right*(cropCenter.x-400)+cam.transform.up*(250-cropCenter.y))*(2*size/500);
            cam.orthographicSize=size*.7996f*323/500;cam.aspect=355f/323f;
            var rt=RenderTexture.GetTemporary(1065,969,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
            var previous=RenderTexture.active; cam.targetTexture=rt;cam.Render();RenderTexture.active=rt;
            var tex=new Texture2D(rt.width,rt.height,TextureFormat.RGB24,false);
            tex.ReadPixels(new Rect(0,0,rt.width,rt.height),0,0); tex.Apply();File.WriteAllBytes(Out+mode+"-registered-3x.png",tex.EncodeToPNG());
            Object.DestroyImmediate(tex);cam.targetTexture=null;RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);
            cam.transform.position=originalPos;cam.orthographicSize=size;cam.aspect=aspect;
            var baked=new Mesh();skin.BakeMesh(baked);var screen=baked.vertices.Select(v=>cam.WorldToViewportPoint(skin.transform.TransformPoint(v))).Select(p=>new Vector2(p.x*800,(1-p.y)*500)).ToArray();
            var tris=baked.triangles;var ws=skin.sharedMesh.GetAllBoneWeights();var counts=skin.sharedMesh.GetBonesPerVertex();
            var per=new Dictionary<int,float>[screen.Length];
            for(int v=0,k=0;v<screen.Length;v++)
            {
                per[v]=new Dictionary<int,float>();
                for(int j=0;j<counts[v];j++){var w=ws[k++];per[v][w.boneIndex]=w.weight;}
            }
            var lines=new List<string>{"registeredY,contourX,triangle,jointsAtRightmostEdge"};
            for(int y=100;y<=390;y++)
            {
                float best=-1,t=0;int vA=-1,vB=-1,tri=-1;
                for(int i=0;i<tris.Length;i+=3)
                for(int j=0;j<3;j++)
                {
                    int a=tris[i+j],b=tris[i+(j+1)%3];
                    if ((screen[a].y<y)==(screen[b].y<y) || Mathf.Abs(screen[b].y-screen[a].y)<.0001f) continue;
                    float f=(y-screen[a].y)/(screen[b].y-screen[a].y);
                    float x=Mathf.Lerp(screen[a].x,screen[b].x,f);
                    if(x<best)continue;
                    vA=a;vB=b;t=f;best=x;tri=i/3;
                }
                if(vA<0)continue;
                var keys=per[vA].Keys.Union(per[vB].Keys);
                var amounts=keys.Select(k=>(joint:skin.bones[k].name,amount:(per[vA].TryGetValue(k,out var a)?a:0)*(1-t)+(per[vB].TryGetValue(k,out var b)?b:0)*t)).Where(z=>z.amount>.005).OrderByDescending(z=>z.amount);
                lines.Add($"{y},{best:F4},{tri},"+string.Join("|",amounts.Select(x=>$"{x.joint}:{x.amount:F3}")));
            }
            File.WriteAllLines(Out+mode+"-edge-skin.csv",lines);Object.DestroyImmediate(baked);
        }
    }
}