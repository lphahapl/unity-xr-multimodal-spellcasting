using System;
using System.Collections.Generic;
using NarutoVR.SealLab;
using Oculus.Interaction;
using Oculus.Interaction.Input;
using UnityEngine;

namespace QuestHandTrial
{
    // Only the two renderers and the independent visual skeleton are mutated.
    [DefaultExecutionOrder(10000)]
    public sealed class OfficialHandDisplayTrial : MonoBehaviour
    {
        public enum DisplayMode { CurrentMeta, UnityFixedLength }
        public DisplayMode display;
        public HandVisual existing;
        public NarutoVR.SealLab.SealLab trackingFrames;
        public Transform unityModel;
        public bool left;
        public Material neutralPreview;
        public Transform[] Bones { get; private set; }
        public float BindPalmWidth { get; private set; }
        public static readonly string[] JointNames = {
            "Palm","Wrist","ThumbMetacarpal","ThumbProximal","ThumbDistal","ThumbTip",
            "IndexMetacarpal","IndexProximal","IndexIntermediate","IndexDistal","IndexTip",
            "MiddleMetacarpal","MiddleProximal","MiddleIntermediate","MiddleDistal","MiddleTip",
            "RingMetacarpal","RingProximal","RingIntermediate","RingDistal","RingTip",
            "LittleMetacarpal","LittleProximal","LittleIntermediate","LittleDistal","LittleTip" };
        [NonSerialized] public bool adaptTips = true;
        readonly Vector3[] bindScale = new Vector3[26];
        readonly Pose[] poses = new Pose[26];
        readonly Quaternion[] correction = new Quaternion[26];
        readonly Vector3[] distalAxis = new Vector3[26];
        readonly Vector3[] restPositions = new Vector3[26];
        public IReadOnlyList<Vector3> RestPositions => restPositions;
        SkinnedMeshRenderer skin;
        float metaWidth;
        Vector3 originalScale;
        IHand subscribed;
        static bool HasChild(int i) => i >= 2 && i != 5 && i != 10 && i != 15 && i != 20 && i != 25;

        public void Configure()
        {
            if (Bones != null) return;
            var joints = new Transform[26];
            var transforms = unityModel.GetComponentsInChildren<Transform>(true);
            var skeleton = left ? HandSkeleton.DefaultLeftSkeleton : HandSkeleton.DefaultRightSkeleton;
            var native = new Pose[26];
            native[1] = Pose.identity;
            var names = new Dictionary<string, Transform>();
            foreach (var t in transforms) names[t.name] = t;
            var prefix = left ? "L_" : "R_";
            for (var i = 0; i != 26; ++i)
                if (!names.TryGetValue(prefix + JointNames[i], out joints[i]))
                    throw new InvalidOperationException("Missing Unity XR joint " + prefix + JointNames[i]);
            var wrist = joints[1]; var inverse = Quaternion.Inverse(wrist.rotation);
            for (int i = 0; i != 26; ++i)
            {
                if (i != 1)
                {
                    var j = skeleton.joints[i];
                    native[i] = j.pose.GetTransformedBy(native[j.parent]);
                }
                bindScale[i] = joints[i].localScale;
                correction[i] = Quaternion.Inverse(native[i].rotation) * inverse * joints[i].rotation;
                restPositions[i] = inverse * (joints[i].position - wrist.position);
                if (HasChild(i)) distalAxis[i] = joints[i].InverseTransformDirection((joints[i + 1].position - joints[i].position).normalized);
            }
            BindPalmWidth = Vector3.Distance(joints[7].position, joints[22].position);
            metaWidth = Vector3.Distance(native[7].position, native[22].position);
            if (BindPalmWidth < .02f || BindPalmWidth > .14f) throw new InvalidOperationException("Unexpected Unity bind width " + BindPalmWidth);
            originalScale = unityModel.localScale;
            skin = unityModel.GetComponentInChildren<SkinnedMeshRenderer>(true);
            if (neutralPreview) skin.sharedMaterial = neutralPreview;
            Bones = joints;
        }

        void LateUpdate()
        {
            if (!existing || !unityModel || existing.Hand == null) return;
            if (subscribed != existing.Hand)
            {
                if (subscribed != null) subscribed.WhenHandUpdated -= Refresh;
                subscribed = existing.Hand;
                subscribed.WhenHandUpdated += Refresh;
            }
            Refresh();
        }

        void OnDisable()
        {
            if (subscribed != null) subscribed.WhenHandUpdated -= Refresh;
            subscribed = null;
            if (existing) existing.ForceOffVisibility = false;
            if (skin) skin.enabled = false;
        }

        public void Refresh()
        {
            Configure();
            bool useAlt = display == DisplayMode.UnityFixedLength;
            if (existing.ForceOffVisibility != useAlt) existing.ForceOffVisibility = useAlt;
            if (!useAlt || existing.Hand == null || !existing.Hand.IsTrackedDataValid)
            { skin.enabled = false; return; }
            if (existing.Hand is ReplayHand replay)
            {
                if (!IsFreshAndComplete(replay.sample,replay.sample.observedAt,.12f)) { skin.enabled=false; return; }
                Apply(replay.World,replay.Scale);
            }
            else
            {
                var frame = trackingFrames && trackingFrames.isActiveAndEnabled ? trackingFrames.Frame : null;
                var sample = left ? frame?.left : frame?.right;
                if (!trackingFrames || !IsFreshAndComplete(sample,Time.realtimeSinceStartupAsDouble,trackingFrames.staleAfterSeconds))
                { skin.enabled = false; return; }
                // Both the validity flags and the pose come from this exact Dynamic observation.
                var origin=trackingFrames.recordingOrigin;
                if (!origin) { skin.enabled=false; return; }
                for(int i=0;i<poses.Length;i++)
                    poses[i]=new Pose(origin.TransformPoint(sample.joints[i].position),origin.rotation*sample.joints[i].rotation);
                Apply(poses,sample.scale);
            }
            skin.enabled = true;
        }

        public static bool IsFreshAndComplete(HandSnapshot s,double now,float maxAge)
        {
            if (s==null || !s.connected || !s.tracked || !s.fresh || s.version<=0 || !double.IsFinite(s.observedAt)
                || !float.IsFinite(s.scale) || s.scale<=0 || now<s.observedAt || now-s.observedAt>maxAge
                || s.jointValid?.Length!=26 || s.joints?.Length!=26) return false;
            for(int i=0;i<26;i++) if(!s.jointValid[i] || !NarutoVR.SealLab.SealLab.FinitePose(s.joints[i]))return false;
            return true;
        }

        public void Apply(Pose[] input, float scale)
        {
            Configure();
            var wrist = Bones[1];
            // Preserve imported segment lengths. Match one hand scale across the whole model.
            unityModel.localScale = originalScale * (metaWidth / BindPalmWidth * scale);
            wrist.SetPositionAndRotation(input[1].position, input[1].rotation * correction[1]);
            for (int i = 0; i != 26; ++i)
            {
                if (i == 1) continue;
                // Root each metacarpal at its tracked point. The two official models place the palm and finger bases differently.
                if (i == 0 || i == 2 || i == 6 || i == 11 || i == 16 || i == 21 || i == 3 || i == 7 || i == 12 || i == 17 || i == 22) Bones[i].position = input[i].position;
                Quaternion rotation = input[i].rotation * correction[i];
                if (HasChild(i))
                {
                    Vector3 direction = input[i + 1].position - input[i].position;
                    if (direction.sqrMagnitude > 1e-8f)
                        rotation = Quaternion.FromToRotation(rotation * distalAxis[i], direction) * rotation;
                }
                Bones[i].rotation = rotation;
                if (i == 4 || i == 9 || i == 14 || i == 19 || i == 24)
                {
                    // Unity's imported tip landmark is farther out than some provider landmarks.
                    // Match only its longitudinal extent. Keep the transverse skin dimensions.
                    Bones[i].localScale = bindScale[i];
                    Vector3 target = input[i + 1].position - input[i].position;
                    Vector3 current = Bones[i + 1].position - Bones[i].position;
                    if (adaptTips && current.sqrMagnitude > 1e-8f && Mathf.Abs(distalAxis[i].z) > .99f)
                    {
                        float ratio = target.magnitude / current.magnitude;
                        if (ratio >= .5f && ratio <= 1.5f)
                        {
                            var sc = bindScale[i]; sc.z *= ratio; Bones[i].localScale = sc;
                            current = Bones[i + 1].position - Bones[i].position;
                            Bones[i].rotation = Quaternion.FromToRotation(current,target) * Bones[i].rotation;
                        }
                    }
                }
            }
        }
    }
}