using System;
using NarutoVR.SealLab;
using Oculus.Interaction.Input;
using UnityEngine;

namespace QuestHandTrial
{
    public sealed class ReplayHand : MonoBehaviour, IHand
    {
        public bool isLeft;
        public HandSnapshot sample;
        readonly Pose[] local = new Pose[26];
        readonly Pose[] relative = new Pose[26];
        ReadOnlyHandJointPoses localView, relativeView;
        public Pose[] World { get; } = new Pose[26];
        public Handedness Handedness => isLeft ? Handedness.Left : Handedness.Right;
        public bool IsConnected => sample?.connected == true;
        public bool IsHighConfidence => sample?.highConfidence == true;
        public bool IsDominantHand => !isLeft;
        public float Scale => sample?.scale ?? 1f;
        public bool IsTrackedDataValid => IsConnected && sample.tracked && sample.fresh && sample.wristPosesValid;
        public int CurrentDataVersion => sample.version;
        public event Action WhenHandUpdated;
        public void Load(HandSnapshot source, Pose stageWrist)
        {
            sample = source;
            for (int i = 0; i != 26; ++i)
            {
                if (!source.jointValid[i]) throw new ArgumentException("Incomplete recorded joint " + i);
                relative[i] = source.wristPoses[i];
                int parent = (int)HandJointUtils.JointParentList[i];
                local[i] = parent < 0 ? relative[i] : Delta(source.wristPoses[parent], relative[i]);
                // Compute target independently from recorded tracking-origin joint transforms.
                Pose captured = Delta(source.joints[1], source.joints[i]);
                World[i] = captured.GetTransformedBy(stageWrist);
            }
            root = stageWrist;
            localView ??= new ReadOnlyHandJointPoses(local);
            relativeView ??= new ReadOnlyHandJointPoses(relative);
            WhenHandUpdated?.Invoke();
        }
        Pose root;
        public static Pose Delta(Pose from, Pose to)
        {
            var inverse = Quaternion.Inverse(from.rotation);
            return new Pose(inverse * (to.position - from.position), inverse * to.rotation);
        }
        public bool GetRootPose(out Pose pose) { pose = root; return IsTrackedDataValid; }
        public bool GetJointPose(HandJointId i, out Pose pose) { pose = World[(int)i]; return IsTrackedDataValid; }
        public bool GetJointPoseLocal(HandJointId i, out Pose pose) { pose = local[(int)i]; return IsTrackedDataValid; }
        public bool GetJointPoseFromWrist(HandJointId i, out Pose pose) { pose = relative[(int)i]; return IsTrackedDataValid; }
        public bool GetJointPosesLocal(out ReadOnlyHandJointPoses poses) { poses = localView; return IsTrackedDataValid; }
        public bool GetJointPosesFromWrist(out ReadOnlyHandJointPoses poses) { poses = relativeView; return IsTrackedDataValid; }
        public bool GetPalmPoseLocal(out Pose pose) => GetJointPoseLocal(HandJointId.HandPalm, out pose);
        public bool GetFingerIsHighConfidence(HandFinger finger) => sample.fingerConfidence[(int)finger];
        // SealRecording did not record provider pinch, aim or pointer channels.
        public bool GetFingerIsPinching(HandFinger finger) => false;
        public bool GetIndexFingerIsPinching() => false;
        public bool IsPointerPoseValid => false;
        public bool GetPointerPose(out Pose pose) { pose = Pose.identity; return false; }
        public float GetFingerPinchStrength(HandFinger finger) => 0f;
    }
}