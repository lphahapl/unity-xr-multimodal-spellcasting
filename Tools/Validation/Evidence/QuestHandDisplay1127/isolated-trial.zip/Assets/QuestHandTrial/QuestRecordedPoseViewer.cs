using System;
using System.Linq;
using NarutoVR.SealLab;
using Oculus.Interaction;
using UnityEngine;

namespace QuestHandTrial
{
    [DefaultExecutionOrder(-210)]
    public sealed class QuestRecordedPoseViewer : MonoBehaviour
    {
        [Serializable] public sealed class Entry { public string key; public SealFrame frame; }
        public TextAsset recordedFrames;
        public GameObject[] metaVisuals, unityModels;
        public Material neutral;
        public Camera viewer;
        public OfficialHandDisplayTrial.DisplayMode display;
        public int frameIndex = 1;
        public bool preserveBilateralPose;
        readonly OfficialHandDisplayTrial[] hands = new OfficialHandDisplayTrial[2];
        readonly ReplayHand[] inputs = new ReplayHand[2];
        Entry[] entries;
        int previous = -1;
        bool previousPair;
        void Awake()
        {
            entries=recordedFrames.text.Split(new[]{'\n','\r'},StringSplitOptions.RemoveEmptyEntries)
                .Select(line=>JsonUtility.FromJson<Entry>(line)).ToArray();
            for(int s=0;s<2;s++)
            {
                var group = new GameObject(s==0?"Replay Left":"Replay Right");
                group.transform.SetParent(transform,false); group.SetActive(false);
                var meta = Instantiate(metaVisuals[s],group.transform).GetComponent<HandVisual>();
                var input=group.AddComponent<ReplayHand>(); input.isLeft = s==0; meta.InjectHand(input);
                var b=group.AddComponent<OfficialHandDisplayTrial>();
                b.existing=meta; b.left=s==0; b.unityModel=Instantiate(unityModels[s],group.transform).transform;
                b.neutralPreview=neutral; b.Configure(); inputs[s]=input; hands[s]=b;
                foreach(var r in group.GetComponentsInChildren<SkinnedMeshRenderer>(true)) r.sharedMaterial=neutral;
                group.SetActive(true);
            }
            Redraw();
        }
        void Update()
        {
            frameIndex = Mathf.Clamp(frameIndex,0,entries.Length-1);
            if(frameIndex!=previous || previousPair!=preserveBilateralPose) Redraw();
            foreach (var h in hands) h.display=display;
        }
        void Redraw()
        {
            var frame = entries[frameIndex].frame;
            for (int s=0;s<2;s++)
            {
                HandSnapshot snap=s==0?frame.left:frame.right;
                inputs[s].Load(snap,preserveBilateralPose?snap.joints[1]:new Pose(new Vector3((s==0?-1:1)*.102f,0,0),Quaternion.identity));
                hands[s].display=display;hands[s].existing.UpdateSkeleton();hands[s].Refresh();
            }
            Vector3 view=new Vector3(0,1,-.36f).normalized; Vector3 up=Vector3.forward;
            if(preserveBilateralPose)
            {
                view=-(frame.left.joints[1].position+frame.right.joints[1].position)*.5f;
                view.y=.14f; if(view.sqrMagnitude<.04f)view=new Vector3(0,.4f,-.5f);
                view.Normalize();up=Vector3.up;
            }
            var points=inputs.SelectMany(i=>i.World).Select(p=>p.position).ToArray();
            viewer.transform.rotation=Quaternion.LookRotation(-view,up);
            var inverse=Quaternion.Inverse(viewer.transform.rotation);
            var bounds=new Bounds(inverse*points[0], Vector3.zero);
            foreach(var v in points)bounds.Encapsulate(inverse*v);
            viewer.transform.position=viewer.transform.rotation*bounds.center+view*.8f;
            viewer.orthographicSize=Mathf.Max(.09f,Mathf.Max(bounds.extents.y,bounds.extents.x/viewer.aspect)*1.4f+.015f);
            previous=frameIndex;previousPair=preserveBilateralPose;
        }
        void OnGUI()
        {
            GUILayout.BeginArea(new Rect(12,12,650,86),"","box");
            GUILayout.Label(entries[frameIndex].key + "   " + (frameIndex+1) + "/" + entries.Length);
            GUILayout.BeginHorizontal();
            if(GUILayout.Button("Previous")) frameIndex=(frameIndex+entries.Length-1)%entries.Length;
            if(GUILayout.Button("Next")) frameIndex=(frameIndex+1)%entries.Length;
            if(GUILayout.Toggle(display==OfficialHandDisplayTrial.DisplayMode.CurrentMeta,"A  Meta SDK","Button"))
                display=OfficialHandDisplayTrial.DisplayMode.CurrentMeta;
            if(GUILayout.Toggle(display==OfficialHandDisplayTrial.DisplayMode.UnityFixedLength,"B  Unity XR Hands","Button"))
                display=OfficialHandDisplayTrial.DisplayMode.UnityFixedLength;
            preserveBilateralPose=GUILayout.Toggle(preserveBilateralPose,"Recorded pair");
            GUILayout.EndHorizontal();GUILayout.EndArea();
        }
    }
}