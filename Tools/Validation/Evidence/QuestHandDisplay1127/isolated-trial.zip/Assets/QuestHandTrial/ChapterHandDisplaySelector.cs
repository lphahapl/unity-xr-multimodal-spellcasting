using UnityEngine;
namespace QuestHandTrial
{
    [DefaultExecutionOrder(9000)]
    public sealed class ChapterHandDisplaySelector : MonoBehaviour
    {
        [InspectorName("显示方式（Play 中可切换）")]
        public OfficialHandDisplayTrial.DisplayMode display = OfficialHandDisplayTrial.DisplayMode.CurrentMeta;
        public OfficialHandDisplayTrial[] hands;
        void Awake()
        {
            foreach (var hand in hands)
            {
                hand.Configure();
                hand.unityModel.GetComponentInChildren<SkinnedMeshRenderer>(true).enabled = false;
            }
        }
        void LateUpdate()
        {
            foreach (var hand in hands) hand.display = display;
        }
    }
}