using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using NarutoVR.SealLab;
using Oculus.Interaction;
using Oculus.Interaction.Input.UnityXR;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Hands;
using UnityEngine.XR.OpenXR;
using Lab = NarutoVR.SealLab.SealLab;

// Editor-only diagnostic for the isolated chapter copies. All providers are read-only.
public static class QuestHandLayerRecorder
{
    const string Qualities = "Tools/Quest Hands/Official Meta mesh/";
    [MenuItem(Qualities + "Use four weights (Play only)")]
    static void ShowFour() => SetSkinQuality(SkinQuality.Bone4);
    [MenuItem(Qualities + "Use two weights (Play only)")]
    static void ShowTwo() => SetSkinQuality(SkinQuality.Bone2);
    [MenuItem(Qualities + "Restore project default (Play only)")]
    static void ShowDefault() => SetSkinQuality(SkinQuality.Auto);
    [MenuItem(Qualities + "Use four weights (Play only)", true)]
    [MenuItem(Qualities + "Use two weights (Play only)", true)]
    [MenuItem(Qualities + "Restore project default (Play only)", true)]
    static bool CanSwitchQuality() => EditorApplication.isPlaying;

    static void SetSkinQuality(SkinQuality quality)
    {
        var meshes = new List<SkinnedMeshRenderer>();
        foreach (var hand in UnityEngine.Object.FindObjectsByType<Oculus.Interaction.HandVisual>(FindObjectsSortMode.None))
        {
            var prop = new SerializedObject(hand).FindProperty("_openXRSkinnedMeshRenderer");
            if (prop?.objectReferenceValue is not SkinnedMeshRenderer skin) continue;
            string path = AssetDatabase.GetAssetPath(skin.sharedMesh);
            if (path == "Packages/com.meta.xr.sdk.interaction/Runtime/Meshes/OpenXRLeftHand.fbx" ||
                path == "Packages/com.meta.xr.sdk.interaction/Runtime/Meshes/OpenXRRightHand.fbx") meshes.Add(skin);
        }
        if (meshes.Count != 2) { Debug.LogWarning("Open the isolated chapter with one enabled pair of Meta hand visuals."); return; }
        foreach (var mesh in meshes) mesh.quality = quality;
        Debug.Log($"Official Meta hand renderers now use {quality}. Effective project setting: {QualitySettings.skinWeights}");
    }

    [Serializable] class Space
    {
        public string name;
        public Matrix4x4 localToWorld;
        public static Space Read(Transform t) => t == null ? null : new Space { name = t.name, localToWorld = t.localToWorldMatrix };
    }

    [Serializable] class RawHand
    {
        public bool tracked, jointsUpdated;
        public Pose root;
        // Project Meta indices (0 = palm, 1 = wrist), in XR tracking space in metres.
        public Pose[] joints = new Pose[26];
        public bool[] valid = new bool[26];
        public static RawHand Read(XRHand hand, bool updated)
        {
            var value = new RawHand { tracked = hand.isTracked, jointsUpdated = updated, root = hand.rootPose };
            if (!hand.isTracked || !updated) return value;
            for (int i = XRHandJointID.BeginMarker.ToIndex(); i < XRHandJointID.EndMarker.ToIndex(); i++)
            {
                var id = XRHandJointIDUtility.FromIndex(i);
                int slot = SealXRHandsSource.MetaJointIndex(id);
                var joint = hand.GetJoint(id);
                if ((joint.trackingState & XRHandJointTrackingState.Pose) == 0 ||
                    !joint.TryGetPose(out var pose) || !Lab.FinitePose(pose)) continue;
                value.valid[slot] = true;
                value.joints[slot] = pose;
            }
            return value;
        }
    }

    [Serializable] class Raw
    {
        public double at;
        public int flags;
        public RawHand left, right;
    }

    [Serializable] class Sample
    {
        public int frame;
        public bool hasBeforeRender, hasGameplay;
        public Raw dynamic, beforeRender;
        public SealFrame gameplay;
        public Space recordingOrigin, leftTrackingSpace, rightTrackingSpace;
        public bool leftMatchesDynamic, rightMatchesDynamic;
        public bool leftSharedOrigin, rightSharedOrigin;
        public JointDifference leftDifference, rightDifference;
    }

    [Serializable] class JointDifference
    {
        public int validJoints;
        public float worstPositionMm, worstAngleDegrees;
        public int positionJoint = -1, angleJoint = -1;
        public static JointDifference Read(RawHand raw, HandSnapshot sdk)
        {
            var result = new JointDifference();
            for (int i = 0; i < 26; i++)
            {
                if (!raw.valid[i] || !sdk.jointValid[i]) continue;
                result.validJoints++;
                float mm = Vector3.Distance(raw.joints[i].position, sdk.joints[i].position) * 1000;
                float angle = Quaternion.Angle(raw.joints[i].rotation, sdk.joints[i].rotation);
                if (mm > result.worstPositionMm) { result.worstPositionMm = mm; result.positionJoint = i; }
                if (angle > result.worstAngleDegrees) { result.worstAngleDegrees = angle; result.angleJoint = i; }
            }
            return result;
        }
    }

    [Serializable] class Header
    {
        public string kind = "header", schema = "quest-hand-layers-1";
        public string utc, unity, runtime, head, manufacturer, scene;
        public int samples;
    }

    static XRHandSubsystem source;
    static Lab lab;
    static Transform leftSpace, rightSpace;
    static Header header;
    static readonly List<Sample> samples = new();
    static Sample current;
    static double deadline, nextSample;

    [MenuItem("Tools/Quest Hands/Record 10 seconds of raw and gameplay joints", true)]
    static bool CanStart() => EditorApplication.isPlaying && !EditorApplication.isPaused && source == null;

    [MenuItem("Tools/Quest Hands/Record 10 seconds of raw and gameplay joints")]
    public static void Start()
    {
        if (!CanStart()) return;
        lab = UnityEngine.Object.FindFirstObjectByType<Lab>();
        var available = new List<XRHandSubsystem>();
        SubsystemManager.GetSubsystems(available);
        var active = available.Find(s => s.running);
        if (!lab || !lab.isActiveAndEnabled || !lab.xrHandsSource || !lab.xrHandsSource.IsConfigured || active == null)
        {
            Debug.LogWarning("Quest hand capture needs a playing chapter with its XR Hands provider running.");
            return;
        }
        leftSpace = GetTrackingSpace(lab.xrHandsSource.leftHand);
        rightSpace = GetTrackingSpace(lab.xrHandsSource.rightHand);
        var head = InputDevices.GetDeviceAtXRNode(XRNode.Head);
        header = new Header { utc = DateTime.UtcNow.ToString("O"), unity = Application.unityVersion,
            runtime = OpenXRRuntime.name, head = head.name, manufacturer = head.manufacturer, scene = lab.gameObject.scene.path };
        source = active;
        nextSample = 0;
        deadline = EditorApplication.timeSinceStartup + 10;
        source.updatedHands += OnRaw;
        Application.onBeforeRender += ReadGameplay;
        EditorApplication.update += Tick;
        EditorApplication.playModeStateChanged += PlayState;
        AssemblyReloadEvents.beforeAssemblyReload += Stop;
        Debug.Log("Quest hand capture started for 10 seconds.");
    }

    static Transform GetTrackingSpace(Component hand)
    {
        var adapter = hand.GetComponent<FromUnityXRHandDataSource>();
        var field = new SerializedObject(adapter).FindProperty("_trackingToWorldTransformer");
        var transformer = field?.objectReferenceValue as TransformTrackingToWorldTransformer;
        return transformer ? transformer.Transform : null;
    }

    static void OnRaw(XRHandSubsystem subsystem, XRHandSubsystem.UpdateSuccessFlags flags, XRHandSubsystem.UpdateType phase)
    {
        double now = Time.realtimeSinceStartupAsDouble;
        if (phase == XRHandSubsystem.UpdateType.Dynamic)
        {
            if (now < nextSample) return;
            nextSample = now + 1.0 / 12;
            current = new Sample { frame = Time.frameCount, recordingOrigin = Space.Read(lab ? lab.recordingOrigin : null),
                leftTrackingSpace = Space.Read(leftSpace), rightTrackingSpace = Space.Read(rightSpace) };
            samples.Add(current);
        }
        if (current == null || current.frame != Time.frameCount) return;
        var raw = new Raw { at = now, flags = (int)flags,
            left = RawHand.Read(subsystem.leftHand, (flags & XRHandSubsystem.UpdateSuccessFlags.LeftHandJoints) != 0),
            right = RawHand.Read(subsystem.rightHand, (flags & XRHandSubsystem.UpdateSuccessFlags.RightHandJoints) != 0) };
        if (phase == XRHandSubsystem.UpdateType.Dynamic) current.dynamic = raw;
        else if (phase == XRHandSubsystem.UpdateType.BeforeRender)
        {
            current.beforeRender = raw;
            current.hasBeforeRender = true;
        }
    }

    // SealLab creates a new snapshot per acquisition. Keep the frame and source timestamps
    // even when the gameplay cadence skipped this render frame.
    [BeforeRenderOrder(10000)]
    static void ReadGameplay()
    {
        if (current == null || current.frame != Time.frameCount || !lab || lab.Frame == null) return;
        current.gameplay = lab.Frame;
        current.hasGameplay = true;
        current.leftMatchesDynamic = CanCompare(current.dynamic?.left, lab.Frame.left, current.dynamic?.at ?? -1);
        current.rightMatchesDynamic = CanCompare(current.dynamic?.right, lab.Frame.right, current.dynamic?.at ?? -1);
        current.leftSharedOrigin = leftSpace && lab.recordingOrigin == leftSpace;
        current.rightSharedOrigin = rightSpace && lab.recordingOrigin == rightSpace;
        if (current.leftMatchesDynamic && current.leftSharedOrigin)
            current.leftDifference = JointDifference.Read(current.dynamic.left, lab.Frame.left);
        if (current.rightMatchesDynamic && current.rightSharedOrigin)
            current.rightDifference = JointDifference.Read(current.dynamic.right, lab.Frame.right);
    }

    static bool CanCompare(RawHand raw, HandSnapshot hand, double rawTime) =>
        raw != null && raw.tracked && raw.jointsUpdated && hand != null && hand.tracked && hand.fresh &&
        hand.wristPosesValid && Math.Abs(hand.observedAt - rawTime) <= 0.003;

    static void PlayState(PlayModeStateChange state) { if (state == PlayModeStateChange.ExitingPlayMode) Stop(); }
    static void Tick()
    {
        if (EditorApplication.timeSinceStartup >= deadline || !lab || !source.running) Stop();
    }

    static void Stop()
    {
        if (source == null) return;
        source.updatedHands -= OnRaw;
        Application.onBeforeRender -= ReadGameplay;
        EditorApplication.update -= Tick;
        EditorApplication.playModeStateChanged -= PlayState;
        AssemblyReloadEvents.beforeAssemblyReload -= Stop;
        source = null;
        var directory = Path.GetFullPath(Path.Combine(Application.dataPath, "../Logs/QuestHandCapture"));
        string path = Path.Combine(directory, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + ".jsonl");
        try
        {
            Directory.CreateDirectory(directory);
            header.samples = samples.Count;
            using (var writer = new StreamWriter(path, false, new UTF8Encoding(false)))
            {
                writer.WriteLine(JsonUtility.ToJson(header));
                foreach (var sample in samples) writer.WriteLine(JsonUtility.ToJson(sample));
            }
            Debug.Log($"Saved {samples.Count} Quest hand samples in {path}");
        }
        finally { samples.Clear(); current = null; lab = null; leftSpace = rightSpace = null; }
    }

    // Batch smoke checks SDK index ordering, real-frame admission, stale rejection and serialization.
    public static void SelfCheck()
    {
        var raw = new RawHand { tracked = true, jointsUpdated = true };
        var hand = new HandSnapshot { tracked = true, fresh = true, wristPosesValid = true, observedAt = 10.001 };
        var slots = new HashSet<int>();
        for (int i = XRHandJointID.BeginMarker.ToIndex(); i < XRHandJointID.EndMarker.ToIndex(); i++)
            slots.Add(SealXRHandsSource.MetaJointIndex(XRHandJointIDUtility.FromIndex(i)));
        var json = JsonUtility.ToJson(new Sample { frame = 42, dynamic = new Raw { at = 10, left = raw } });
        if (slots.Count != 26 || !slots.SetEquals(System.Linq.Enumerable.Range(0, 26)) ||
            !CanCompare(raw, hand, 10) || CanCompare(raw, hand, 10.02) || !json.Contains("\"jointsUpdated\":true"))
            throw new InvalidOperationException("Quest hand capture self-check failed.");
        hand.fresh = false;
        if (CanCompare(raw, hand, 10)) throw new InvalidOperationException("Stale sample accepted.");
        raw.valid[8] = hand.jointValid[8] = true;
        raw.joints[8] = Pose.identity;
        hand.joints[8] = new Pose(Vector3.right * 0.005f, Quaternion.Euler(0, 15, 0));
        var diff = JointDifference.Read(raw, hand);
        if (diff.validJoints != 1 || diff.positionJoint != 8 || Mathf.Abs(diff.worstPositionMm - 5) > 0.001f ||
            Mathf.Abs(diff.worstAngleDegrees - 15) > 0.01f) throw new InvalidOperationException("Joint difference scale or index mismatch.");
        Debug.Log("QUEST_HAND_LAYER_CAPTURE_SELF_CHECK_PASS");
        if (Application.isBatchMode) EditorApplication.Exit(0);
    }
}
