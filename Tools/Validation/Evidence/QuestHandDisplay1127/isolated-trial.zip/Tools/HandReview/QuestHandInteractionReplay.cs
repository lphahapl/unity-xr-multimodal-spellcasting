using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using NarutoVR.SealLab;
using NarutoVR.SealCombat.Rpg;
using NarutoVR.SealCombat.Items;
using Object=UnityEngine.Object;
using Lab=NarutoVR.SealLab.SealLab;
public static class QuestHandInteractionReplay
{
    const string Dir="D:/Temp/QuestHandReview1127/interaction/", Key="quest1127.interaction";
    [Serializable] public class Cases { public Input[] files; }
    [Serializable] public class Input { public string path,keys,lines,sha; public int n; }
    static BindingFlags flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
    static MethodInfo Sample=typeof(PlayerInputController).GetMethod("SampleHands",flags);
    static MethodInfo Read=typeof(PlayerInputController).GetMethod("ReadHandFrame",flags);
    static MethodInfo Score=typeof(Lab).GetMethod("Evaluate",flags);
    static FieldInfo Frame=typeof(Lab).GetField("<Frame>k__BackingField",flags);
    static FieldInfo Rec=typeof(Lab).GetField("recognition",flags);
    static List<string> result=new();
    static string F(float x)=>x.ToString("F6",System.Globalization.CultureInfo.InvariantCulture);
    static void Say(string s){result.Add(s);File.WriteAllLines(Dir+"results.txt",result);}
    public static void Run()
    {
        if(!Application.persistentDataPath.Contains("NarutoVR_MovementComfortQA"))throw new InvalidOperationException("Save location guard");
        if(UnityEngine.XR.Management.XRGeneralSettings.Instance.InitManagerOnStart)throw new InvalidOperationException("XR must be off");
        EditorSceneManager.OpenScene("Assets/Scene/Chapter02_SuspendedPath.unity");
        SessionState.SetBool(Key,true);SessionState.SetFloat(Key+".start",(float)EditorApplication.timeSinceStartup);
        EditorApplication.EnterPlaymode();
    }
    [InitializeOnLoadMethod] static void Init()=> EditorApplication.update+=Tick;
    static void Tick()
    {
        if(!SessionState.GetBool(Key,false)||!EditorApplication.isPlaying)return;
        try{
            var p=Object.FindFirstObjectByType<LinearRpgController>();
            if((!p||!p.CanAct)&&EditorApplication.timeSinceStartup-SessionState.GetFloat(Key+".start",0)<110)return;
            if(Time.frameCount<8)return;
            if(!p||!p.CanAct)throw new Exception("Formal player failed to become ready");
            if(UnityEngine.XR.Management.XRGeneralSettings.Instance.Manager.activeLoader)throw new Exception("Active hardware loader");
            SessionState.EraseBool(Key);
            Check(p);
            Say("END");EditorApplication.Exit(0);
        }catch(Exception e){SessionState.EraseBool(Key);Say("FAIL "+e);EditorApplication.Exit(1);}
    }
    static void Check(LinearRpgController p)
    {
        var lab=p.handTracking;var w=p.wristMenu;
        var releaseHeng=AssetDatabase.LoadAssetAtPath<SealProfile>("Assets/QuestHandInteractionReview1127/CurrentHeng.asset");
        int heng=lab.profiles.FindIndex(x=>x&&x.sealName=="衡印");
        if(!releaseHeng||heng<0||releaseHeng.sealName!="衡印")throw new Exception("Current formal Heng profile missing"); lab.profiles[heng]=releaseHeng;
        if(!w||!w.wornDevice||w.playerWatchMount)throw new Exception("Wrist fallback binding differs");
        Say("scene="+p.gameObject.scene.path+" CanAct="+p.CanAct+" loader=none head=authored desktop eye (recorded head unavailable); profiles="+string.Join(",",lab.profiles.Select(x=>x?x.sealName:"NULL"))+" offset="+w.deviceOffset.ToString("F4"));
        var extractor=new SealFeatureExtractor(); var rec=(SealRecognizer)Rec.GetValue(lab);
        string key="";int line=0;var ev=new List<string>();
        lab.WhenSealRecognized+=(profile)=>ev.Add(line+"="+profile.sealName);
        var direct=Object.FindFirstObjectByType<ToolBeltInteraction>();
        Say("actualSceneBelt="+(direct?direct.name:"none"));
        var manifest=JsonUtility.FromJson<Cases>(File.ReadAllText(Dir+"inputs.json"));
        var samples=new List<string>{"key\tsourceLine\tstate\tcandidate\trecognized\tleftWristValid\trightPinchDistanceM\trightPinchDown\trightPinchUp\trightGripValid\tleftWristMountValid\tdeviceActive\tdevicePositionErrorM\trightPinchSource\trightClosed\trightOpen"};
        PlayerHandObservation closed=default;
        foreach(var input in manifest.files)
        {
            ev.Clear(); rec.Reset(); p.Input.Pickups.Reset();
            var poseField=typeof(PlayerInputController).GetField("handPoses",flags); poseField.SetValue(p.Input,null);
            var keys=input.keys.Split('|');var selectedLines=input.lines.Split('|').Select(int.Parse).ToArray();key=keys[0];
            int mounts=0,heldFrames=0,grips=0,downs=0,ups=0,edges=0,lc=0,rc=0,opened=0,system=0,visible=0,wristPressed=0;
            bool armed=false;line=0;float maxPositionErr=0,maxAngleErr=0;
            var src=File.ReadAllLines(input.path);
            foreach(var raw in src)
            {
                line++;
                var frame=JsonUtility.FromJson<SealFrame>(raw);
                Frame.SetValue(lab,frame); extractor.Extract(frame,lab.Features);
                Score.Invoke(lab,new object[]{frame.time});
                Sample.Invoke(p.Input,new object[]{frame.time});
                var h=p.Input.LatestHand;
                if(h.rightClosed)rc++;if(h.leftClosed)lc++;if(h.rightOpen)opened++;
                if(h.systemPinch)system++;
                bool down=h.PinchDown(.03f),up=h.PinchUp(.045f);
                if(down){downs++;if(armed)edges++;armed=false;}
                if(up){ups++;armed=true;}
                if(h.gripPoseValid)grips++;
                if(h.mountValid)mounts++;
                if(w.PrepareWristTap(h,false,frame.time))wristPressed++;
                if(w.wornDevice.gameObject.activeSelf)visible++;
                float e=Vector3.Distance(w.wornDevice.transform.position,h.leftWrist+h.mountRotation*w.deviceOffset);
                if(h.mountValid){maxPositionErr=Math.Max(maxPositionErr,e);maxAngleErr=Math.Max(maxAngleErr,Quaternion.Angle(w.wornDevice.transform.rotation,h.mountRotation*Quaternion.Euler(w.deviceEuler)));}
                if(direct&&direct.Held)heldFrames++;
                int idx=Array.IndexOf(selectedLines,line);
                if(idx>=0)samples.Add(string.Join("\t",keys[idx],line,lab.RecognitionState,lab.Candidate?lab.Candidate.sealName:"",lab.Recognized?lab.Recognized.sealName:"",h.leftValid,F(h.pinchDistance),down,up,h.gripPoseValid,h.mountValid,w.wornDevice.gameObject.activeSelf,F(e),h.pinchSource,h.rightClosed,h.rightOpen));
                if(h.gripPoseValid&&h.rightValid&&down&&!h.systemPinch&&closed.source==null)closed=h;
            }
            Say($"{key}: frames={line}; recognition events={string.Join(",",ev)}; rightDown={downs}; rightUp={ups}; rightNewPress={edges}; rightSystemPinch={system}; validGrip={grips}; leftClosed={lc}; rightClosed={rc}; rightOpen={opened}; wristMountValid={mounts}; deviceVisible={visible}; wristConfirmedPress={wristPressed}; sampledBeltHeldFrames={heldFrames}; maxWristPosM={F(maxPositionErr)}; maxWristAngleDeg={F(maxAngleErr)}");
        }
        File.WriteAllLines(Dir+"selected-results.tsv",samples);
        if(closed.source==null)throw new Exception("No valid closed hand in selected archive for isolated pickup");
        var bodyObj=new GameObject("controlled pickup probe only");
        var body=bodyObj.AddComponent<Rigidbody>();body.useGravity=false;body.isKinematic=true;
        var item=bodyObj.AddComponent<GameItemBase>(); bodyObj.AddComponent<SphereCollider>().radius=.015f;
        bodyObj.transform.position=closed.rightTip; Physics.SyncTransforms();
        if(!direct){var go=new GameObject("controlled production belt provider"); direct=go.AddComponent<ToolBeltInteraction>();direct.player=p;}
        typeof(ToolBeltInteraction).GetMethod("RegisterItem",flags).Invoke(direct,new object[]{item});
        Say("control precondition: item at tip; input="+closed.pinchSource+"; actualDownDistance="+F(closed.pinchDistance)+"; beltInitialised="+direct.Initialised+"; canAct="+p.CanAct);
        p.Input.Pickups.Reset();
        var arming=closed;
        arming.pinchDistance=.06f; arming.rightObserved=closed.rightObserved-.025;
        p.Input.Pickups.Evaluate(default,arming,arming.rightObserved+.001);
        bool hovered=p.Input.Pickups.Highlighted(false)==item.transform;
        p.Input.Pickups.Evaluate(default,closed,closed.rightObserved+.001);
        bool selected=direct.Held==item&&item.IsHeld;
        Say("Control using real query, placed probe, one synthetic open preparatory sample, then unchanged archive closed sample: hover="+hovered+" selection="+selected);
        if((selected || direct.TryPickup(item.transform,false,closed))&&direct.Held==item&&item.IsHeld&&item.HasBeenTaken)
        {
            var err=Vector3.Distance(item.GripPosition,closed.gripPosition);
            Say("controlled provider positive: ToolBeltInteraction.TryPickup -> GameItemBase.Take -> IsHeld=true, same-frame grip error M="+F(err)+", interaction claimed="+p.Input.InteractionOwnsHand);
            if(err>.0001f||!p.Input.InteractionOwnsHand)throw new Exception("Grip or input owner mismatch");
        } else throw new Exception("Registered controlled item not actually held");
        Say("If the controlled query did not select the item, the positive test called the actual provider directly with the archived closed sample. Natural uninterrupted recordings had separate input/contact circumstances; controlled call alone does not establish a real device or naturally selected grab.");
    }
}
