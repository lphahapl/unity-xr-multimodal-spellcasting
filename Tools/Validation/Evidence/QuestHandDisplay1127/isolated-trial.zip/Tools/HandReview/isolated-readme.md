# Quest 官方手显示对照

## 怎样打开

用 Unity 6000.3.10f1 打开隔离工程 `D:/Temp/Naruto-ChapterEntry-QA-1126/Project`。

- 桌面回看选 **Tools → Quest Hand Trial → Open offline recorded frames**，按 Play。上方 A/B 切换显示，Previous/Next 选一帧。勾选 Recorded pair 可保留两手原来的相对位置与方向。默认的腕部对齐视角适合比较同一根手指。场景是 `Assets/QuestHandTrial/QuestHandRecordedFrames.unity`。
- 连 Quest 3 与 PC Steam Link 并让 SteamVR 提供 OpenXR 后，选 **Tools → Quest Hand Trial → Open live chapter (PC OpenXR)**，按 Play。在 Hierarchy 搜索「Quest 手部显示」，选中后在 Inspector 的「显示方式」切换 Current Meta 和 Unity Fixed Length。两手同时切换。二章现场入口是 `Assets/QuestHandTrial/Chapter02_QuestHandDisplayAB.unity`。默认 A。窗口切换发生在 Game 运行时。摘头显结束后，可用离线菜单恢复该隔离工程的 Standalone XR 设置。
- 现场只需比较同一个动作。先放松摊手后缓慢握拳，再让拇食指腹捏合后分开；结一个惯用印，抬左腕检查匣扣，最后从笔套取出墨规笔再放回。重点看右手是否跟动、指根是否扭折、捏合与笔身是否对齐。桌面录制没有成功捏合的逐帧证据。现场时可同时开启主会话提供的上游关节记录。

隔离二章从正式 `Assets/Scene/Chapter02_SuspendedPath.unity` 的 a51820e4939dedb3302e4736b9f6b2b8e39a6211e821aa5ff1044f6aab706ac7 复制。追加两套显示组件，独立存档名为 `quest-hand-display-trial-ch02.json`。现场 A 使用正式 Meta UnityXRHandVisual 和原始输入引用。B 引用 Unity XR Hands 1.7.2 HandVisualizer 样例的左右手 FBX，两个 FBX 的 SHA-256 与已安装官方包逐个相同。试用菜单限定写隔离工程的 Standalone 设置，Android 配置另由打包者管理。

## 能复查什么

同一双手帧分别驱动 A 和 B。桌面回放通过原 Meta `HandVisual.UpdateSkeleton` 重建 A。B 从同一份关节数据重建官方 Unity 网格。B 保留指段的横向尺寸，腕、掌、五个掌骨根及五个近节根随跟踪，指节按当前骨段方向和扭转驱动，末节沿自身纵轴按当帧测得长度适配。摄像机和中性材质在每对图上相同。每一帧另有保留双手相对姿势的原位视图。现场 B 读取章节同侧 `SealLab.Frame` 的姿态、逐骨有效性和时间，只驱动显示。缺一关节、过期或未来时间会隐藏该侧 B 并在完整观测恢复后重显。

- 2026-11-27 Quest 3 / Steam Link 段来自同一次五秒采样，取开始、中间、结束三帧。此段右手关节在 210 次观测内逐值不变，左手持续变化；来源止于 Meta `IHand`。另五个姿态源自较早的 SteamVR 历史录制，含规、矩、律和四指伸屈几何例，历史那次头显型号未证实。
- 实际 Unity 摄像机输出 36 张图。两组静态佩戴图取自该章腕匣和实体墨规笔，复用章中按腕及指根求挂点的布置。缩短到手腕的官方网格没有前臂，部分视角能透过腕带看到背景。试装图用于判断几何贴合；真实摘笔、入槽、指腹接触与头显内外观仍由现场测试裁定。
- 八个双手帧共 16 侧，A 的五指端点最大跟踪误差为 0.002 mm。B 初版 18.077 mm，仅纠正掌根后一版 9.898 mm，最终腕及手指根锚定、末节适配后为 0.254 mm。两组佩戴例的腕骨和抓笔指根中点与输入挂点距离均小于 0.001 mm。
- 骨端与指腹分别测量。筛选各指远节与端点权重之和至少 0.5 的顶点，取沿末节轴的最前点。相对跟踪指尖，A 为 +2.00 至 +9.45 mm，B 为 −3.24 至 +5.42 mm；负值表示最前点在跟踪端后方。筛出顶点与目标最近距离 A 为 2.52 至 5.61 mm、B 为 1.54 至 4.29 mm。这是加权顶点的几何读数，不能代替指腹接触、轮廓舒适度或解剖精度。B 尚有指腹略收的角度。
- 局部骨段方向的最大误差为 B 0.028°。五指分节长度、掌宽、每帧拇食跨度以及腕局部轴列在表内。B 绑姿左右 26 关节沿拇指轴镜像后最大差为 0.547 mm。A 每侧 1360 顶点，B 每侧 1616 顶点，均 26 个绑定骨槽；桌面 BakeMesh 做了顶点有限性和逐顶点权重归一检查。

## 证据

- [双列视觉对照](Review/official-hand-comparison.jpg)
- [几何与肌肤对照](Review/comparison-summary.json)，[关节读数](Review/pose-metrics.csv)，[指腹顶点读数](Review/fingertip-surface.csv)，[腕与笔](Review/fittings.csv)，[绑定轴与尺寸](Review/bind-axes.csv)。
- [显示切换与逐骨失追回归](Review/replay-play.txt)，[PC OpenXR 菜单配置校验](Review/modes.txt)，[二章副本 Play](Review/chapter-play.txt)，[交付文件 SHA-256](verified-assets.json)。
- 同目录 `Assets/` 是隔离工程的相对路径镜像。保留首版与第二版的回归数据方便比较。笔交互和结印仍从原章节输入取数。结果限于桌面重放和禁 XR 的章节运行；Android GPU 蒙皮、真实 Quest 手指捏合、抓笔与握拳仍待测试。
