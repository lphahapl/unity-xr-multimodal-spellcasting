using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NarutoVR.SealLab;
using Oculus.Interaction;
using UnityEditor;
using UnityEngine;

// Replay the recorded, post-adapter joint transforms on the same official skin twice.
// Changing only the influence budget isolates skinning from provider or retargeting changes.
public static class QuestHandInfluenceProbe
{
    [Serializable] class Selection { public string key; public SealFrame frame; }
    [Serializable] class Surface
    {
        public string sample, side;
        public int[] triangles;
        public Vector3[] two, four;
        public float[] displacementMm;
        public Vector3 wrist, indexBase, littleBase, middleBase;
    }
    const string Prefabs = "Packages/com.meta.xr.sdk.interaction/Runtime/UnityXR/Prefabs/Hands/";
    static readonly int[] ParentFirst = new[] { 1, 0 }.Concat(Enumerable.Range(2, 24)).ToArray();

    public static void Run()
    {
        var input = Environment.GetEnvironmentVariable("QUEST_HAND_REPLAY_INPUT");
        var output = Environment.GetEnvironmentVariable("QUEST_HAND_INFLUENCE_CSV");
        var rows = new List<string> { "sample,hand,vertices,over1mm,over2mm,p95mm,maxmm,maxVertex,mainBoneAtMax,bakeMaxMm" };
        foreach (string line in File.ReadLines(input))
        {
            var sample = JsonUtility.FromJson<Selection>(line);
            rows.Add(Measure(sample.key, "Left", sample.frame.left));
            rows.Add(Measure(sample.key, "Right", sample.frame.right));
        }
        File.WriteAllLines(output, rows, new UTF8Encoding(false));
        Debug.Log("QUEST_HAND_INFLUENCES_PASS rows=" + (rows.Count - 1));
        if (Application.isBatchMode) EditorApplication.Exit(0);
    }

    static string Measure(string name, string side, HandSnapshot recorded)
    {
        if (!recorded.tracked || !recorded.fresh || recorded.jointValid.Count(x => x) != 26)
            throw new InvalidDataException("Untracked or partial hand in " + name);
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Prefabs + "UnityXRHandVisual" + side + ".prefab");
        var instance = UnityEngine.Object.Instantiate(prefab);
        var bake2 = new Mesh();
        var bake4 = new Mesh();
        try
        {
            var visual = instance.GetComponent<HandVisual>();
            var skin = (SkinnedMeshRenderer)new SerializedObject(visual).FindProperty("_openXRSkinnedMeshRenderer").objectReferenceValue;
            visual.Root.localScale = Vector3.one * recorded.scale;
            var wrist = recorded.joints[1];
            visual.Root.SetPositionAndRotation(wrist.position, wrist.rotation);
            foreach (int i in ParentFirst)
                visual.Joints[i].SetPositionAndRotation(recorded.joints[i].position, recorded.joints[i].rotation);
            skin.quality = SkinQuality.Bone2;
            skin.BakeMesh(bake2);
            skin.quality = SkinQuality.Bone4;
            skin.BakeMesh(bake4);
            var two = bake2.vertices;
            var four = bake4.vertices;
            var bakedDelta = two.Zip(four, (a, b) => Vector3.Distance(a, b) * 1000f).ToArray();
            float bakeMax = bakedDelta.Max();

            var mesh = skin.sharedMesh;
            var positions = mesh.vertices;
            var weights = mesh.boneWeights;
            var matrices = skin.bones.Select((bone, i) => bone.localToWorldMatrix * mesh.bindposes[i]).ToArray();
            var deltas = new float[positions.Length];
            var twoPositions = new Vector3[positions.Length];
            var fourPositions = new Vector3[positions.Length];
            for (int i = 0; i < deltas.Length; i++)
            {
                var w = weights[i];
                var p = positions[i];
                var a = matrices[w.boneIndex0].MultiplyPoint3x4(p) * w.weight0 +
                        matrices[w.boneIndex1].MultiplyPoint3x4(p) * w.weight1;
                var b = a + matrices[w.boneIndex2].MultiplyPoint3x4(p) * w.weight2 +
                            matrices[w.boneIndex3].MultiplyPoint3x4(p) * w.weight3;
                a /= w.weight0 + w.weight1;
                b /= w.weight0 + w.weight1 + w.weight2 + w.weight3;
                twoPositions[i] = a;
                fourPositions[i] = b;
                deltas[i] = Vector3.Distance(a, b) * 1000f;
            }
            int worst = Array.IndexOf(deltas, deltas.Max());
            if (deltas.Zip(bakedDelta, (a, b) => Mathf.Abs(a - b)).Max() > 0.05f)
                throw new InvalidDataException("World skinning and Unity BakeMesh disagree on " + name + " " + side);
            var surfacePath = Environment.GetEnvironmentVariable("QUEST_HAND_SURFACE");
            if (!string.IsNullOrEmpty(surfacePath) && name == "quest3-1127-middle" && side == "Right")
            {
                var surface = new Surface { sample = name, side = side, triangles = mesh.triangles,
                    two = twoPositions, four = fourPositions, displacementMm = deltas,
                    wrist = recorded.joints[1].position, indexBase = recorded.joints[7].position,
                    middleBase = recorded.joints[12].position, littleBase = recorded.joints[22].position };
                File.WriteAllText(surfacePath, JsonUtility.ToJson(surface), new UTF8Encoding(false));
            }
            float p95 = deltas.OrderBy(v => v).ElementAt((int)Math.Ceiling(deltas.Length * 0.95) - 1);
            return FormattableString.Invariant($"{name},{side},{deltas.Length},{deltas.Count(d => d > 1)},{deltas.Count(d => d > 2)},{p95:F4},{deltas[worst]:F4},{worst},{skin.bones[weights[worst].boneIndex0].name},{bakeMax:F4}");
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(bake2);
            UnityEngine.Object.DestroyImmediate(bake4);
            UnityEngine.Object.DestroyImmediate(instance);
        }
    }
}
