using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public static class QuestHandAudit1127
{
    static string Folder = "D:/Temp/QuestHandReview1127/chain";
    static string Ts(Transform t) => !t ? "" : (t.parent ? Ts(t.parent) + "/" : "") + t.name;
    static string Obj(UnityEngine.Object o)
    {
        if (o is Component c) return Ts(c.transform) + "[" + c.GetType().Name + "]#" + GlobalObjectId.GetGlobalObjectIdSlow(c).targetObjectId;
        if (o is GameObject g) return Ts(g.transform);
        return o ? AssetDatabase.GetAssetPath(o) + "/" + o.name : "";
    }
    static string Esc(string x) => x.Replace("\t", " ").Replace("\r"," ").Replace("\n"," ");
    static void Add(StreamWriter w, params object[] fields) => w.WriteLine(string.Join("\t", fields.Select(x => Esc(Convert.ToString(x, CultureInfo.InvariantCulture) ?? ""))));
    static string V(Vector3 v) => v.ToString("F6");
    static void Skin(StreamWriter w, SkinnedMeshRenderer r, HashSet<Transform> jointSet)
    {
        var m=r.sharedMesh;
        if (!m) { Add(w, "no mesh",Ts(r.transform)); return; }
        Add(w, "skin", Ts(r.transform), m.name, AssetDatabase.GetAssetPath(m), m.vertexCount, m.triangles.Length/3, r.bones.Length, m.bindposes.Length, m.isReadable, r.quality, r.enabled, r.gameObject.activeInHierarchy, Ts(r.rootBone), string.Join(",", r.sharedMaterials.Select(Obj)));
        var weights = m.GetAllBoneWeights();
        var counts = m.GetBonesPerVertex();
        var hist=new Dictionary<int,int>();
        var totals=new double[r.bones.Length];
        var foreign=0; var invalid=0; var unweighted=0; var multiFinger=0; var multiFingerSignificant=0;
        double maxNormError=0, maxOtherFinger=0;
        int k=0;
        for(int i=0;i<counts.Length;i++)
        {
            var n=(int)counts[i]; if(!hist.ContainsKey(n)) hist[n]=0; hist[n]++;
            var fingers=new Dictionary<string,double>();
            double sum=0;if(n==0)unweighted++;
            for(int j=0;j<n;j++,k++)
            {
                var b=weights[k]; sum+=b.weight;
                if(b.boneIndex<0||b.boneIndex>=totals.Length||b.weight<0||float.IsNaN(b.weight)){invalid++;continue;}
                totals[b.boneIndex]+=b.weight;
                var bt=r.bones[b.boneIndex];
                if(!jointSet.Contains(bt))foreign++;
                string f=bt ? new[]{"Thumb","Index","Middle","Ring","Little","Pinky"}.FirstOrDefault(x=>bt.name.IndexOf(x,StringComparison.OrdinalIgnoreCase)>=0): null;
                if(f!=null){if(!fingers.ContainsKey(f))fingers[f]=0;fingers[f]+=b.weight;}
            }
            if(fingers.Count>1){multiFinger++;double other=fingers.Values.Sum()-fingers.Values.Max();maxOtherFinger=Math.Max(maxOtherFinger,other);if(other>.05)multiFingerSignificant++;}
            maxNormError=Math.Max(maxNormError, Math.Abs(sum-1));
        }
        Add(w, "weights", Ts(r.transform), "weights="+weights.Length, "hist="+string.Join(",",hist.Select(p=>p.Key+"="+p.Value)), "unweighted="+unweighted, "invalid="+invalid, "weight outside joint set="+foreign, "max norm err="+maxNormError,"mesh vertices with two named finger influences="+multiFinger, "sum of other fingers >0.05="+multiFingerSignificant, "max other-finger weight="+maxOtherFinger);
        for (int i=0; i < r.bones.Length; i++)
        {
            var b=r.bones[i]; if(!b){Add(w,"null bone",i);continue;}
            var matrix = r.transform.worldToLocalMatrix*b.localToWorldMatrix*m.bindposes[i];
            Add(w,"bone",i,b.name,b.parent?b.parent.name:"",V(b.localPosition),V(b.localEulerAngles),V(b.localScale),V(matrix.GetColumn(3)),Quaternion.Angle(Quaternion.identity,matrix.rotation),V(matrix.lossyScale),totals[i]);
        }
    }
    static void Audit(string name)
    {
        var s=EditorSceneManager.OpenScene("Assets/QuestHandAudit1127/"+name+".unity",OpenSceneMode.Single);
        var comps=s.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<Component>(true)).Where(c=>c).ToArray();
        using(var w=new StreamWriter(Path.Combine(Folder, name+".tsv")))
        {
            Add(w,"scene",s.path, "component count="+comps.Length);
            string[] interested={"SealLab","SealXRHandsSource","PlayerInputController","Wrist","DistanceGrab","FromUnityXRHandDataSource","Hand","GlyphPenController","TravelRationInteraction","ToolBeltInteraction","SpellAim","HandVisual"};
            foreach(var c in comps.OfType<MonoBehaviour>())
            {
                var n=c.GetType().Name;
                if(!interested.Any(x=> n==x || ((x=="Wrist"||x=="DistanceGrab"||x=="SpellAim") && n.Contains(x))))continue;
                Add(w,"component",n,Obj(c),c.enabled,c.gameObject.activeInHierarchy,PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(c.gameObject));
                var so=new SerializedObject(c);
                var prop=so.GetIterator();
                while(prop.NextVisible(true))
                {
                    if(prop.depth>0||prop.name=="m_Script")continue;
                    if(prop.propertyType==SerializedPropertyType.ObjectReference) Add(w,"  ref",prop.name,Obj(prop.objectReferenceValue));
                    if(prop.name=="_updateType")Add(w,"  update type",prop.enumDisplayNames[prop.enumValueIndex]);
                }
                if(n!="HandVisual")continue;
                var jt=so.FindProperty("_openXRJointTransforms");
                var q=new HashSet<Transform>();
                for(int j=0;j<jt.arraySize;j++)
                {
                    var t=jt.GetArrayElementAtIndex(j).objectReferenceValue as Transform;
                    Add(w,"joint",j,t?t.name:"",t&&t.parent?t.parent.name:"",t ? V(t.localPosition):"",t?V(t.localEulerAngles):"");
                    if(t)q.Add(t);
                }
                var source=so.FindProperty("_hand").objectReferenceValue;
                var root=so.FindProperty("_openXRRoot").objectReferenceValue as Transform;
                Add(w,"visual chain",Obj(source),Ts(root), V(c.transform.lossyScale),so.FindProperty("_updateRootScale").boolValue,so.FindProperty("_updateRootPose").boolValue);
                foreach(var child in c.GetComponentsInChildren<Component>(true).Where(z=>z && !(z is Transform)).GroupBy(z=>z.GetType().FullName))
                    Add(w,"visual attached",child.Key,child.Count());
                foreach(var r in c.GetComponentsInChildren<SkinnedMeshRenderer>(true))Skin(w,r,q);
            }
            foreach(var c in comps.Where(c=>c is Animator || c is Animation || c.GetType().Name.Contains("SkeletonDriver") || c.GetType().Name=="OVRSkeleton")) Add(w,"other possible driver",c.GetType().Name,Ts(c.transform));
        }
    }
    public static void Run()
    {
        try {foreach(var name in new[]{"Chapter01_Awakening","Chapter01_Courtyard","Chapter02_SuspendedPath"})Audit(name); File.WriteAllText(Path.Combine(Folder,"unity-success.txt"),Application.unityVersion+"\n"+DateTimeOffset.Now.ToString("O")); EditorApplication.Exit(0);}
        catch(Exception e){File.WriteAllText(Path.Combine(Folder,"unity-error.txt"),e.ToString());Debug.LogException(e);EditorApplication.Exit(2);}
    }
}
