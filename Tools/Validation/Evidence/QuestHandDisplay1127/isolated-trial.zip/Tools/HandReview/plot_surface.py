"""Plot projected Unity skinning surfaces. Input exported by QuestHandInfluenceProbe."""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.colors import Normalize
from matplotlib.font_manager import FontProperties
import numpy as np


def xyz(point):
    return np.array([point[key] for key in "xyz"])


def unit(vector):
    return vector / np.linalg.norm(vector)


def main(source, destination):
    data = json.loads(Path(source).read_text(encoding="utf-8-sig"))
    font = FontProperties(fname="C:/Windows/Fonts/msyh.ttc")
    wrist = xyz(data["wrist"])
    vertical = unit(xyz(data["middleBase"]) - wrist)
    across = xyz(data["indexBase"]) - xyz(data["littleBase"])
    across = unit(across - vertical * np.dot(vertical, across))
    face = unit(np.cross(across, vertical))
    view = unit(-face * 0.88 + across * 0.46 + vertical * 0.13)
    right = unit(np.cross(vertical, view))
    up = np.cross(view, right)
    basis = np.column_stack((right, up, view))
    tri = np.array(data["triangles"]).reshape(-1, 3)
    delta = np.array(data["displacementMm"])
    norm = Normalize(0, np.ceil(delta.max()))
    cmap = plt.get_cmap("inferno")
    surfaces = [((np.array([xyz(p) for p in data[key]]) - wrist) @ basis) * 1000 for key in ("two", "four")]
    xy = np.vstack(surfaces)[:, :2]
    low, high = xy.min(axis=0) - 3, xy.max(axis=0) + 3
    fig, axes = plt.subplots(1, 3, figsize=(9.0, 4.4), facecolor="#ffffff")
    for ax, pts, title, heat in zip(axes, [surfaces[0], surfaces[1], surfaces[1]],
                                    ["每个顶点两骨", "每个顶点四骨", "同一顶点的位移"], [False, False, True]):
        faces = pts[tri]
        depth = np.argsort(faces[:, :, 2].mean(axis=1))
        normals = np.cross(faces[:, 1] - faces[:, 0], faces[:, 2] - faces[:, 0])
        normals /= np.maximum(1e-10, np.linalg.norm(normals, axis=1)[:, None])
        light = 0.45 + 0.5 * np.abs(normals @ unit(np.array([-0.35, 0.55, 1.])))
        colors = cmap(norm(delta[tri].mean(axis=1))) if heat else np.outer(light, [0.74, 0.81, 0.84])
        ax.add_collection(PolyCollection(faces[depth, :, :2], facecolors=colors[depth],
                                         edgecolors="face", linewidths=0.15))
        ax.set(xlim=(low[0], high[0]), ylim=(low[1], high[1]), aspect="equal")
        ax.set_title(title, fontproperties=font, fontsize=13)
        ax.axis("off")
    fig.subplots_adjust(left=0.03, right=0.96, top=0.82, bottom=0.18, wspace=0.10)
    fig.suptitle("Quest 3 同一录制帧 · 右手官方网格", fontproperties=font, fontsize=16, y=0.96)
    cb = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap),
                      cax=fig.add_axes([0.68, 0.125, 0.24, 0.021]), orientation="horizontal")
    cb.ax.set_xlabel("毫米", fontproperties=font, fontsize=9)
    cb.ax.tick_params(labelsize=8)
    fig.text(0.04, 0.09, "网格最大位移 %.1f 毫米 · 三幅同视角" % delta.max(), fontproperties=font, fontsize=10)
    fig.savefig(destination, dpi=160, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main(*sys.argv[1:])
